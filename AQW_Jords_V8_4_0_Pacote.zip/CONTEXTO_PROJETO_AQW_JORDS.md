# AQW Jords — Contexto técnico e histórico para manutenção

**Versão do pacote:** 8.4.0 (método opcional SendInput com jogo ativo)  
**Data:** 14/11/2026  
**Sistema-alvo:** Windows 10/11, Artix Experimental Launcher com Ruffle  
**Status funcional:** usuário confirmou versão clássica 7.6 e interface 8.3 em seu computador; a seleção ao vivo introduzida na V8.3.6 não foi executada nem validada no Windows/Ruffle neste ambiente. 

> **LEIA ESTE ARQUIVO ANTES DE MODIFICAR O PROJETO.** O usuário prioriza manter a lógica que já funcionou. Não confundir compilação com teste funcional no jogo. Este documento acompanha o código-fonte, para permitir continuidade em novas conversas, correções e refatorações.

## 1. Objetivo e escopo

Ferramenta **local, portátil e sem instalação**, chamada **AQW Jords**, para reduzir tarefas repetitivas durante sessões de AdventureQuest Worlds, sem editar o Ruffle, o launcher ou o tráfego do jogo. O usuário deseja gerenciar manualmente seus itens, equipamentos e potions enquanto o programa facilita a repetição de comandos e o acompanhamento visual de quests. O aplicativo usa métodos de automação externos ao jogo; seu uso pode contrariar os termos da Artix e gerar sanções de conta. Não há tentativa de burlar proteções ou de acessar a memória do jogo.

**Restrições do projeto definidas pelo usuário:**
- Idioma de toda a interface e documentação: **português brasileiro**.
- Executável único `.exe`, portátil, sem arquivo `.bat` para abrir.
- Logo: símbolo original enviado pelo usuário, com fundo branco removido; não redesenhar a marca sem solicitação.
- UI: tema escuro, ícones Lucide de licença permissiva, navegação pelo botão **Menu** (sem barra lateral fixa).
- Preferência essencial: **preservar o motor de entrada, o OCR, o comportamento do mouse, as quests, o painel flutuante e os atalhos F2/F3** sempre que o pedido for exclusivamente visual.
- Não prometer teste real no Windows/Ruffle quando houver apenas testes estáticos no ambiente Linux. O novo SendInput depende de validação prática.

## 2. Arquitetura concreta (não confundir com WebView2)

```
AQW_Jords_V8_4_0.exe  [src/main.go, binário Go Windows GUI]
  ├─ extrai arquivos incorporados para diretório temporário
  ├─ executa powershell.exe -STA -File engine.ps1 sem console
  │   ├─ classes C# compiladas com Add-Type
  │   │   ├─ BackgroundKeySender: PostMessage (modos 0–2) e SendInput (modo 3, foco obrigatório)
  │   │   ├─ AQWQuestVision: captura de tela, cursor, cliques, comparação
  │   │   ├─ AQWQuestPicker: seletor da imagem capturada, ajuste/zoom
  │   │   ├─ AQWLivePointPicker: marcacao direta sobre o jogo real (sem screenshot)
  │   │   ├─ AQWHotkeyReceiver: atalhos globais RegisterHotKey
  │   │   └─ AQWStatusOverlay: painel flutuante sem capturar cliques
  │   ├─ Windows Forms: motor, controles e temporizadores
  │   ├─ WebBrowser do Windows Forms: interface HTML local
  │   └─ ponte COM AQWJordsWebBridge (JavaScript -> PowerShell)
  └─ fallback.ps1: interface clássica antiga se a principal não abrir
```

**ATENÇÃO:** o frontend atual é renderizado pelo controle **System.Windows.Forms.WebBrowser**, não pelo Microsoft WebView2. Recursos CSS modernos podem não funcionar como em um Chrome atual. O problema antigo de sobreposição da sidebar foi resolvido na V8.3 ao removê-la da UI. Qualquer migração futura para WebView2 exigiria trabalho específico e validação dos eventos da ponte.

### Arquivos essenciais

| Caminho | Conteúdo | Regra de manutenção |
|---|---|---|
| `src/main.go` | Empacotador, execução, diagnóstico e fallback | Evitar mudanças se estiver funcionando; compilar com `-H windowsgui` |
| `src/engine.ps1` | Lógica principal PowerShell, C# e WinForms | **Preservar**, salvo correção solicitada |
| `src/interface.html` | Estilos, navegação, cards, JS e comandos da ponte | Alterar isoladamente para demandas exclusivamente visuais |
| `src/fallback.ps1` | Interface de compatibilidade (antiga V6) | NÃO confundir com o motor atual completo; não atualizar por engano |
| `src/logo.png`, `src/logo_original.png`, `src/app.ico` | Identidade visual e ícone | Preservar imagem original enviada pelo usuário |
| `Icones_Lucide_SVG/` | Ícones abertos embarcados | Conferir `LICENCA_ICONES_LUCIDE.txt` |
| `CONTEXTO_PROJETO_AQW_JORDS.md` | **Este contexto** | Atualizar sempre que houver mudança de arquitetura, bugs ou decisões |
| `CHANGELOG_V8_3_7.md` | Correção da aba Habilidades | Manter histórico de correções e testes |
| `tests/test_coordinate_model.py` e `tests/test_live_click_picker.py` | Testes geométricos e contratos de seleção ao vivo | Executar antes de publicar |

## 3. Fluxos funcionais a preservar

### Sequência de habilidades
- Seleção/fixação de janela do jogo (HWND); escolha opcional de componente interno.
- Adição, remoção, reordenação e ativação individual de teclas; intervalo individual após cada tecla em milissegundos.
- Modos 0–2: mensagens `WM_KEYDOWN/WM_KEYUP` via `PostMessage` (envio direcionado, sem exigir foco). Modo 3 opcional: `SendInput` com scan code, pressionamento de 45 ms e **AQW obrigatoriamente em primeiro plano**; ao perder o foco, o aplicativo aguarda sem enviar teclas.
- **F3 global** inicia/pausa/retoma; programa pode estar minimizado. Modo alternativo `WM_CHAR` mantido.

### Quests visuais
- Quest cadastrada com nome, ponto de clique na lista, posição do botão **Turn in!** e 1+ requisitos `X/Y` selecionados na tela.
- O OCR nativo do Windows retorna `Count` e `Need`. Uma quest só é entregável se **todos** os requisitos estiverem legíveis e `Count >= Need`.
- Após clicar em `Turn in!`, verificar se ao menos um requisito consumível diminuiu adequadamente, relendo todos antes de nova entrega. Sem confirmação: estado `Recover`, sem clicar repetidamente às cegas.
- **F2 global** pede revalidação manual, seguido por novas leituras. F2 não deve forçar uma entrega enquanto ainda está sendo verificada.
- Clique na quest: método de mouse legado validado em V7.2. Clique de Turn in: `SendInput` validado em V7.2. Movimento suave e tempos individualmente configuráveis desde V7.3. **Não alterar a estratégia de clique para corrigir apenas coordenadas.**

### Painel flutuante
- Always-on-top e sem ativação/interceptação de mouse. Exibe cada requisito, estados e falhas de OCR.
- Os dados vêm da leitura normal do monitor, não de um OCR duplicado.

## 4. Problema de coordenadas: origem, correção e invariantes

**Sintoma reportado na V8.3.4:** o usuário calibra uma região com imagem aparentemente correta, mas o cursor percorre uma trajetória até **pontos incorretos**. Ambiente inclui monitor de aproximadamente 30 polegadas e possível DPI/escala não padrão.

**Causa técnica identificada:** `MonitorBounds`, `ClientBounds` e `Capture` da classe `AQWQuestVision` utilizam `SetThreadDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)` e trabalham em **pixels físicos**. Entretanto, `MoveSmooth`, `Click`, `ClickTurnIn` e `ReturnIfAtTarget` usavam `GetCursorPos` / `SetCursorPos`, que podem operar no espaço **lógico**, conforme a consciência de DPI do processo/thread. O cálculo correto da imagem não garantia o mesmo ponto no cursor.

**Correção V8.3.5:** todas as leituras e movimentações do mouse dentro do motor usam `GetPhysicalCursorPos` e `SetPhysicalCursorPos`, chamadas nativas que usam coordenadas de pixels físicos de tela. Mantivemos a duração do movimento e os eventos `mouse_event`/`SendInput`. Referências Microsoft: `https://learn.microsoft.com/en-us/windows/win32/menurc/about-cursors`, `https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setphysicalcursorpos` e `https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getphysicalcursorpos`.

**Sistema de coordenadas único:**

```text
pixels da captura do AQW / selecao do usuario (xrel, yrel)
  + origem fisica da area ativa (area.Left, area.Top)
= pixel fisico do monitor (xabs, yabs)
  => SetPhysicalCursorPos(xabs, yabs)
```

- A área manual é escolhida em uma captura **do monitor completo** e convertida em retângulo físico: `monitor.X + selection.X`, `monitor.Y + selection.Y`.
- `AQWQuestPicker` pode mostrar a captura reduzida/ampliada, mas devolve o retângulo nas coordenadas originais da imagem (`ConvertToOriginalPixels`).
- **Jamais** misturar DPI lógicos de WinForms com posições físicas do cursor.
- Monitores secundários podem ter origem negativa. Não assumir `(0,0)` nem que o monitor usado é o primário.
- A área manual é temporária (não persiste entre execuções). Se a janela do jogo mudou de posição/tamanho, V8.3.5 **bloqueia o uso da região antiga** em vez de voltar silenciosamente à detecção automática.
- Calibrações feitas com uma área diferente da atual podem precisar ser refeitas. Alterar a área após a calibração sem refazer os pontos é perigoso.

### Instrumento de diagnóstico seguro: teste de cursor sem clique

Na página **Quests**, botão **Testar posição sem clicar**. Só funciona com o monitor de quests desligado, uma quest selecionada e o jogo fixado. Oferece teste do nome da quest OU do centro do botão Turn in; move o mouse ao ponto, permanece 1,5 segundo, verifica desvio em pixels físicos e retorna o cursor. **Não clica**. O objetivo é o usuário observar visualmente se o cursor fica sobre o elemento marcado antes de reativar as entregas. Se o teste numérico mostrar desvio zero, mas o cursor cair fora do alvo, é sinal de calibração antiga ou área manual incorreta, não necessariamente falha da API.

## 5. Estado / arquivos de configuração do usuário

A pasta usada pelo código do monitor é construída em `LocalApplicationData` e aponta para **`AQWComandos\QuestsV6`** (apesar do nome, utilizada nas versões novas). Dentro, existem `quests-v6.json`, imagens de botões `.png`, `mouse-ritmo.json`, `painel-flutuante-v76.json` e imagens de diagnóstico OCR. **Nunca zerar essa pasta automaticamente em atualizações.**

Uma quest persistida contém `Name`, `Enabled`, `File`, `Requirements` (nome/região de cada requisito), `QX/QY` (clique no nome) e `TX/TY/TW/TH` (região do Turn in). Os estados transitórios (por exemplo, `Stage`, `Hits`, `BeforeReadings`, `Turns`) são reconstruídos em memória. Os pontos são relativos à área de captura usada quando se calibrou.

Antes de alterar schema ou coordenadas, faça backup dos registros e planeje migração. Não presumir que um item salvo foi calibrado para o monitor atual.

## 6. Evolução resumida

- **V2.1:** envio virtual para janela direcionada e correção de sintaxe PowerShell.
- **V3:** interface WinForms escura; teclas e intervalos individuais.
- **V4:** executável portátil; F3 global; início/pausa.
- **V5:** primeira leitura visual de quests por imagem.
- **V6/V7.1:** OCR `X/Y`, diagnóstico, mapa de tela e seletor de regiões.
- **V7.2:** correção do clique de Turn in usando `SendInput` e pausa maior.
- **V7.3:** movimento suave, hover e ritmo ajustável.
- **V7.4:** suporte a múltiplos requisitos por quest.
- **V7.5:** recuperação de OCR sem travamento permanente; revalidação manual.
- **V7.6:** F2 revalidar e overlay flutuante; versão clássica de referência confirmada funcionando.
- **V7.7:** tentativa de polimento WinForms e alteração de ícone.
- **V8.0:** interface HTML/CSS/JS sobre o motor WinForms, ponte COM; nome AQW Jords.
- **V8.1/V8.2:** ajustes de sidebar e ícone, sem resultado satisfatório no WebBrowser real.
- **V8.3:** retirada da sidebar; menu por botão; logo original transparente; ícones Lucide SVG. Usuário aprovou.
- **V8.3.1/V8.3.2:** respiro, tipografia e padronização de botões/cartões.
- **V8.3.3:** seletor de captura com Ajustar/100%/+/- para caber no monitor.
- **V8.3.4:** seleção manual da área jogável a partir de captura do monitor inteiro; resolve recorte, mas expôs desvio entre seleção e cursor.
- **V8.3.5:** correção do cursor físico, validação de janela/área e botão de teste sem clique.
- **V8.3.6:** separação de OCR (imagem) e clique (coordenada física marcada na tela do jogo), editor individual dos pontos e novo template de conferência do Turn in, mantendo cliques reais independentes do template (**pendente teste real no Windows**).

## 7. Checklist de manutenção e regressão

1. Leia este documento e compare `src/engine.ps1` com a última versão estável. Não reescrever o núcleo inteiro para corrigir CSS.
2. Confirme que a interface em português abre e que o menu navega por **Início, Aplicativo, Habilidades, Quests, Sobreposição, Atalhos, Configurações**.
3. Confirme a seleção/fixação do Ruffle e o envio das teclas de 1–5 sem deslocar o foco.
4. Confirme F3 iniciar/pausar/retomar e F2 revalidar, mesmo com a interface minimizada.
5. Execute **testar posição sem clicar** com escala 100%, 125% e 150%, preferencialmente em monitor secundário. Confirme visualmente os dois pontos.
6. Defina área manual do AQW, cadastre uma quest e teste OCR. Verifique no mapa se regiões correspondem à captura correta.
7. Com entrega automática desligada, confira a leitura de contadores `0/6`, `6/6`, `50/10` e múltiplos requisitos.
8. Só depois, teste uma entrega com observação manual e confirme que o contador diminui antes da próxima.
9. Teste movimento/redimensionamento da janela após selecionar área: deve **parar de usar coordenadas antigas**.
10. Teste a abertura sem PowerShell visível e o ícone da barra, sem prometer sucesso se não foi validado no Windows.
11. Verifique o pacote e os recursos embutidos (`app.ico`, `logo.png`, `interface.html`) e execute `tests/test_coordinate_model.py`.
12. Atualize o histórico de versão e **este documento**.

## 8. Build e diagnóstico

Linux com Go 1.23.2 neste ambiente (cross-compilação):

```bash
cd src
GOOS=windows GOARCH=amd64 go build -ldflags='-H windowsgui -s -w' -o ../AQW_Jords_V8_4_0.exe main.go
```

O `.exe` incorpora arquivos via `//go:embed` e extrai-os para diretório temporário ao iniciar. A interface principal exige Windows PowerShell 5.1 e os componentes nativos do Windows. Os logs de inicialização ficam sob `%LOCALAPPDATA%\AQW Jords\Diagnosticos`. A forma atual de distribuição não exige um instalador; pode haver alertas de reputação por ausência de assinatura digital.

**Limitações de verificação:** neste ambiente não há runtime Windows/Ruffle disponível para executar a GUI e testar cliques reais. Compile o Go, execute checagens estáticas e testes geométricos, mas **descreva a build como experimental até a validação pelo usuário**.

## 9. Próximas ações se o desvio persistir

- Pedir captura da área manual configurada, resultado de **Testar posição sem clicar**, resolução e percentual de escala dos dois monitores (se houver), e se o AQW estava maximizado.
- Distinguir falha de coordenada (**desvio calculado em pixels físicos**) de calibração antiga (**cursor chega exatamente ao ponto calculado, mas o elemento esperado está em outra parte do monitor**).
- Se ambos os pontos estiverem deslocados pela mesma distância, revisar origem da região manual. Se o desvio crescer proporcionalmente à posição, revisar escala de DPI e renderização do seletor.
- Não criar cliques de compensação por offset ad hoc sem corrigir o sistema de coordenadas.

**Princípio final:** arquitetura e comportamento validados antes de alterações cosméticas; isolamento de responsabilidades, testes reproduzíveis e documentação atualizada.

## 10. V8.3.6 — Separação obrigatória de OCR e clique ao vivo

### Decisão arquitetural

O usuário explicitou que **a captura de imagem só pode determinar onde o OCR deve ler o contador**, não a posição do mouse para abrir uma quest e concluir. O método antigo inferia `QX/QY` e o clique final pelo centro de retângulos selecionados em screenshots, causando deslocamentos em monitores grandes/com DPI e calibrações históricas.

A partir da V8.3.6, a classe C# `AQWLivePointPicker` exibe uma **janela translúcida sobre o monitor com o AQW visível, sem screenshot**, captura um clique do usuário e lê a posição real por `GetPhysicalCursorPos`. O clique é consumido pela camada e não deve ser encaminhado ao jogo. O usuário pode cancelar com ESC/botão direito. O ponto de tela em pixels físicos é validado contra a região real do jogo (`AQWQuestVision.ClientBounds`) e é salvo como ponto relativo apenas subtraindo a origem física da região; não aplicar zoom nem escalonamento nessa conversão.

- `QX/QY` = clique REAL no nome da quest (relativo ao início da região física do AQW).
- `TPX/TPY` = clique REAL no botão `Turn in!` (mesma convenção).
- `TX/TY/TW/TH` = pequeno retângulo da imagem de **verificação** de presença do `Turn in!`; não determina onde clicar. Preserva a comparação de segurança já validada pela V7.2.
- `Requirements[] {Name,X,Y,W,H}` = regiões OCR **por imagem**, sem alteração; número arbitrário de requisitos.
- O fluxo `Register-QuestVisual` usa primeiro `Pick-AQWArea` (somente requisito OCR), em seguida dois `Pick-AQWLiveClick` (nome e Turn in). `Edit-AQWClickPoints` permite mudar só um ponto, sem mexer nos contadores.
- `Save-AQWTurnInModel` salva a imagem de verificação em um novo arquivo GUID para evitar sobrescrever um arquivo válido em caso de falha. Afasta temporariamente o cursor do botão antes de fotografar, para capturar a aparência sem hover.
- `Save-QuestRecords` persiste `TPX/TPY` e `PointSource`. `Load-QuestRecords` aceita quests antigas sem esses campos: fallback para o centro do retângulo anterior; **recomendação: recadastrar ambos os pontos antigos ao vivo antes de reativar entrega automática.** A UI e o motor continuam com perfil de dados em `%LOCALAPPDATA%\AQWComandos\QuestsV6`.

### Cuidados com bugs futuros

1. **Nunca usar o centro do retângulo OCR como posição para clicar.** O método de clique deve usar `QX/QY` ou `TPX/TPY` exclusivamente.
2. A região física do jogo pode mudar: não gravar coordenadas absolutas permanentes se a janela for redimensionada/movida; validar a âncora.
3. O seletor semitransparente é uma janela real que recebe o clique. Testar no Windows com vários DPIs, monitor secundário com origem negativa e escala de 125%/150%. Se não cobrir o jogo inteiro, o bug fica restrito ao posicionamento do overlay, não ao OCR.
4. O preview de posição sem clicar continua necessário para verificar o resultado antes de ativar o monitor.
5. Não afirmar que `Add-Type` do C# e WinForms foram executados no Linux; o build Go e testes de fonte não cobrem esse runtime.
6. Testes relevantes: `tests/test_coordinate_model.py` e `tests/test_live_click_picker.py`.


## 8. Atualização V8.3.7 — edição de habilidades

**Sintoma:** botão de adicionar, ordem, remoção, ativação e intervalo não respondiam adequadamente na aba Habilidades da V8.3.6.

**Causas no código:**
- `Start.Add_Click` desativava `$grid`, `$add`, `$remove`, `$up`, `$down` e `$keyCombo` enquanto a sequência executava; a ponte HTML recusava alterações quando `$grid.Enabled = $false`.
- `selectedChoice('keyChoice',...)` sincronizava repetidamente a seleção antiga, pois o `<select>` não enviava `selectKey` ao escolher outro valor.
- O bridge chamava `PerformClick` em botões do WinForms cobertos pelo WebBrowser, criando acoplamento desnecessário entre duas interfaces.

**Decisão de arquitetura (preservar nas próximas versões):** o `DataGridView` continua sendo a configuração editável. `activeSequence` é um snapshot usado para enviar teclas. A ponte web altera diretamente as linhas do `DataGridView` e marca `sequenceDirty`. A rotina `Sync-PendingSequence`, chamada **entre envios**, lê e valida a configuração, substituindo o snapshot ativo de forma atômica. Não alterar `BackgroundKeySender.SendVirtualKey`, `PostMessage`, o OCR, os cliques ou os atalhos por causa de mudanças na aba de habilidades.

Se uma sequência ativa ficar sem teclas habilitadas ou com intervalo inválido, interromper de modo seguro, em vez de continuar com a última configuração. Durante a execução, alterações podem aguardar até que o intervalo já iniciado termine. Ao pausar com F3, pode-se editar e a nova configuração passa a valer ao retomar. Ao parar, a próxima inicialização reconstrói a sequência a partir do grid.

**Testes adicionados:** `tests/test_habilidades_v837.py` (contratos estáticos e comparação do motor de quests) e `tests/test_habilidades_ui.py` (navegação e comandos em Chromium com ponte simulada). Para validar de fato, repetir no Windows com Ruffle, verificando a atualização do intervalo, da ordem e das teclas em execução e pausado.

**Cuidado ao avaliar:** JavaScript validado no navegador moderno **não** garante funcionamento do controle `System.Windows.Forms.WebBrowser` (motor legado do Windows). Não afirmar validação de ponta a ponta até executar no computador do usuário.


## 9. Atualização V8.3.8 — protocolo de índices e sincronização da tabela

**Defeito remanescente:** a V8.3.7 permitia adicionar teclas, mas ignorava os comandos `keyDelete|0`, `keyUp|1` e `keyDown|0`. A ponte `Handle-JordsWebCommand` só extraía índices do formato `indice:valor`. Ações com índice isolado chegavam ao motor com `$index = -1` e eram descartadas.

**Regra de protocolo obrigatória:** aceitar ambos os formatos: `indice` para ordem e exclusão, `indice:valor` para duração e ativação. Não mudar unilateralmente o formato de envio da interface ou a interpretação da ponte. Os testes devem verificar o caminho completo, não apenas que o clique emitiu uma mensagem.

**Regra de reordenação:** executar `Move-JordsKeyRow` diretamente pelo índice da linha, trocando todas as células de dados da linha com a vizinha. Não depender de `DataGridView.CurrentCell` ou de seleção na interface clássica, porque o grid pode estar desativado durante a execução. Preservar `sequenceDirty` e o mecanismo de `Sync-PendingSequence` entre envios.

**Regra de sincronização visual:** `keyTime` e `keyEnabled` podem ser disparados no evento de mudança de foco. A ponte responde imediatamente com um estado que atualiza a tabela, mas **não deve reconstruir a tabela no mesmo retorno**, pois isso pode cancelar o clique subsequente do usuário. A V8.3.8 adia uma sincronização de habilidades nesses casos (`pendingSkillEditRefresh`), mantendo a atualização de status.

**Testes:** `tests/test_habilidades_v838.py` e `tests/test_habilidades_integracao_ui_v838.py`, além dos anteriores. Para comprovação no Windows, verificar mover e excluir com a sequência parada, pausada e ativa, e clicar em um botão imediatamente após editar um intervalo. Comparação do OCR, mouse e das quests com V8.3.7 demonstrou ausência de alterações nesses módulos.

**Limitação do ambiente:** os testes locais em Chromium simulam a ponte e os testes PowerShell são estruturais. Não declarar validação real em WinForms/Ruffle até o usuário executar o novo `.exe`.


## 13. V8.3.9 — Auditoria do envio de teclas e diagnóstico

**Relato:** na V8.3.8 a interface de habilidades passou a permitir editar a fila, mas o usuário não observa execução de habilidades no Ruffle. Não há confirmação de que a falha seja do motor ou do jogo.

**Auditoria estática:** a classe `BackgroundKeySender.SendVirtualKey` da V8.3.8 é idêntica à da V8.3.2, usando `PostMessage` para as mensagens `WM_KEYDOWN` e `WM_KEYUP`. A única alteração em `Send-Next` foi sincronizar edições pendentes de fila. O retorno verdadeiro de `PostMessage` significa publicação na fila de mensagens, **não** que o Ruffle recebeu ou executou a habilidade.

**Potencial problema de controle:** na V8.3.8 a interface HTML acionava `start` e `pin` por `PerformClick()` em botões WinForms encobertos pela interface web. Isso não oferece garantia robusta de acionamento em todos os estados de visibilidade/habilitação. V8.3.9 extrai `Start-JordsSequence` e `Pin-JordsTarget` e faz chamadas diretas desde HTML, mantendo os handlers da interface clássica. O comando `stop` também usa `Stop-Autoclick` diretamente.

**Novo teste controlado, aba Habilidades:** `Diagnosticar envio de tecla`. Primeiro cria `AQWKeyMessageProbe`, uma janela de mensagens invisível **do próprio processo**, e publica um KeyDown + KeyUp da primeira tecla ativa, verificando que ambos chegaram ao receptor. Em seguida, somente com confirmação do usuário, publica **uma tecla** no HWND selecionado usando o método escolhido. A interface diferencia: falha local, HWND inválido, PostMessage recusado ou PostMessage aceito sem confirmação da execução no jogo.

**Registro local:** `%LOCALAPPDATA%\AQW Jords\Diagnosticos\envio-teclas-v839.log` registra somente horário, tecla, método, classe e identificador do HWND e resultado do teste; não contém credenciais nem conteúdo de quests.

**Não alterado:** o método Win32 `SendVirtualKey`, OCR, algoritmos de mouse/click, modelo de quests, F2/F3, intervalos da sequência. **Não migrar para SendInput global automaticamente**: isso seria mudança de arquitetura e poderia afetar outros aplicativos.

**Pendência:** teste real no Windows com Artix Launcher + Ruffle. Se o teste local passar e o HWND aceitar mas o jogo não reagir, inspecionar `Componente do aplicativo (avançado)` e método de envio (`KeyDown+KeyUp` vs `Char`) antes de mudar o mecanismo de entrada.


## 14. V8.4.0 — Quarto modo de teclado, opcional e com proteção de foco

**Evidência do usuário:** no desktop, teclas físicas ativam habilidades, mas os três modos `PostMessage` reportam aceitação pelo Windows sem qualquer reação do jogo, em Ruffle e launcher convencional. No notebook, os métodos antigos continuam funcionando. Não há justificativa para removê-los.

**Decisão:** acrescentar `SendInput (AQW em primeiro plano)` como quarto item de `methodCombo` (`SelectedIndex = 3`). Os índices 0, 1 e 2 e o `BackgroundKeySender.SendVirtualKey` permanecem **exatamente inalterados**. O método é **opt-in**, sem elevação automática de permissões e sem ativar outras janelas. A escolha é lida ao iniciar a sequência (trocar métodos requer reiniciar a sequência).

**Implementação:** `BackgroundKeySender.SendForegroundVirtualKey(main, child, vk)` utiliza estrutura Win32 `INPUT` com união explicitamente declarada para preservar o `sizeof(INPUT)` de 40 bytes em x64, `KEYBDINPUT` e scan codes de `MapVirtualKey`. Envia `KeyDown`, aguarda 45 ms e envia `KeyUp`. Se o Windows recusar um dos eventos, para a sequência e apresenta diagnóstico. Para setas, utiliza também `KEYEVENTF_EXTENDEDKEY`. A função `IsTargetForeground` compara raízes `GA_ROOT` de `mainHandle`, componente filho e `GetForegroundWindow()`; não se deve remover esta guarda. O timer aguarda 250 ms quando o AQW não estiver em primeiro plano, sem avançar a fila nem incrementar o contador.

**Diagnóstico:** a prova local `PostMessage` foi preservada e é independente do método escolhido. Se modo 3, após confirmação na janela modal, um temporizador permite até 10 segundos para o usuário ativar o AQW e então envia **uma única tecla**; em caso de expiração, não envia nenhuma. O resultado é registrado em `envio-teclas-v840.log`. Ao parar a sequência ou fechar o aplicativo, os testes pendentes são cancelados.

**Risco conhecido:** `SendInput` atua no fluxo de entrada do SO, não no handle oculto. O teste de foco é feito imediatamente antes de iniciar o pressionamento. Se a janela mudar de foco *durante* os 45 ms, a liberação `KeyUp` ainda é necessária para evitar tecla presa; não é possível garantir atomicamente que o foco nunca mudará entre os dois eventos. Não equiparar sucesso da API a execução da habilidade pelo Ruffle. A UIPI pode impedir injeção em janelas com nível de integridade maior. Referência: https://learn.microsoft.com/pt-br/windows/win32/api/winuser/nf-winuser-sendinput e https://learn.microsoft.com/pt-br/windows/win32/api/winuser/ns-winuser-keybdinput

**Invariantes:** OCR, cliques, calibração, estado das quests, overlay, F2/F3 e `fallback.ps1` não devem ser alterados em reparos desse método. O código `AQWQuestVision` usa outro `SendInput`, exclusivo do mouse de Turn in, e **não deve** ser substituído pelo novo mecanismo de teclado.

**Testes estáticos:** `tests/test_sendinput_v840.py` valida seleção dos 4 modos, proteção de foco, integração do timer, pressionar/soltar, estrutura INPUT em x64, logs, diagnóstico e comparações com baseline do motor do mouse/quests. Os testes antigos continuam verificando habilidades e ponte. **Pendência:** testes funcionais no Windows/launcher e em monitores diversos.
