# AQW Jords V8.3.9 — Envio de teclas e diagnóstico

- Conferida a classe `BackgroundKeySender` contra a V8.3.2: sem alterações no mecanismo de `PostMessage`.
- `Iniciar sequência`, `Fixar janela`, `Parar` e `Atualizar lista` executam funções diretas, sem `PerformClick` em botões encobertos.
- Adicionado **Diagnosticar envio de tecla**, com teste local em janela de mensagens do próprio programa e envio único ao HWND selecionado, mediante confirmação.
- Resultado do diagnóstico exibido na aba Habilidades; registro em `%LOCALAPPDATA%\AQW Jords\Diagnosticos\envio-teclas-v839.log`.
- Status da sequência agora informa **envios aceitos pelo PostMessage**, sem dizer que o Ruffle executou a tecla.
- Preservados `SendVirtualKey`, OCR, quests, cliques, atalho F2/F3 e ordem/milissegundos.

## Limites

Verificações estáticas, integração simulada da interface HTML e compilação cruzada **não equivalem a execução real no Windows**. O usuário deverá executar o diagnóstico para verificar o comportamento do Ruffle.
