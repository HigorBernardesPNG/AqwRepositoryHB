# AQW Jords V8.3.7 — correção da Sequência de Habilidades

## Problema informado
Na V8.3.6, os controles da aba **Sequência de Habilidades** não permitiam editar as teclas, os intervalos, a ativação ou a ordem. A falha era especialmente perceptível com a automação executando ou pausada.

## Causas observadas no código
1. O motor WinForms desativava seu `DataGridView` e os botões de edição assim que a sequência era iniciada. A interface HTML continuava oferecendo os controles, mas a ponte verificava `grid.Enabled` e descartava as ações.
2. O seletor de novas teclas não informava sua seleção ao motor. A sincronização periódica devolvia a seleção antiga do PowerShell.
3. A ponte acionava botões WinForms internos por `PerformClick()` enquanto a interface HTML os cobria. O novo tratamento atua diretamente sobre as linhas do `DataGridView` para evitar dependência da visibilidade desses controles.
4. Erros capturados pela ponte eram armazenados internamente sem retorno visível ao usuário.

## Correções
- Sincronização do seletor de teclas por `selectKey` em `onchange`.
- Adição, remoção, reordenação, ativação e edição do intervalo por ações explícitas da ponte, com validação de **50 a 60.000 ms**.
- Alterações da sequência feitas durante execução ou pausa são aplicadas no **próximo envio**, em um ponto seguro entre mensagens. O timer aguarda o intervalo já iniciado antes de considerar a nova sequência.
- Troca atômica do retrato de execução; se todas as teclas forem desativadas/removidas, o autoclick é interrompido com aviso (não continua enviando a sequência antiga).
- Mensagem de feedback `sequenceInfo` exibida na aba. Falhas na ponte agora também deixam uma mensagem na barra de estado.

## Escopo deliberadamente preservado
- Motor de teclas `BackgroundKeySender.SendVirtualKey` (`PostMessage`).
- Monitor visual OCR, calibração, captura e posições reais dos cliques.
- Entregas das quests, tratamentos de falha e configuração de múltiplos requisitos.
- Atalhos globais F2/F3, painel flutuante e aparência geral da interface.
- Arquivos de configuração do usuário; não foi feita migração ou substituição.

## Validação nesta entrega
- Verificação estática de contratos de edição e não regressão em trechos do motor de quests.
- Teste real do JavaScript no Chromium automatizado com simulador da ponte (seleção, adição, intervalo, ativação, movimentação na lista e exclusão).
- Compilação cruzada do `.exe` para Windows amd64 via Go e verificação de integridade do pacote ZIP.

**Limite:** não há um Windows com Ruffle disponível neste ambiente. A ponte COM/PowerShell e as alterações da sequência em execução ainda precisam ser verificadas no computador do usuário. Os testes do JavaScript usam um simulador da ponte, não o jogo real.
