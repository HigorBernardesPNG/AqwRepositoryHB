# AQW Jords V8.3.8 — correção de exclusão e prioridade de habilidades

## Defeito confirmado na V8.3.7
A interface HTML enviava `keyDelete|0`, `keyUp|1` e `keyDown|0`, usando apenas o índice da linha, mas `Handle-JordsWebCommand` só interpretava índices quando vinham acompanhados de um valor (`0:450`). Por isso, o índice ficava em `-1` e as três ações eram ignoradas. Os testes anteriores verificavam o envio da mensagem pelo navegador, não o seu processamento real na ponte PowerShell.

Foi identificado também um problema de sincronização: ao sair do campo de intervalo e clicar imediatamente em outro botão, a resposta do motor reconstruía a tabela durante a mudança de foco, podendo interromper o clique seguinte.

## Correções
1. A ponte passa a aceitar **ambos os formatos** de parâmetro: índice isolado (`keyDelete|0`) e índice com valor (`keyTime|0:450`). A validação com `TryParse` evita aceitar índice não numérico.
2. As ações **Subir prioridade** e **Descer prioridade** alteram diretamente os valores das linhas por índice, sem depender da seleção/`CurrentCell` do `DataGridView` WinForms, que fica desabilitado durante a execução.
3. **Excluir tecla** confirma a edição anterior antes da remoção e oferece retorno textual caso o índice seja inválido.
4. A interface não recria a tabela no mesmo retorno de sincronização de uma edição de milissegundos/ativação. Isso preserva o próximo clique, feito imediatamente após sair do campo.
5. Ferramentas de ajuda nos botões de prioridade e exclusão.

## Escopo que permanece intacto
- Envio de habilidades e temporização original (`BackgroundKeySender`, `PostMessage`, `Send-Next`).
- OCR, monitor de quests e requisitos múltiplos.
- Captura visual, coordenadas de mouse, calibração e `Turn in!`.
- Atalhos globais F2/F3 e sobreposição flutuante.
- Formatos e localização das configurações do usuário.

## Verificações locais
- Testes de regressão dos comandos, inclusive `keyDelete|0`, `keyUp|1`, `keyDown|0`, e mensagens de intervalo `keyTime|0:450`.
- Testes de interação no Chromium simulando respostas da ponte e conferindo a ordem efetiva das teclas na tela, exclusão de linhas, prioridades de limite e atualização de intervalos seguida de clique.
- Comparação de trechos do motor de OCR, mouse e quests com a V8.3.7.
- Compilação cruzada Go para Windows amd64 e validação estrutural do pacote.

**Limite de validação:** o ambiente de desenvolvimento não executa o Windows PowerShell 5.1/WinForms nem o launcher Ruffle; o comportamento precisa ser conferido no Windows do usuário. O teste no Chromium simula a ponte, não substitui um teste completo com o motor real.

## Teste recomendado no Windows
Com a sequência parada, deixe três teclas (por exemplo, `1`, `2`, `3`). Suba a terceira para a segunda posição, desça a primeira, exclua a segunda e confira se a tabela muda imediatamente. Depois altere um intervalo e clique no botão Subir ou Excluir sem esperar, para validar a sincronização. Por fim, teste com F3 pausado e executando; se a sequência estiver executando, a nova ordem só passa a valer quando chegar o próximo envio.
