"""Contratos verificaveis em Linux para o novo modo SendInput.

Nao afirmam que o launcher reagiu: isso so pode ser testado no Windows real.
"""
import re
import unittest
from pathlib import Path
from ctypes import Structure, Union, c_uint16, c_uint32, c_int32, c_void_p, sizeof

R = Path(__file__).resolve().parents[1]
E = (R/'src/engine.ps1').read_text(encoding='utf-8-sig')
H = (R/'src/interface.html').read_text(encoding='utf-8')
G = (R/'src/main.go').read_text()
BASE=(R/'tests/baseline_v836/engine.ps1').read_text(encoding='utf-8-sig')

class Keybdinput(Structure):
    _fields_ = [('vk', c_uint16), ('scan', c_uint16), ('flags', c_uint32), ('time', c_uint32), ('extra', c_void_p)]
class Mouseinput(Structure):
    _fields_ = [('dx', c_int32), ('dy', c_int32), ('data', c_uint32), ('flags', c_uint32), ('time', c_uint32), ('extra', c_void_p)]
class Hardwareinput(Structure):
    _fields_ = [('msg', c_uint32), ('lo', c_uint16), ('hi', c_uint16)]
class Inputunion(Union):
    _fields_ = [('key', Keybdinput), ('mouse', Mouseinput), ('hardware', Hardwareinput)]
class Input(Structure):
    _fields_=[('type', c_uint32), ('payload', Inputunion)]

class TestModeV840(unittest.TestCase):
    def test_fourth_mode_is_optional_and_default_unchanged(self):
        modes = re.findall(r"\[void\]\$methodCombo.Items.Add\('([^']+)'\)",E)
        self.assertEqual(len(modes),4)
        self.assertEqual(modes[:3],['KeyDown + KeyUp (V2.1)','KeyDown + Char + KeyUp','Char (experimental)'])
        self.assertIn('SendInput (AQW em primeiro plano)',modes[-1])
        self.assertIn('$methodCombo.SelectedIndex = 0',E)
        self.assertIn("'sendMode' {",E)
        self.assertIn('selectedValue(\'sendMode\',s.modes||[],s.modeIndex)',H)

    def test_no_global_key_injection_when_other_app_is_foreground(self):
        self.assertIn('public static bool IsTargetForeground(IntPtr main, IntPtr child)',E)
        self.assertIn('mainRoot == childRoot && GetAncestor(foreground, 2) == mainRoot',E)
        self.assertIn('if (!IsTargetForeground(main, child)) return -2;',E)
        self.assertIn("if ($script:sendMode -eq 3) {",E)
        self.assertIn("$script:timer.Interval = 250",E)
        self.assertIn('Aguardando AQW em primeiro plano',E)
        self.assertIn('if ($result -eq -2)',E)
        self.assertIn('if ($result -ne 2)',E)
        self.assertIn('if ($result -ne 2) {\n            Stop-Autoclick',E)

    def test_key_press_and_key_release_and_older_mode_isolated(self):
        self.assertIn('private static extern uint SendInput(uint count, [In] INPUT[] inputs, int size);',E)
        self.assertIn('public static int SendForegroundVirtualKey(IntPtr main, IntPtr child, int key)',E)
        self.assertIn('SendInput(1, down, size)',E)
        self.assertIn('SendInput(1, up, size)',E)
        self.assertIn('System.Threading.Thread.Sleep(45)',E)
        self.assertIn('KEYEVENTF_SCANCODE',E)
        self.assertIn('KEYEVENTF_KEYUP',E)
        self.assertIn('KEYEVENTF_EXTENDEDKEY',E)
        self.assertIn('if ($script:sendMode -eq 3)',E)
        self.assertIn('[BackgroundKeySender]::SendVirtualKey($script:targetHandle, [int]$step.VK, [int]$script:sendMode)',E)
        p=r'    // mode 0 = KEYDOWN \+ KEYUP[\s\S]*?\n    \}'
        self.assertEqual(re.search(p,E).group(),re.search(p,BASE).group())

    def test_win64_input_layout_matches_win32_input_contract(self):
        # A union precisa ter tamanho MOUSEINPUT, nao apenas KEYBDINPUT.
        self.assertEqual(sizeof(Keybdinput),24)
        self.assertEqual(sizeof(Mouseinput),32)
        self.assertEqual(sizeof(Inputunion),32)
        self.assertEqual(sizeof(Input),40)
        self.assertEqual(Input.payload.offset,8)
        self.assertIn('[StructLayout(LayoutKind.Explicit)]',E)
        self.assertIn('[FieldOffset(0)] public MOUSEINPUT mi;',E)
        self.assertIn('Marshal.SizeOf(typeof(INPUT))',E)

    def test_diagnostic_waits_foreground_and_cancel_path(self):
        self.assertIn('function Stop-JordsForegroundDiagnosis',E)
        self.assertIn('$script:keyTestDeadline = [DateTime]::UtcNow.AddSeconds(10)',E)
        self.assertIn('[BackgroundKeySender]::IsTargetForeground($script:keyTestMain, $script:keyTestHandle)',E)
        self.assertIn('SendForegroundVirtualKey($script:keyTestMain, $script:keyTestHandle, $script:keyTestVK)',E)
        self.assertIn('Stop-JordsForegroundDiagnosis\n    $script:timer.Stop()',E)
        self.assertIn('envio-teclas-v840.log',E)
        self.assertIn('inicio-v840.log',G)

    def test_quest_engine_and_original_mouse_untouched(self):
        for cls in ('AQWQuestVision','AQWLivePointPicker','AQWQuestPicker'):
            p=rf'public (?:static |sealed )?class {cls}(?:\s*:\s*Form)?\s*\{{[\s\S]*?\n\}}'
            a=re.search(p,E); b=re.search(p,BASE)
            self.assertTrue(a and b,cls)
            self.assertEqual(a.group(),b.group(),cls)
        self.assertIn("'editPoints' { Edit-AQWClickPoints }",E)
        self.assertIn("'captureArea' { Set-AQWCaptureRegion }",E)

if __name__=='__main__': unittest.main()
