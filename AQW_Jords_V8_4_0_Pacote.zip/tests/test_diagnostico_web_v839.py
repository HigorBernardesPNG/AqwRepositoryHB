"""Only exercises browser->bridge wiring, not Win32 or Ruffle processing."""
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'src'/'interface.html').read_text(encoding='utf-8')
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1320,'height':900})
    page.set_content(html,wait_until='load')
    page.evaluate("window.__messages=[];Object.defineProperty(window,'external',{configurable:true,value:{Send:(s)=>window.__messages.push(s)}})")
    page.locator('#menuToggle').click()
    page.locator('button[data-page="habilidades"]').click()
    page.get_by_role('button',name='Diagnosticar envio de tecla').click()
    assert 'diagnoseKey|' in page.evaluate('window.__messages'),page.evaluate('window.__messages')
    print('PASSOU: botao Diagnosticar envio encaminha comando para ponte HTML/COM')
    browser.close()
