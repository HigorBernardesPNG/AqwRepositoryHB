from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
PS = (ROOT / 'src/engine.ps1').read_text(encoding='utf-8-sig')
HTML = (ROOT / 'src/interface.html').read_text(encoding='utf-8')

class HabilidadesV837(unittest.TestCase):
    def test_selector_persists_change_via_backend(self):
        self.assertIn('id="keyChoice" onchange="act(\'selectKey\',this.value)"', HTML)
        self.assertIn("'selectKey' {", PS)
        self.assertIn('$keyCombo.SelectedItem = $arg', PS)

    def test_all_actions_dispatch_to_grid_directly(self):
        actions = ['addKey','keyEnabled','keyTime','keyUp','keyDown','keyDelete']
        start = PS.index('function Handle-JordsWebCommand(')
        end = PS.index('function Set-JordsTimingSafe(', start)
        bridge = PS[start:end]
        for action in actions:
            self.assertIn("'" + action + "' {", bridge)
        self.assertNotIn('$grid.Enabled -and', bridge)
        self.assertNotIn('$add.PerformClick()', bridge)
        self.assertNotIn('$up.PerformClick()', bridge)
        self.assertNotIn('$down.PerformClick()', bridge)
        self.assertNotIn('$remove.PerformClick()', bridge)

    def test_active_dispatch_updates_snapshot_only_between_sends(self):
        self.assertIn('function Sync-PendingSequence {', PS)
        self.assertIn('if (-not (Sync-PendingSequence)) { return }', PS)
        self.assertIn('$script:activeSequence = @($updated)', PS)
        self.assertIn('$script:sequenceDirty = $false', PS)
        self.assertIn("Stop-Autoclick 'Sequencia interrompida: nao ha teclas ativas.'", PS)

    def test_quest_visual_capture_and_hotkeys_not_changed(self):
        previous_root = ROOT / 'tests' / 'baseline_v836' / 'engine.ps1'
        if not previous_root.exists():
            self.skipTest('No baseline copy')
        old = previous_root.read_text(encoding='utf-8-sig')
        for marker in ('function Start-AQWOcr', 'function Tick-AQWQuests', 'function Set-OverlayHotkey', 'public static class AQWQuestVision'):
            start = old.index(marker)
            # compare meaningful 600-character window, excluding class definitions changes elsewhere
            self.assertEqual(old[start:start+600], PS[PS.index(marker):PS.index(marker)+600])

    def test_feedback_visible(self):
        self.assertIn('id="skillsInfo"', HTML)
        self.assertIn("setText('skillsInfo',s.sequenceInfo", HTML)
        self.assertIn('sequenceInfo = [string]$script:sequenceEditStatus', PS)

if __name__ == '__main__': unittest.main(verbosity=2)
