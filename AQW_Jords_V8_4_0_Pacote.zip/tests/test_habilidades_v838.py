"""Regressoes precisas do protocolo de comandos da aba de habilidades.

Estes testes analisam o codigo entregue. Sem Windows nao executam PowerShell/WinForms.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (ROOT / 'src' / 'engine.ps1').read_text(encoding='utf-8-sig')
HTML = (ROOT / 'src' / 'interface.html').read_text(encoding='utf-8')
PREVIOUS = (ROOT / 'tests' / 'baseline_v837' / 'engine.ps1').read_text(encoding='utf-8-sig')


def parse_wire_message(encoded_message):
    """Representacao em Python do contrato aceito pela rotina PowerShell.

    O teste de fonte abaixo verifica que ambos os caminhos de analise existem.
    """
    from urllib.parse import unquote
    action, encoded = encoded_message.split('|', 1)
    arg = unquote(encoded)
    idx, value = -1, ''
    match = re.fullmatch(r'([0-9]+):(.*)', arg)
    if match:
        idx, value = int(match.group(1)), match.group(2)
    elif re.fullmatch(r'[0-9]+', arg):
        idx = int(arg)
    return action, idx, value


class TesteCorrecoesV838(unittest.TestCase):
    def test_single_index_messages_that_failed_before(self):
        self.assertEqual(parse_wire_message('keyDelete|0'), ('keyDelete', 0, ''))
        self.assertEqual(parse_wire_message('keyUp|1'), ('keyUp', 1, ''))
        self.assertEqual(parse_wire_message('keyDown|0'), ('keyDown', 0, ''))

    def test_compound_index_value_still_works(self):
        self.assertEqual(parse_wire_message('keyTime|0%3A450'), ('keyTime', 0, '450'))
        self.assertEqual(parse_wire_message('keyEnabled|1%3A0'), ('keyEnabled', 1, '0'))

    def test_power_shell_supports_both_formats(self):
        self.assertIn("if ($arg -match '^([0-9]+):(.*)$')", SCRIPT)
        self.assertIn("elseif ([int]::TryParse($arg, [ref]$parsedIndex))", SCRIPT)
        self.assertIn("$index = $parsedIndex", SCRIPT)
        self.assertNotIn("if ($arg -match '^([0-9]+):(.*)$') { $index = [int]$matches[1];", SCRIPT)
        self.assertIn("if ($arg -match '^([0-9]+):(.*)$') { $index = [int]$matches[1];", PREVIOUS)

    def test_reorder_is_independent_of_disabled_grid_selection(self):
        self.assertIn('function Move-JordsKeyRow([int]$fromIndex, [int]$delta)', SCRIPT)
        self.assertIn('$grid.Rows[$fromIndex].Cells[$column].Value = $grid.Rows[$toIndex].Cells[$column].Value', SCRIPT)
        for action, delta in [('keyUp', '(-1)'), ('keyDown', '1')]:
            body = SCRIPT.split("        '"+action+"' {", 1)[1].split("        'key", 1)[0]
            self.assertIn('Move-JordsKeyRow -fromIndex $index -delta '+delta, body)
            self.assertNotIn('Select-JordsKeyRow $index', body)
        self.assertIn('[void]$grid.EndEdit()\n                $grid.Rows.RemoveAt($index)', SCRIPT)

    def test_single_index_buttons_are_sent_to_bridge(self):
        self.assertIn("act(\\'keyUp\\',\\''+i+", HTML)
        self.assertIn("act(\\'keyDown\\',\\''+i+", HTML)
        self.assertIn("act(\\'keyDelete\\',\\''+i+", HTML)
        for tooltip in ['Subir prioridade', 'Descer prioridade', 'Excluir tecla']:
            self.assertIn(tooltip, HTML)

    def test_engine_quest_and_click_implementation_unchanged(self):
        for marker in ('function Start-AQWOcr', 'function Tick-AQWQuests', 'function Set-OverlayHotkey', 'public static class AQWQuestVision', 'function Edit-AQWClickPoints'):
            start_old = PREVIOUS.index(marker)
            start_new = SCRIPT.index(marker)
            self.assertEqual(PREVIOUS[start_old:start_old+800], SCRIPT[start_new:start_new+800])


if __name__ == '__main__':
    unittest.main(verbosity=2)
