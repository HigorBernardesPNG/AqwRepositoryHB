"""Exercita clique real dos controles no Chromium e ciclo completo de atualizacao.

Simula apenas o retorno da ponte; nao executa API Windows/PowerShell.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
PAGE = (ROOT / 'src' / 'interface.html').read_text(encoding='utf-8')
state = {
    'target': '', 'status': 'Pronto', 'questInfo': '', 'ocrReady': False,
    'monitor': False, 'running': True, 'paused': False,
    'windows': [], 'components': [], 'windowSelected': -1, 'componentSelected': -1,
    'keyChoices': ['1','2','3','R'], 'keyChoice': '1',
    'hotkeys': ['F3'], 'hotkeysQuest': ['F2'], 'hotkeySequence': 'F3', 'hotkeyQuest': 'F2',
    'cornerChoices': ['Superior esquerdo'], 'corner': 'Superior esquerdo',
    'modes': ['KeyDown + KeyUp'], 'modeIndex': 0, 'overlay': False,
    'autoQuest': False, 'similarity': 88,
    'mouseMove': 420, 'mouseHover': 600, 'mousePress': 180, 'mouseAfter': 650,
    'skills': [
        {'enabled': True, 'key': '1', 'ms': '200'},
        {'enabled': True, 'key': '2', 'ms': '300'},
        {'enabled': True, 'key': '3', 'ms': '400'}
    ],
    'quests': [], 'sequenceInfo': 'Pronto'
}
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1320, 'height':900})
    page.set_content(PAGE, wait_until='load')
    page.evaluate('''s => {
        window.__model = s;
        window.__messages = [];
        Object.defineProperty(window, 'external', {configurable:true, value: {
            Send: function(msg) {
                window.__messages.push(msg);
                const split = msg.indexOf('|');
                const action = msg.substring(0,split);
                const arg = decodeURIComponent(msg.substring(split+1));
                // This mock models the acceptance contract of the PowerShell bridge.
                const pair = /^([0-9]+):(.*)$/.exec(arg);
                const simple = /^[0-9]+$/.exec(arg);
                const idx = pair ? Number(pair[1]) : simple ? Number(arg) : -1;
                const data = window.__model.skills;
                if (action === 'keyDown' && idx >= 0 && idx < data.length-1) {
                    const item = data[idx]; data[idx]=data[idx+1]; data[idx+1]=item;
                } else if (action === 'keyUp' && idx > 0 && idx < data.length) {
                    const item = data[idx]; data[idx]=data[idx-1]; data[idx-1]=item;
                } else if (action === 'keyDelete' && idx >= 0 && idx < data.length) {
                    data.splice(idx,1);
                } else if (action === 'keyTime' && pair && idx >= 0 && idx < data.length) {
                    data[idx].ms = pair[2];
                } else if (action === 'keyEnabled' && pair && idx >= 0 && idx < data.length) {
                    data[idx].enabled = pair[2] === '1';
                } else if (action === 'selectKey') {
                    window.__model.keyChoice = arg;
                } else if (action === 'addKey') {
                    data.push({enabled:true,key:arg,ms:'1000'});
                }
                window.__model.sequenceInfo = 'Sequência editada';
                syncState(JSON.stringify(window.__model));
            }
        }});
        syncState(JSON.stringify(window.__model));
    }''',state)
    page.locator('#menuToggle').click()
    page.locator('button[data-page="habilidades"]').click()
    assert page.locator('#page-habilidades').is_visible()

    def rows():
        return page.locator('#skillsTable td .keycap').all_text_contents()
    assert rows() == ['1','2','3'], rows()

    # Changing the order requires reading a bare numeric index (0, 1, 2)
    page.locator('#skillsTable tr').nth(0).get_by_title('Descer prioridade').click()
    assert rows() == ['2','1','3'], rows()
    page.locator('#skillsTable tr').nth(2).get_by_title('Subir prioridade').click()
    assert rows() == ['2','3','1'], rows()

    # Removing the middle item must change both state and rendered table.
    page.locator('#skillsTable tr').nth(1).get_by_title('Excluir tecla').click()
    assert rows() == ['2','1'], rows()

    page.locator('#skillsTable tr').nth(1).locator('input.num').fill('875')
    page.locator('#skillsTable tr').nth(1).locator('input.num').dispatch_event('change')
    assert page.locator('#skillsTable tr').nth(1).locator('input.num').input_value() == '875'

    page.locator('#skillsTable tr').nth(0).get_by_title('Subir prioridade').click()
    assert rows() == ['2','1']  # boundary check: first cannot go up

    page.locator('#keyChoice').select_option('R')
    page.get_by_role('button', name='Adicionar à sequência').click()
    assert rows() == ['2','1','R'], rows()
    page.locator('#skillsTable tr').nth(2).get_by_title('Excluir tecla').click()
    assert rows() == ['2','1'], rows()

    messages = page.evaluate('window.__messages')
    for expected in ['keyDown|0','keyUp|2','keyDelete|1','keyTime|1%3A875','keyUp|0','keyDelete|2']:
        assert expected in messages, (expected,messages)
    assert page.locator('#skillsInfo').inner_text() == 'Sequência editada'
    print('PASSOU: ordem, exclusao, limites, intervalos, adicionar e sincronizar em tempo real')
    browser.close()
