
var state={}, lastSkills='', lastQuests='', activePage='inicio', lastNames='', lastWindows='', ready=false, pendingSkillEditRefresh=0;
function el(id){return document.getElementById(id)}
function val(id){var e=el(id);return e?e.value:''}
function esc(s){return String(s===undefined||s===null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;')}
function attr(s){return esc(s)}
function act(a,v){if(a==='keyTime'||a==='keyEnabled'){pendingSkillEditRefresh=1}try{window.external.Send(a+'|'+encodeURIComponent(String(v===undefined?'':v)))}catch(e){notify('A comunicação com o aplicativo não respondeu.') }}
function notify(message){var n=el('toast');n.innerHTML=esc(message);n.style.display='block';setTimeout(function(){n.style.display='none'},3500)}
function toggleMenu(){var m=el('menuPanel'),b=el('menuToggle');var open=m.className.indexOf('open')>=0;m.className=open?'menu-panel':'menu-panel open';b.setAttribute('aria-expanded',open?'false':'true')}
function closeMenu(){el('menuPanel').className='menu-panel';el('menuToggle').setAttribute('aria-expanded','false')}
function go(id){closeMenu();var p=document.querySelectorAll('.page'),n=document.querySelectorAll('.nav-item');for(var i=0;i<p.length;i++){p[i].className=p[i].id==='page-'+id?'page active':'page'}for(var j=0;j<n.length;j++){n[j].className=n[j].getAttribute('data-page')===id?'nav-item active':'nav-item'}activePage=id}
var nav=document.querySelectorAll('.nav-item');for(var i=0;i<nav.length;i++){nav[i].onclick=function(){go(this.getAttribute('data-page'))}}
function setText(id,s){if(el(id))el(id).innerText=String(s===undefined?'':s)}
function selectedValue(id,items,selected){var e=el(id);if(!e||document.activeElement===e)return;var key=JSON.stringify(items)+'|'+selected;if(e.getAttribute('data-key')===key)return;e.innerHTML='';for(var i=0;i<items.length;i++){var o=document.createElement('option');o.value=String(i);o.text=items[i];e.add(o)}e.value=String(selected);e.setAttribute('data-key',key)}
function selectedChoice(id,items,chosen){var e=el(id);if(!e||document.activeElement===e)return;var key=JSON.stringify(items);if(e.getAttribute('data-key')!==key){e.innerHTML='';for(var i=0;i<items.length;i++){var o=document.createElement('option');o.value=items[i];o.text=items[i];e.add(o)}e.setAttribute('data-key',key)}e.value=chosen}
function setChecked(id,v){var e=el(id);if(e && document.activeElement!==e)e.checked=!!v}
function setInput(id,v){var e=el(id);if(e && document.activeElement!==e && e.value!==String(v))e.value=String(v)}
function iconState(t){t=String(t||'').toLowerCase();if(t.indexOf('pronta')>=0||t.indexOf('confirmada')>=0||t.indexOf('completo')>=0)return 'good';if(t.indexOf('falha')>=0||t.indexOf('erro')>=0||t.indexOf('recupera')>=0)return 'bad';return 'wait'}
function renderReqs(q){var a=q.requirements||[];if(!a.length)return '<span class="req-hint">Aguardando leitura</span>';var h='';for(var i=0;i<a.length;i++){var r=a[i],s=iconState(r.status);if(r.status==='Incompleto')s='wait';h+='<span class="tag req-chip '+s+'">'+esc(r.name)+' &nbsp;'+esc(r.value||'—')+'</span>'}return h}
function renderQuestRows(a,id,dash){var h='';for(var i=0;i<a.length;i++){var q=a[i],s=iconState(q.status);h+='<tr'+(q.selected?' class="selected"':'')+'>';
if(!dash)h+='<td><input class="quest-check" type="checkbox" '+(q.enabled?'checked':'')+' onchange="act(\'questEnabled\',\''+i+':\'+(this.checked?\'1\':\'0\'))" /></td>';
h+='<td>'+(dash?'<button class="rowlink" onclick="go(\'quests\');act(\'selectQuest\',\''+i+'\')">'+esc(q.name)+'</button>':'<button class="rowlink" onclick="act(\'selectQuest\',\''+i+'\')">'+esc(q.name)+'</button>')+'</td>';
h+='<td>'+renderReqs(q)+'</td><td><span class="tag '+s+'">'+esc(q.status)+'</span></td><td>'+esc(q.turns)+'</td></tr>'}
if(!a.length)h='<tr><td colspan="5" class="empty">Nenhuma quest cadastrada. Calibre uma quest para começar.</td></tr>';el(id).innerHTML=h}
function renderSkills(a){var h='',quick='';for(var i=0;i<a.length;i++){var k=a[i],ch=esc(k.key);h+='<tr><td><input class="chk" type="checkbox" '+(k.enabled?'checked':'')+' onchange="act(\'keyEnabled\',\''+i+':\'+(this.checked?\'1\':\'0\'))" /></td><td>'+(i+1)+'</td><td><span class="keycap">'+ch+'</span></td><td><input class="num" type="number" min="50" max="60000" value="'+esc(k.ms)+'" onchange="act(\'keyTime\',\''+i+':\'+this.value)" /></td><td><div class="btns"><button class="btn mini" title="Subir prioridade" onclick="act(\'keyUp\',\''+i+'\')"><span class="ui-icon icon-arrow-up"></span></button><button class="btn mini" title="Descer prioridade" onclick="act(\'keyDown\',\''+i+'\')"><span class="ui-icon icon-arrow-down"></span></button><button class="btn mini danger" title="Excluir tecla" onclick="act(\'keyDelete\',\''+i+'\')"><span class="ui-icon icon-trash"></span></button></div></td></tr>';quick+='<span class="tag '+(k.enabled?'dark':'')+'"><b>'+ch+'</b> &nbsp;'+esc(k.ms)+' ms</span>'}
el('skillsTable').innerHTML=h||'<tr><td colspan="5" class="empty">Nenhuma tecla configurada.</td></tr>';el('dashboardKeys').innerHTML=quick||'Nenhuma tecla adicionada.'}
function preview(a){var q=null;for(var i=0;i<a.length;i++)if(a[i].enabled){q=a[i];break};if(!q)return '<h4>Monitor de requisitos</h4><div class="one">Nenhuma quest ativa</div>';var h='<h4>'+esc(q.name)+'</h4>';var r=q.requirements||[];if(!r.length)h+='<div class="one">Aguardando primeira leitura...</div>';for(var i=0;i<r.length;i++){var st=iconState(r[i].status);if(r[i].status==='Incompleto')st='wait';h+='<div class="one '+st+'">'+(st==='good'?'<span class="ui-icon icon-circle-check"></span>':st==='bad'?'<span class="ui-icon icon-x"></span>':'<span class="ui-icon icon-refresh-cw"></span>')+' &nbsp;'+esc(r[i].name)+': '+esc(r[i].value||'—')+'</div>'}return h}
function syncState(j){try{var s=JSON.parse(j);state=s;ready=true;
setText('pillDestino',s.target?'●  '+s.target:'●  Destino não fixado');el('pillDestino').className='pill '+(s.target?'ok':'');
setText('pillOCR',s.ocrReady?'●  OCR: pronto':'●  OCR: aguardando');el('pillOCR').className='pill '+(s.ocrReady?'ok':'');
setText('pillMonitor',s.monitor?'●  Monitor: ativo':'●  Monitor: parado');el('pillMonitor').className='pill '+(s.monitor?'ok':'');
setText('pillTeclas',s.running?'●  Habilidades: executando':s.paused?'●  Habilidades: pausadas':'●  Habilidades: paradas');el('pillTeclas').className='pill '+(s.running?'ok':s.paused?'warn':'');
setText('statusHome',s.status||'Pronto');setText('windowInfo',s.target?'Janela fixada: '+s.target:'Nenhuma janela fixada');setText('questInfo',s.questInfo||'Aguardando monitoramento');setText('skillsInfo',s.sequenceInfo||'Pronto para editar a sequência.');
selectedValue('windowSelect',s.windows||[],s.windowSelected);selectedValue('componentSelect',s.components||[],s.componentSelected);
selectedChoice('keyChoice',s.keyChoices||[],s.keyChoice);
selectedChoice('hotkeySequence',s.hotkeys||[],s.hotkeySequence);selectedChoice('hotkeyQuest',s.hotkeysQuest||[],s.hotkeyQuest);
selectedChoice('overlayCorner',s.cornerChoices||[],s.corner);
selectedValue('sendMode',s.modes||[],s.modeIndex);
setChecked('autoQuest',s.autoQuest);setChecked('overlayEnabled',s.overlay);
setInput('similarity',s.similarity);setInput('mouseMove',s.mouseMove);setInput('mouseHover',s.mouseHover);setInput('mousePress',s.mousePress);setInput('mouseAfter',s.mouseAfter);
setText('hotkeyHomeF3',s.hotkeySequence||'F3');setText('hotkeyHomeF2',s.hotkeyQuest||'F2');
setText('monitorToggle',s.monitor?'Pausar monitor':'Ativar monitor');
var qh=JSON.stringify(s.quests||[]);if(qh!==lastQuests){lastQuests=qh;renderQuestRows(s.quests||[],'questTable',false);renderQuestRows(s.quests||[],'dashboardQuests',true);var html=preview(s.quests||[]);el('previewHome').innerHTML=html;el('previewOverlay').innerHTML=html;el('previewQuests').innerHTML=html}
var kh=JSON.stringify(s.skills||[]);if(pendingSkillEditRefresh>0){pendingSkillEditRefresh--}else if(kh!==lastSkills && document.activeElement.tagName!=='INPUT'){lastSkills=kh;renderSkills(s.skills||[])}
}catch(e){notify('Erro ao atualizar a interface: '+e.message)}}
window.onload=function(){act('ready')};
