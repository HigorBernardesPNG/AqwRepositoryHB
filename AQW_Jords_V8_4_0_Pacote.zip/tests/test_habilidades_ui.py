from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
url=(ROOT/'src/interface.html').as_uri()

with sync_playwright() as p:
    b=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=b.new_page(viewport={'width':1320,'height':900})
    page.add_init_script('''
        window.__commands=[];
        Object.defineProperty(window,'external',{configurable:true,value:{Send:function(v){window.__commands.push(v)}}});
    ''')
    page.set_content((ROOT/'src/interface.html').read_text(encoding='utf-8'), wait_until='load')
    page.evaluate("window.__commands=[]; Object.defineProperty(window,'external',{configurable:true,value:{Send:function(v){window.__commands.push(v)}}});")
    state=dict(
       target='',status='Pronto',questInfo='',ocrReady=False,monitor=False,running=False,paused=False,
       windows=[], components=[],windowSelected=-1,componentSelected=-1,
       keyChoices=['1','2','3','4','5','R','F4'],keyChoice='1',
       hotkeys=['F3'],hotkeysQuest=['F2'],hotkeySequence='F3',hotkeyQuest='F2',
       cornerChoices=['Superior esquerdo'],corner='Superior esquerdo',modes=['KeyDown + KeyUp'],modeIndex=0,
       overlay=False,autoQuest=False,similarity=88,mouseMove=420,mouseHover=600,mousePress=180,mouseAfter=650,
       skills=[{'enabled':True,'key':'1','ms':'200'},{'enabled':True,'key':'2','ms':'300'}],quests=[],
       sequenceInfo='Pronto para editar')
    page.evaluate('(s)=>syncState(JSON.stringify(s))',state)
    page.locator('#menuToggle').click()
    page.locator('button[data-page="habilidades"]').click()
    assert page.locator('#page-habilidades').is_visible()
    assert page.locator('#skillsTable tr').count()==2
    page.locator('#keyChoice').select_option('R')
    cmds=page.evaluate('window.__commands')
    assert 'selectKey|R' in cmds,cmds
    # simulate the motor acknowledging the new selected key in its periodic state
    state['keyChoice']='R'
    for _ in range(3): page.evaluate('(s)=>syncState(JSON.stringify(s))',state)
    assert page.locator('#keyChoice').input_value()=='R'
    page.get_by_role('button',name='Adicionar à sequência').click()
    assert 'addKey|R' in page.evaluate('window.__commands')
    page.locator('#skillsTable input.num').first.fill('450')
    page.locator('#skillsTable input.num').first.dispatch_event('change')
    page.locator('#skillsTable input.chk').first.uncheck()
    page.locator('#skillsTable .btn.mini').nth(1).click() # down
    page.locator('#skillsTable .btn.mini').nth(2).click() # delete
    cmds=page.evaluate('window.__commands')
    for cmd in ['keyTime|0%3A450','keyEnabled|0%3A0','keyDown|0','keyDelete|0']:
        assert cmd in cmds,(cmd,cmds)
    # stale data from the motor should not overwrite input while editing (user typing)
    state['skills'][0]['ms']='200'
    page.locator('#skillsTable input.num').first.focus()
    page.locator('#skillsTable input.num').first.fill('560')
    page.evaluate('(s)=>syncState(JSON.stringify(s))',state)
    assert page.locator('#skillsTable input.num').first.input_value()=='560'
    print('BROWSER TEST PASS: seleção, adição, intervalos, marcação, ordem, exclusão, proteção da edição durante sincronização')
    b.close()
