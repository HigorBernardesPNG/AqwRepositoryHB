"""Validation of wiring and preservation of old key engine; Windows delivery needs live test."""
from pathlib import Path
import unittest
import re
ROOT=Path(__file__).resolve().parents[1]
S=(ROOT/'src'/'engine.ps1').read_text(encoding='utf-8-sig')
H=(ROOT/'src'/'interface.html').read_text(encoding='utf-8')
B=(ROOT/'tests'/'baseline_v836'/'engine.ps1').read_text(encoding='utf-8-sig')

class EnvioV839(unittest.TestCase):
    def test_original_postmessage_sender_preserved_identically(self):
        # V8.4.0 acrescenta metodos novos na classe, sem alterar SendVirtualKey.
        p=r'    // mode 0 = KEYDOWN \+ KEYUP[\s\S]*?\n    \}'
        self.assertEqual(re.search(p,S).group(),re.search(p,B).group())
    def test_send_loop_uses_selected_vk_and_mode(self):
        self.assertIn('[BackgroundKeySender]::SendVirtualKey($script:targetHandle, [int]$step.VK, [int]$script:sendMode)',S)
        self.assertIn('$script:timer.Add_Tick({ Send-Next })',S)
        self.assertIn('$script:timer.Start()',S)
    def test_start_and_pin_directly_dispatched(self):
        self.assertIn("'start' { if (-not $script:isRunning) { Start-JordsSequence } }",S)
        self.assertIn("'pin' { Pin-JordsTarget }",S)
        self.assertIn('$start.Add_Click({ Start-JordsSequence })',S)
        self.assertIn('$pin.Add_Click({ Pin-JordsTarget })',S)
        self.assertNotIn('$start.PerformClick()',S)
        self.assertNotIn('$pin.PerformClick()',S)
    def test_diag_probe_no_system_input_in_key_sender(self):
        self.assertIn('public sealed class AQWKeyMessageProbe : NativeWindow, IDisposable',S)
        self.assertIn('if (m.Msg == 0x0100) Downs++',S)
        self.assertIn('else if (m.Msg == 0x0101) Ups++',S)
        self.assertIn('$probe.Downs -eq 1 -and $probe.Ups -eq 1',S)
        self.assertIn('if ($answer -ne [System.Windows.Forms.DialogResult]::Yes)',S)
        self.assertIn('$accepted = [BackgroundKeySender]::SendVirtualKey($testHandle, $keyVK, $mode)',S)
        self.assertIn('o Windows nao confirma o processamento',S)
    def test_diag_web_ui(self):
        self.assertIn("act('diagnoseKey')",H)
        self.assertIn("'diagnoseKey' { Test-JordsKeySending }",S)
        self.assertIn('keyDiagnostic = [string]$script:keyDiagnosticStatus',S)
        self.assertIn("setText('keyDiagnostic',s.keyDiagnostic",H)
    def test_no_quest_mouse_changes(self):
        p=r'public static class AQWQuestVision\s*\{[\s\S]*?\n\}'
        self.assertEqual(re.search(p,S).group(),re.search(p,B).group())

if __name__=='__main__': unittest.main()
