# AQW Jords V8.4.0 — Novo método de envio de habilidades

## Objetivo

Adicionar uma alternativa de teclado para o computador em que o AQW recebe mensagens por `PostMessage`, mas não executa as habilidades. **Preservar os três métodos anteriores**, que continuam úteis no notebook do usuário.

## Alterações

- **Quarto método:** `SendInput (AQW em primeiro plano)` em Configurações → Método de entrada.
- O novo método utiliza eventos Win32 `KEYEVENTF_SCANCODE` para simular pressão e soltura das teclas, com aproximadamente **45 ms de pressionamento**.
- Validação do foco antes de cada envio: tanto a janela fixada quanto o componente selecionado devem pertencer à janela **atualmente em primeiro plano**. Caso contrário, o contador não avança e o temporizador verifica novamente após 250 ms.
- O botão **Diagnosticar envio de tecla** inclui um teste específico do novo método: após confirmação, há até **10 segundos para colocar o AQW em primeiro plano**; o teste envia **uma única tecla** se o destino estiver corretamente ativo. Falha por ausência de foco não causa envio a outro programa.
- `SendInput` informa quantas teclas foram inseridas no fluxo do Windows, **não** se o Ruffle realmente executou as habilidades.
- Os três modos `KeyDown + KeyUp`, `KeyDown + Char + KeyUp` e `Char` preservam a implementação e a seleção padrão (modo 0).
- Arquivos de diagnóstico da versão em `%LOCALAPPDATA%\AQW Jords\Diagnosticos\inicio-v840.log` e `envio-teclas-v840.log`.
- Texto explicativo atualizado nas abas Habilidades e Configurações.

## Permanecem inalterados

- OCR e reconhecimento de múltiplos requisitos.
- Coordenadas físicas dos cliques, calibração ao vivo, entrega de quests e monitor de leitura.
- F2/F3, editor de habilidades, tempos individuais, ordem e exclusão.
- Lógica exata de `BackgroundKeySender.SendVirtualKey` dos modos `PostMessage`.
- `src/fallback.ps1` e identidade visual.

## Limitações conhecidas

- `SendInput` usa o **jogo em primeiro plano** e **não** funciona com o AQW minimizado ou atrás de outra janela. O aplicativo pode ficar minimizado, desde que o AQW esteja em foco.
- A operação pode ser restringida por integridade/permissões (UIPI); a aplicação não tenta elevar permissões automaticamente nem contornar bloqueios.
- Após selecionar outro método, **pare e inicie novamente a sequência** para aplicar a mudança.
- Pressionamentos reais e recebimento por Ruffle/launcher não foram testados em Windows neste ambiente de compilação Linux. A confirmação dependerá de teste no desktop do usuário.

## Teste de regressão

1. Fixar a janela correta do AQW e selecionar `SendInput (AQW em primeiro plano)`.
2. Adicionar somente `1` com intervalo de 1000 ms; iniciar pelo AQW Jords e voltar ao jogo.
3. Confirmar que a habilidade é executada; alternar para outra janela e observar se a contagem para.
4. Voltar ao AQW e verificar retomada automática.
5. Executar **Diagnosticar envio de tecla** parado; confirmar e retornar ao AQW em até 10 segundos.
6. Repetir no notebook com modo original `KeyDown + KeyUp` e comprovar funcionamento anterior.
