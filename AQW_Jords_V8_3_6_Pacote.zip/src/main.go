package main

import (
    "embed"
    "errors"
    "fmt"
    "os"
    "os/exec"
    "path/filepath"
    "strings"
    "syscall"
    "time"
    "unsafe"
)

//go:embed engine.ps1 fallback.ps1 app.ico interface.html logo.png
var embedded embed.FS

var user32 = syscall.NewLazyDLL("user32.dll")
var messageBoxW = user32.NewProc("MessageBoxW")

func messageBox(text, title string, flags uintptr) {
    tp, _ := syscall.UTF16PtrFromString(text)
    cp, _ := syscall.UTF16PtrFromString(title)
    messageBoxW.Call(0, uintptr(unsafe.Pointer(tp)), uintptr(unsafe.Pointer(cp)), flags)
}

func readTail(path string, max int) string {
    b, err := os.ReadFile(path)
    if err != nil { return "Nao foi possivel ler o arquivo de diagnostico: " + err.Error() }
    if len(b) > max { b = b[len(b)-max:] }
    v := strings.TrimSpace(string(b))
    if v == "" { return "Nenhuma mensagem no log do PowerShell." }
    return v
}

func runChild(scriptName, tempDir, logPath, iconPath, hostExe string) error {
    marker := filepath.Join(tempDir, scriptName+".interface-aberta")
    _ = os.Remove(marker)
    script := filepath.Join(tempDir, scriptName+".ps1")
    data, err := embedded.ReadFile(scriptName+".ps1")
    if err != nil { return fmt.Errorf("falha ao ler codigo %s: %w", scriptName, err) }
    if err := os.WriteFile(script,data,0600); err != nil { return err }

    log, err := os.OpenFile(logPath,os.O_CREATE|os.O_TRUNC|os.O_WRONLY,0600)
    if err != nil { return err }
    defer log.Close()
    _, _ = fmt.Fprintf(log,"AQW - %s\nInicio: %s\nWindows PowerShell 5.1\n\n",scriptName,time.Now().Format(time.RFC3339))
    _ = log.Sync()

    command := exec.Command("powershell.exe", "-NoLogo", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", script)
    command.Env = append(os.Environ(), "AQW_READY_FILE="+marker,"AQW_ICON_FILE="+iconPath,"AQW_HOST_EXE="+hostExe, "AQW_JORDS_HTML_FILE="+filepath.Join(tempDir,"interface.html"), "AQW_JORDS_LOGO_FILE="+filepath.Join(tempDir,"logo.png"))
    command.Stdout = log
    command.Stderr = log
    // CRITICAL: do not set HideWindow=true. It can suppress the WinForms window
    // along with the PowerShell host. CREATE_NO_WINDOW only hides the console.
    command.SysProcAttr = &syscall.SysProcAttr{CreationFlags: 0x08000000}
    if err := command.Start(); err != nil { return fmt.Errorf("falha ao iniciar PowerShell: %w",err) }

    finished := make(chan error,1)
    go func(){finished <- command.Wait()}()
    ticker := time.NewTicker(250*time.Millisecond)
    startupTimeout := time.NewTimer(28*time.Second)
    defer ticker.Stop()
    defer startupTimeout.Stop()

    for {
        select {
        case err := <- finished:
            if _, markerErr := os.Stat(marker); markerErr == nil { return err }
            _ = log.Sync()
            return fmt.Errorf("PowerShell encerrou antes de exibir a interface (%v).\n%s",err,readTail(logPath,2500))
        case <- ticker.C:
            if _, err := os.Stat(marker); err == nil {
                // A janela WinForms sinalizou seu proprio evento Shown.
                // Aguarda o fechamento para manter script e icone disponiveis.
                err := <- finished
                // A janela abriu, portanto fechar depois nao aciona fallback.
                _ = err
                return nil
            }
        case <- startupTimeout.C:
            _ = command.Process.Kill()
            <-finished
            _ = log.Sync()
            return fmt.Errorf("A interface nao confirmou abertura em 28 segundos.\n%s",readTail(logPath,2500))
        }
    }
}

func main() {
    tempDir, err := os.MkdirTemp("", "AQW-JORDS-V834-")
    if err != nil {messageBox(err.Error(),"AQW - erro ao iniciar",0x10); return}
    defer os.RemoveAll(tempDir)
    icon, err := embedded.ReadFile("app.ico")
    if err != nil {messageBox(err.Error(),"AQW - erro no icone",0x10);return}
    iconPath := filepath.Join(tempDir,"app.ico")
    if err := os.WriteFile(iconPath,icon,0600);err!=nil {messageBox(err.Error(),"AQW - erro no icone",0x10);return}
    for _, asset := range []string{"interface.html", "logo.png"} {
        data, err := embedded.ReadFile(asset)
        if err != nil { messageBox(err.Error(), "AQW Jords - recursos", 0x10); return }
        if err := os.WriteFile(filepath.Join(tempDir,asset),data,0600); err != nil { messageBox(err.Error(), "AQW Jords - recursos", 0x10); return }
    }
    hostExe,_ := os.Executable()
    logsRoot := os.Getenv("LOCALAPPDATA")
    if logsRoot == "" {logsRoot=os.TempDir()}
    logsRoot = filepath.Join(logsRoot,"AQW Jords","Diagnosticos")
    if err:=os.MkdirAll(logsRoot,0700);err!=nil {logsRoot=tempDir}
    primaryLog := filepath.Join(logsRoot,"inicio-v834.log")
    if err:=runChild("engine",tempDir,primaryLog,iconPath,hostExe);err==nil {return} else {
        messageBox("A interface nao iniciou corretamente.\n\nO motor classico sera iniciado para preservar as funcoes anteriores. Diagnostico:\n"+primaryLog+"\n\nMotivo:\n"+err.Error(),"AQW Jords - modo de compatibilidade",0x30)
    }
    fallbackLog := filepath.Join(logsRoot,"inicio-v6-compatibilidade.log")
    if err:=runChild("fallback",tempDir,fallbackLog,iconPath,hostExe);err!=nil {
        messageBox("Nenhuma das interfaces conseguiu iniciar.\n\nDetalhes:\n"+err.Error()+"\n\nLogs:\n"+primaryLog+"\n"+fallbackLog,"AQW - erro de inicializacao",0x10)
    }
}

var _ = errors.New
