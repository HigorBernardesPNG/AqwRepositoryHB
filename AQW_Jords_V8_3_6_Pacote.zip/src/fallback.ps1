# AQW - Comandos Direcionados V6 | Windows PowerShell 5.1
# Portatil: mensagens de janela, nunca injeta teclas no teclado global.
# Observacao: PostMessage enfileira mensagens; o aplicativo de destino pode ignora-las.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$source = @'
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

public static class BackgroundKeySender
{
    private const uint WM_KEYDOWN = 0x0100;
    private const uint WM_KEYUP   = 0x0101;
    private const uint WM_CHAR    = 0x0102;

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool PostMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool IsWindow(IntPtr hWnd);

    private delegate bool EnumWindowCallback(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumChildWindows(IntPtr hWnd, EnumWindowCallback callback, IntPtr data);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr hWnd, StringBuilder buffer, int maxCount);

    [DllImport("user32.dll")]
    private static extern uint MapVirtualKey(uint code, uint mapType);

    public static string GetWindowClass(IntPtr hWnd)
    {
        StringBuilder name = new StringBuilder(256);
        GetClassName(hWnd, name, name.Capacity);
        return name.ToString();
    }

    public static IntPtr[] GetChildren(IntPtr hWnd)
    {
        List<IntPtr> windows = new List<IntPtr>();
        EnumWindowCallback callback = delegate (IntPtr child, IntPtr data)
        {
            windows.Add(child);
            return windows.Count < 60;
        };
        EnumChildWindows(hWnd, callback, IntPtr.Zero);
        return windows.ToArray();
    }

    // mode 0 = KEYDOWN + KEYUP (compatibilidade V2.1)
    // mode 1 = KEYDOWN + CHAR (se aplicavel) + KEYUP
    // mode 2 = CHAR (se aplicavel) ou KEYDOWN + KEYUP
    public static bool SendVirtualKey(IntPtr target, int key, int mode)
    {
        if (!IsWindow(target) || key < 1 || key > 255) return false;
        uint scan = MapVirtualKey((uint)key, 0);
        long downInfo = 1L | ((long)scan << 16);
        long upInfo = downInfo | (1L << 30) | (1L << 31);
        int charCode = 0;
        if (key >= 0x30 && key <= 0x39) charCode = key;
        else if (key >= 0x41 && key <= 0x5A) charCode = key + 32;
        else if (key == 0x20 || key == 0x09 || key == 0x0D) charCode = key;

        if (mode == 2 && charCode != 0)
            return PostMessage(target, WM_CHAR, new IntPtr(charCode), new IntPtr(downInfo));

        bool down = PostMessage(target, WM_KEYDOWN, new IntPtr(key), new IntPtr(downInfo));
        bool middle = true;
        if (mode == 1 && charCode != 0)
            middle = PostMessage(target, WM_CHAR, new IntPtr(charCode), new IntPtr(downInfo));
        bool up = PostMessage(target, WM_KEYUP, new IntPtr(key), new IntPtr(upInfo));
        return down && middle && up;
    }
}

public static class AQWVisuals
{
    public static void Round(Control control, int radius)
    {
        if (control.Width <= 0 || control.Height <= 0) return;
        int r = Math.Min(radius * 2, Math.Min(control.Width, control.Height));
        using (GraphicsPath path = new GraphicsPath())
        {
            path.AddArc(0, 0, r, r, 180, 90);
            path.AddArc(control.Width - r - 1, 0, r, r, 270, 90);
            path.AddArc(control.Width - r - 1, control.Height - r - 1, r, r, 0, 90);
            path.AddArc(0, control.Height - r - 1, r, r, 90, 90);
            path.CloseFigure();
            Region old = control.Region;
            control.Region = new Region(path);
            if (old != null) old.Dispose();
        }
    }
}

// A dedicated message-only window receives system-wide WM_HOTKEY messages.
// No keyboard hook or simulated global keypresses are used.
public sealed class AQWHotkeyReceiver : NativeWindow, IDisposable
{
    private const int WmHotkey = 0x0312;
    private const int HotkeyId = 0x2A71;
    private const uint ModNoRepeat = 0x4000;
    private bool registered;
    private int previousVk;
    private uint previousMods;

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint vk);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    public event EventHandler HotkeyPressed;

    public AQWHotkeyReceiver()
    {
        CreateParams cp = new CreateParams();
        cp.Caption = "AQW Atalho Global";
        cp.Parent = new IntPtr(-3); // HWND_MESSAGE: no taskbar entry or visible window.
        CreateHandle(cp);
    }

    public bool ChangeHotkey(int virtualKey, uint modifiers)
    {
        int oldVk = previousVk;
        uint oldMods = previousMods;
        if (registered)
        {
            UnregisterHotKey(Handle, HotkeyId);
            registered = false;
        }
        if (RegisterHotKey(Handle, HotkeyId, modifiers | ModNoRepeat, (uint)virtualKey))
        {
            registered = true;
            previousVk = virtualKey;
            previousMods = modifiers;
            return true;
        }
        // If the new key is unavailable, restore the previous registration.
        if (oldVk != 0 && RegisterHotKey(Handle, HotkeyId, oldMods | ModNoRepeat, (uint)oldVk))
        {
            registered = true;
            previousVk = oldVk;
            previousMods = oldMods;
        }
        return false;
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WmHotkey && m.WParam.ToInt32() == HotkeyId)
        {
            EventHandler callback = HotkeyPressed;
            if (callback != null) callback(this, EventArgs.Empty);
            return;
        }
        base.WndProc(ref m);
    }

    public void Dispose()
    {
        if (registered)
        {
            UnregisterHotKey(Handle, HotkeyId);
            registered = false;
        }
        DestroyHandle();
    }
}

// Captura visual somente da area visivel do cliente do jogo.
// Nao altera arquivos, memoria ou comunicacao do launcher.
public static class AQWQuestVision
{
    [StructLayout(LayoutKind.Sequential)]
    public struct NativePoint { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)]
    public struct NativeRect { public int Left; public int Top; public int Right; public int Bottom; }

    [DllImport("user32.dll")]
    private static extern bool GetClientRect(IntPtr hwnd, out NativeRect r);
    [DllImport("user32.dll")]
    private static extern bool ClientToScreen(IntPtr hwnd, ref NativePoint pt);
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    private static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out NativePoint pt);
    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")]
    private static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);

    public static Rectangle ClientBounds(IntPtr hwnd)
    {
        NativeRect r;
        if (!GetClientRect(hwnd, out r)) return Rectangle.Empty;
        NativePoint pt = new NativePoint();
        if (!ClientToScreen(hwnd, ref pt)) return Rectangle.Empty;
        int w = r.Right - r.Left;
        int h = r.Bottom - r.Top;
        if (w < 100 || h < 100) return Rectangle.Empty;
        return new Rectangle(pt.X, pt.Y, w, h);
    }

    public static bool IsActive(IntPtr hwnd)
    {
        IntPtr active = GetForegroundWindow();
        return active != IntPtr.Zero && GetAncestor(active, 2) == GetAncestor(hwnd, 2);
    }

    public static void Activate(IntPtr hwnd) { SetForegroundWindow(hwnd); }

    public static Bitmap Capture(Rectangle bounds)
    {
        if (bounds.Width <= 0 || bounds.Height <= 0) throw new ArgumentException("Area vazia");
        Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        using (Graphics g = Graphics.FromImage(bitmap))
            g.CopyFromScreen(bounds.Location, Point.Empty, bounds.Size, CopyPixelOperation.SourceCopy);
        return bitmap;
    }

    // Similaridade de amostragem com tolerancia a pequenas variacoes da interface.
    // O resultado vai de 0 a 100; exigir duas leituras antes de agir.
    public static int Compare(Bitmap expected, Bitmap observed)
    {
        if (expected == null || observed == null ||
            expected.Width != observed.Width || expected.Height != observed.Height) return 0;
        int dx = Math.Max(1, expected.Width / 52);
        int dy = Math.Max(1, expected.Height / 20);
        long diff = 0;
        long samples = 0;
        long matchingPixels = 0;
        long pixels = 0;
        for (int y = 0; y < expected.Height; y += dy)
        {
            for (int x = 0; x < expected.Width; x += dx)
            {
                Color a = expected.GetPixel(x, y);
                Color b = observed.GetPixel(x, y);
                int dr = Math.Abs((int)a.R - (int)b.R);
                int dg = Math.Abs((int)a.G - (int)b.G);
                int db = Math.Abs((int)a.B - (int)b.B);
                diff += dr + dg + db;
                if (Math.Max(dr, Math.Max(dg, db)) <= 35) matchingPixels++;
                pixels++;
                samples += 3;
            }
        }
        if (samples == 0 || pixels == 0) return 0;
        double pixelScore = matchingPixels * 100.0 / pixels;
        double colorScore = 100.0 - diff * 100.0 / (255.0 * samples);
        return (int)Math.Round(0.60 * pixelScore + 0.40 * colorScore);
    }

    // Clique simulado apenas com o launcher ATIVO e em uma coordenada calibrada.
    // A restauracao do cursor e imediata, mas pode interromper o movimento do mouse.
    public static bool Click(IntPtr hwnd, int clientX, int clientY)
    {
        if (!IsActive(hwnd)) return false;
        Rectangle region = ClientBounds(hwnd);
        if (region.IsEmpty || clientX < 0 || clientY < 0 ||
            clientX >= region.Width || clientY >= region.Height) return false;
        NativePoint previous;
        if (!GetCursorPos(out previous)) return false;
        try
        {
            SetCursorPos(region.Left + clientX, region.Top + clientY);
            mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero);
            System.Threading.Thread.Sleep(45);
            mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);
            return true;
        }
        finally { SetCursorPos(previous.X, previous.Y); }
    }
}

// Area para calibrar uma quest: a pessoa arrasta sobre o botao Complete
// mostrado no print congelado do cliente visivel do AQW.
public sealed class AQWQuestPicker : Form
{
    private Point started;
    private bool dragging;
    private Rectangle marked = Rectangle.Empty;
    public Rectangle Selection { get; private set; }
    public AQWQuestPicker(Bitmap snapshot, Point screenOrigin)
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        StartPosition = FormStartPosition.Manual;
        Location = screenOrigin;
        ClientSize = snapshot.Size;
        BackgroundImage = snapshot;
        BackgroundImageLayout = ImageLayout.None;
        KeyPreview = true;
        Cursor = Cursors.Cross;
        DoubleBuffered = true;
    }
    protected override void OnKeyDown(KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape) { DialogResult = DialogResult.Cancel; Close(); }
        base.OnKeyDown(e);
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left) { dragging = true; started = e.Location; marked = Rectangle.Empty; Capture = true; }
        base.OnMouseDown(e);
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        if (dragging)
        {
            int l = Math.Max(0, Math.Min(started.X, e.X));
            int t = Math.Max(0, Math.Min(started.Y, e.Y));
            int r = Math.Min(ClientSize.Width, Math.Max(started.X, e.X));
            int b = Math.Min(ClientSize.Height, Math.Max(started.Y, e.Y));
            marked = Rectangle.FromLTRB(l, t, r, b);
            Invalidate();
        }
        base.OnMouseMove(e);
    }
    protected override void OnMouseUp(MouseEventArgs e)
    {
        if (dragging)
        {
            dragging = false; Capture = false;
            if (marked.Width >= 28 && marked.Height >= 16)
            {
                Selection = marked;
                DialogResult = DialogResult.OK;
                Close();
            }
            else { marked = Rectangle.Empty; Invalidate(); }
        }
        base.OnMouseUp(e);
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        if (!marked.IsEmpty)
        {
            using (Brush b = new SolidBrush(Color.FromArgb(55, 60, 165, 255)))
                e.Graphics.FillRectangle(b, marked);
            using (Pen pen = new Pen(Color.FromArgb(255, 74, 200, 255), 3))
                e.Graphics.DrawRectangle(pen, marked);
        }
    }
}
'@
Add-Type -TypeDefinition $source -ReferencedAssemblies @('System.Windows.Forms', 'System.Drawing') -ErrorAction Stop

[System.Windows.Forms.Application]::EnableVisualStyles()

# --- Estado / paleta ---
$script:targetHandle = [IntPtr]::Zero
$script:mainHandle = [IntPtr]::Zero
$script:targetTitle = ''
$script:activeSequence = @()
$script:sequenceIndex = 0
$script:sentCount = 0
$script:sendMode = 0
$script:isRunning = $false
$script:isPaused = $false
$script:hotkeyInitialized = $false
$script:activeHotkeyLabel = ''

$bg = [System.Drawing.Color]::FromArgb(11, 18, 32)
$card = [System.Drawing.Color]::FromArgb(23, 34, 53)
$inputBg = [System.Drawing.Color]::FromArgb(32, 47, 70)
$line = [System.Drawing.Color]::FromArgb(52, 72, 100)
$accent = [System.Drawing.Color]::FromArgb(81, 137, 249)
$green = [System.Drawing.Color]::FromArgb(39, 174, 128)
$text = [System.Drawing.Color]::FromArgb(239, 245, 255)
$muted = [System.Drawing.Color]::FromArgb(159, 178, 207)
$subtle = [System.Drawing.Color]::FromArgb(121, 145, 178)

$form = New-Object System.Windows.Forms.Form
$form.Text = 'AQW | Comandos Direcionados V6'
$form.Size = New-Object System.Drawing.Size(990, 785)
$form.MinimumSize = New-Object System.Drawing.Size(790, 640)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$form.BackColor = $bg
$form.ForeColor = $text
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
# The executable passes its icon and a readiness marker for error diagnostics.
try {
    if (-not [string]::IsNullOrWhiteSpace($env:AQW_HOST_EXE) -and (Test-Path -LiteralPath $env:AQW_HOST_EXE)) {
        $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($env:AQW_HOST_EXE)
    }
} catch { }
$form.Add_Shown({
    $form.BringToFront()
    [void]$form.Activate()
    if (-not [string]::IsNullOrWhiteSpace($env:AQW_READY_FILE)) {
        try { [System.IO.File]::WriteAllText($env:AQW_READY_FILE, 'shown') } catch { }
    }
})

$layoutRoot = New-Object System.Windows.Forms.TableLayoutPanel
$layoutRoot.Dock = [System.Windows.Forms.DockStyle]::Fill
$layoutRoot.ColumnCount = 1
$layoutRoot.RowCount = 3
$layoutRoot.Padding = New-Object System.Windows.Forms.Padding(0)
$layoutRoot.Margin = New-Object System.Windows.Forms.Padding(0)
$columnStyle = New-Object System.Windows.Forms.ColumnStyle
$columnStyle.SizeType = [System.Windows.Forms.SizeType]::Percent
$columnStyle.Width = 100
[void]$layoutRoot.ColumnStyles.Add($columnStyle)
$rowHeader = New-Object System.Windows.Forms.RowStyle
$rowHeader.SizeType = [System.Windows.Forms.SizeType]::Absolute
$rowHeader.Height = 91
[void]$layoutRoot.RowStyles.Add($rowHeader)
$rowBody = New-Object System.Windows.Forms.RowStyle
$rowBody.SizeType = [System.Windows.Forms.SizeType]::Percent
$rowBody.Height = 100
[void]$layoutRoot.RowStyles.Add($rowBody)
$rowFooter = New-Object System.Windows.Forms.RowStyle
$rowFooter.SizeType = [System.Windows.Forms.SizeType]::Absolute
$rowFooter.Height = 186
[void]$layoutRoot.RowStyles.Add($rowFooter)
$form.Controls.Add($layoutRoot)

function New-UiLabel($parent, [string]$value, [int]$x, [int]$y, [int]$w, [int]$h, [int]$size = 10, [bool]$bold = $false, $color = $null) {
    $control = New-Object System.Windows.Forms.Label
    $control.Text = $value
    $control.Location = New-Object System.Drawing.Point($x, $y)
    $control.Size = New-Object System.Drawing.Size($w, $h)
    $style = [System.Drawing.FontStyle]::Regular
    if ($bold) { $style = [System.Drawing.FontStyle]::Bold }
    $control.Font = New-Object System.Drawing.Font('Segoe UI', $size, $style)
    $control.ForeColor = $text
    if ($null -ne $color) { $control.ForeColor = $color }
    $control.BackColor = [System.Drawing.Color]::Transparent
    $parent.Controls.Add($control)
    return $control
}

function New-UiButton($parent, [string]$value, [int]$x, [int]$y, [int]$w, [int]$h, $background, [bool]$isPrimary = $false) {
    $control = New-Object System.Windows.Forms.Button
    $control.Text = $value
    $control.Location = New-Object System.Drawing.Point($x, $y)
    $control.Size = New-Object System.Drawing.Size($w, $h)
    $control.BackColor = $background
    $control.ForeColor = $text
    $control.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $control.FlatAppearance.BorderSize = 0
    $control.Cursor = [System.Windows.Forms.Cursors]::Hand
    $control.UseVisualStyleBackColor = $false
    if ($isPrimary) { $control.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold) }
    $control.Add_Resize({ param($sender, $eventArgs) [AQWVisuals]::Round($sender, 9) })
    $parent.Controls.Add($control)
    [AQWVisuals]::Round($control, 9)
    return $control
}

function New-UiCombo($parent, [int]$x, [int]$y, [int]$w) {
    $control = New-Object System.Windows.Forms.ComboBox
    $control.Location = New-Object System.Drawing.Point($x, $y)
    $control.Size = New-Object System.Drawing.Size($w, 32)
    $control.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    $control.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $control.BackColor = $inputBg
    $control.ForeColor = $text
    $parent.Controls.Add($control)
    return $control
}

# --- Cabecalho ---
$header = New-Object System.Windows.Forms.Panel
$header.Dock = [System.Windows.Forms.DockStyle]::Fill
$header.Margin = New-Object System.Windows.Forms.Padding(0)
$header.Height = 91
$header.BackColor = $bg
$layoutRoot.Controls.Add($header, 0, 0)
$title = New-UiLabel $header 'Comandos direcionados' 23 13 620 39 20 $true
$desc = New-UiLabel $header 'Envio virtual para a janela escolhida, sem usar o teclado fisico.' 25 55 780 25 10 $false $muted
$version = New-UiLabel $header 'AQW  /  V6' 800 23 142 26 10 $true $accent
$version.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$version.Anchor = 'Top,Right'

# --- Rodape sempre visivel ---
$footer = New-Object System.Windows.Forms.Panel
$footer.Dock = [System.Windows.Forms.DockStyle]::Fill
$footer.Margin = New-Object System.Windows.Forms.Padding(0)
$footer.Height = 186
$footer.BackColor = [System.Drawing.Color]::FromArgb(16, 27, 44)
$layoutRoot.Controls.Add($footer, 0, 2)
$sendLabel = New-UiLabel $footer 'MODO DE ENVIO' 23 12 280 22 9 $true $muted
$methodCombo = New-UiCombo $footer 23 38 348
[void]$methodCombo.Items.Add('KeyDown + KeyUp (V2.1)')
[void]$methodCombo.Items.Add('KeyDown + Char + KeyUp')
[void]$methodCombo.Items.Add('Char (experimental)')
$methodCombo.SelectedIndex = 0
$start = New-UiButton $footer 'Iniciar sequencia' 608 33 166 42 $green $true
$stop = New-UiButton $footer 'Parar' 786 33 150 42 $inputBg $true
$stop.Enabled = $false
# Atalho global continua ativo mesmo se esta janela estiver minimizada.
$hotkeyLabel = New-UiLabel $footer 'ATALHO GLOBAL PARA INICIAR / PAUSAR' 23 87 310 22 9 $true $muted
$hotkeyCombo = New-UiCombo $footer 347 84 216
foreach ($n in 1..11) { [void]$hotkeyCombo.Items.Add("F$n") }
foreach ($n in 1..11) { [void]$hotkeyCombo.Items.Add("Ctrl + F$n") }
foreach ($n in 1..11) { [void]$hotkeyCombo.Items.Add("Ctrl + Shift + F$n") }
foreach ($letter in [char[]]'ABCDEFGHIJKLMNOPQRSTUVWXYZ') { [void]$hotkeyCombo.Items.Add("Ctrl + $letter") }
foreach ($digit in 0..9) { [void]$hotkeyCombo.Items.Add("Ctrl + $digit") }
$hotkeyCombo.SelectedItem = 'F3'
$hotkeyHint = New-UiLabel $footer 'Funciona com o app minimizado.' 575 88 370 30 9 $false $muted
$status = New-UiLabel $footer 'Pronto. Escolha e fixe uma janela.' 23 138 915 30 10 $false $muted
$status.AutoEllipsis = $true

# --- Conteudo rolavel, redimensionavel ---
$scroll = New-Object System.Windows.Forms.Panel
$scroll.Dock = [System.Windows.Forms.DockStyle]::Fill
$scroll.Margin = New-Object System.Windows.Forms.Padding(0)
$scroll.AutoScroll = $true
$scroll.BackColor = $bg
$layoutRoot.Controls.Add($scroll, 0, 1)

$content = New-Object System.Windows.Forms.Panel
$content.Location = New-Object System.Drawing.Point(22, 5)
$content.Size = New-Object System.Drawing.Size(928, 1295)
$content.BackColor = $bg
$scroll.Controls.Add($content)

$targetCard = New-Object System.Windows.Forms.Panel
$targetCard.Location = New-Object System.Drawing.Point(0, 0)
$targetCard.Size = New-Object System.Drawing.Size(928, 235)
$targetCard.BackColor = $card
$content.Controls.Add($targetCard)
[AQWVisuals]::Round($targetCard, 14)
$targetCard.Add_Resize({ param($sender, $eventArgs) [AQWVisuals]::Round($sender, 14) })

$targetHeading = New-UiLabel $targetCard '01   Aplicativo de destino' 20 14 600 30 13 $true
$targetHint = New-UiLabel $targetCard 'Selecione o aplicativo e fixe a janela. Mantenha o mesmo componente que funcionou antes.' 20 46 850 24 9 $false $muted
$appLabel = New-UiLabel $targetCard 'JANELAS ABERTAS' 20 74 250 18 8 $true $subtle
$combo = New-UiCombo $targetCard 20 96 765
$combo.DisplayMember = 'Display'
$refresh = New-UiButton $targetCard 'Atualizar' 799 94 108 34 $inputBg
$pin = New-UiButton $targetCard 'Fixar janela' 20 139 150 39 $accent $true
$pinInfo = New-UiLabel $targetCard 'Nenhuma janela fixada.' 183 145 720 32 9 $false $muted
$pinInfo.AutoEllipsis = $true
$componentLabel = New-UiLabel $targetCard 'COMPONENTE DO APLICATIVO (AVANCADO)' 20 182 590 18 8 $true $subtle
$subcombo = New-UiCombo $targetCard 20 202 887
$subcombo.DisplayMember = 'Display'

$sequenceCard = New-Object System.Windows.Forms.Panel
$sequenceCard.Location = New-Object System.Drawing.Point(0, 250)
$sequenceCard.Size = New-Object System.Drawing.Size(928, 424)
$sequenceCard.BackColor = $card
$content.Controls.Add($sequenceCard)
[AQWVisuals]::Round($sequenceCard, 14)
$sequenceCard.Add_Resize({ param($sender, $eventArgs) [AQWVisuals]::Round($sender, 14) })

$sequenceHeading = New-UiLabel $sequenceCard '02   Sequencia e tempo de cada tecla' 20 15 800 30 13 $true
$sequenceHint = New-UiLabel $sequenceCard 'A ordem e de cima para baixo. O intervalo e a espera APOS cada envio.' 20 47 850 24 9 $false $muted

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object System.Drawing.Point(20, 86)
$grid.Size = New-Object System.Drawing.Size(634, 273)
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.AllowUserToResizeRows = $false
$grid.AllowUserToResizeColumns = $false
$grid.RowHeadersVisible = $false
$grid.MultiSelect = $false
$grid.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
$grid.EditMode = [System.Windows.Forms.DataGridViewEditMode]::EditOnEnter
$grid.BackgroundColor = $inputBg
$grid.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$grid.GridColor = $line
$grid.EnableHeadersVisualStyles = $false
$grid.ColumnHeadersHeight = 38
$grid.RowTemplate.Height = 36
$grid.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(42, 61, 87)
$grid.ColumnHeadersDefaultCellStyle.ForeColor = $text
$grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(42, 61, 87)
$grid.ColumnHeadersDefaultCellStyle.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
$grid.DefaultCellStyle.BackColor = $inputBg
$grid.DefaultCellStyle.ForeColor = $text
$grid.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(55, 79, 113)
$grid.DefaultCellStyle.SelectionForeColor = $text
$grid.DefaultCellStyle.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$grid.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(8, 1, 8, 1)
$grid.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(36, 52, 75)
$grid.AlternatingRowsDefaultCellStyle.ForeColor = $text
$grid.AlternatingRowsDefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(55, 79, 113)
$grid.AlternatingRowsDefaultCellStyle.SelectionForeColor = $text
$grid.CellBorderStyle = [System.Windows.Forms.DataGridViewCellBorderStyle]::SingleHorizontal

$cEnabled = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$cEnabled.Name = 'Ativar'
$cEnabled.HeaderText = 'Usar'
$cEnabled.Width = 69
$cEnabled.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::NotSortable
$cEnabled.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
[void]$grid.Columns.Add($cEnabled)
$cKey = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$cKey.Name = 'Tecla'
$cKey.HeaderText = 'Tecla'
$cKey.Width = 120
$cKey.ReadOnly = $true
$cKey.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::NotSortable
[void]$grid.Columns.Add($cKey)
$cMs = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$cMs.Name = 'Espera'
$cMs.HeaderText = 'Espera apos (ms)'
$cMs.AutoSizeMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
$cMs.MinimumWidth = 175
$cMs.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::NotSortable
$cMs.DefaultCellStyle.Alignment = [System.Windows.Forms.DataGridViewContentAlignment]::MiddleRight
[void]$grid.Columns.Add($cMs)
$sequenceCard.Controls.Add($grid)

$chooseLabel = New-UiLabel $sequenceCard 'ADICIONAR UMA TECLA' 674 88 235 19 8 $true $subtle
$keyCombo = New-UiCombo $sequenceCard 674 111 232
foreach ($digit in 0..9) { [void]$keyCombo.Items.Add([string]$digit) }
foreach ($letter in [char[]]'ABCDEFGHIJKLMNOPQRSTUVWXYZ') { [void]$keyCombo.Items.Add([string]$letter) }
foreach ($n in 1..12) { [void]$keyCombo.Items.Add("F$n") }
foreach ($special in @('Espaco', 'Enter', 'Tab', 'Esc', 'Seta cima', 'Seta baixo', 'Seta esquerda', 'Seta direita')) { [void]$keyCombo.Items.Add($special) }
$keyCombo.SelectedItem = '1'
$add = New-UiButton $sequenceCard '+  Adicionar' 674 151 232 39 $accent $true
$remove = New-UiButton $sequenceCard 'Remover selecionada' 674 201 232 37 $inputBg
$up = New-UiButton $sequenceCard 'Subir  ↑' 674 249 111 37 $inputBg
$down = New-UiButton $sequenceCard 'Descer  ↓' 795 249 111 37 $inputBg
$editHint = New-UiLabel $sequenceCard 'Edite os ms diretamente na tabela. Voce pode repetir teclas e desativar linhas sem exclui-las.' 674 302 234 78 9 $false $muted
$gridHint = New-UiLabel $sequenceCard 'Exemplo: tecla 1 = 200 ms; tecla 2 = 300 ms. Apos a ultima, a sequencia recomeça.' 20 371 633 42 9 $false $muted


# --- 03  Quests por leitura de contador e clique visual (Windows OCR) ---
$script:questsPath = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'AQWComandos\QuestsV6'
$script:questsFile = Join-Path $script:questsPath 'quests-v6.json'
$script:questRecords = New-Object System.Collections.ArrayList
$script:questImages = @{}
$script:questWatchEnabled = $false
$script:questListLoading = $false
$script:ocrReady = $false
$script:ocrError = ''
$script:questSelected = $null
$script:questScanBusy = $false

$questCard = New-Object System.Windows.Forms.Panel
$questCard.Location = New-Object System.Drawing.Point(0, 689)
$questCard.Size = New-Object System.Drawing.Size(928, 595)
$questCard.BackColor = $card
$content.Controls.Add($questCard)
[AQWVisuals]::Round($questCard, 14)
$questCard.Add_Resize({ param($sender, $eventArgs) [AQWVisuals]::Round($sender, 14) })
$questHeading = New-UiLabel $questCard '03   Quests | contador + entrega visual' 20 15 850 30 13 $true
$questHelp = New-UiLabel $questCard 'Fluxo: ler X/Y no canto direito; clicar nome da quest; conferir Turn in!; entregar; verificar reducao do contador. Repetir apenas se X >= Y.' 20 48 880 50 9 $false $muted
$questHelp.AutoSize = $false
$questAdd = New-UiButton $questCard '+  Calibrar quest' 20 106 204 39 $accent $true
$questRemove = New-UiButton $questCard 'Remover' 238 106 126 39 $inputBg
$questToggle = New-UiButton $questCard 'Ativar monitor' 378 106 172 39 $green $true
$questAuto = New-Object System.Windows.Forms.CheckBox
$questAuto.Text = 'Entregar automaticamente'
$questAuto.Location = New-Object System.Drawing.Point(568, 112)
$questAuto.Size = New-Object System.Drawing.Size(320, 28)
$questAuto.ForeColor = $text
$questAuto.Checked = $false
$questCard.Controls.Add($questAuto)
$questList = New-Object System.Windows.Forms.ListView
$questList.Location = New-Object System.Drawing.Point(20, 161)
$questList.Size = New-Object System.Drawing.Size(888, 252)
$questList.View = [System.Windows.Forms.View]::Details
$questList.CheckBoxes = $true
$questList.FullRowSelect = $true
$questList.GridLines = $false
$questList.MultiSelect = $false
$questList.BackColor = $inputBg
$questList.ForeColor = $text
$questList.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$questList.Font = New-Object System.Drawing.Font('Segoe UI', 10)
[void]$questList.Columns.Add('Quest', 300)
[void]$questList.Columns.Add('Contador', 105)
[void]$questList.Columns.Add('Estado', 310)
[void]$questList.Columns.Add('Entregas', 102)
$questCard.Controls.Add($questList)
$questThresholdLabel = New-UiLabel $questCard 'SIMILARIDADE DO BOTAO (%)' 20 428 275 25 9 $true $muted
$questThreshold = New-Object System.Windows.Forms.NumericUpDown
$questThreshold.Location = New-Object System.Drawing.Point(306, 428)
$questThreshold.Size = New-Object System.Drawing.Size(85, 28)
$questThreshold.Minimum = 75
$questThreshold.Maximum = 99
$questThreshold.Value = 88
$questThreshold.BackColor = $inputBg
$questThreshold.ForeColor = $text
$questCard.Controls.Add($questThreshold)
$questTest = New-UiButton $questCard 'Testar leitura OCR' 421 424 203 36 $inputBg
$questInfo = New-UiLabel $questCard 'Calibracao: selecione o X/Y superior direito, depois o nome da quest e por ultimo o botao Turn in!.' 20 474 882 104 9 $false $muted
$questInfo.AutoSize = $false

$tooltip = New-Object System.Windows.Forms.ToolTip
$tooltip.SetToolTip($grid, 'Edite os intervalos em milissegundos: minimo 50, maximo 60000.')
$tooltip.SetToolTip($subcombo, 'Se a versao anterior usou um componente interno, selecione o mesmo aqui.')
$tooltip.SetToolTip($methodCombo, 'O modo inicial corresponde ao funcionamento da V2.1.')

$script:keyMap = @{}
foreach ($d in 0..9) { $script:keyMap[[string]$d] = 48 + $d }
foreach ($ch in [char[]]'ABCDEFGHIJKLMNOPQRSTUVWXYZ') { $script:keyMap[[string]$ch] = [int]$ch }
foreach ($i in 1..12) { $script:keyMap["F$i"] = 111 + $i }
$script:keyMap['Espaco'] = 32
$script:keyMap['Enter'] = 13
$script:keyMap['Tab'] = 9
$script:keyMap['Esc'] = 27
$script:keyMap['Seta cima'] = 38
$script:keyMap['Seta baixo'] = 40
$script:keyMap['Seta esquerda'] = 37
$script:keyMap['Seta direita'] = 39

function Add-KeyRow([string]$key, [int]$ms = 1000, [bool]$enabled = $true) {
    $index = $grid.Rows.Add([object[]]@($enabled, $key, [string]$ms))
    $grid.ClearSelection()
    $grid.Rows[$index].Selected = $true
    $grid.CurrentCell = $grid.Rows[$index].Cells[1]
}
foreach ($key in @('1','2','3','4','5')) { Add-KeyRow $key 1000 $true }
$grid.ClearSelection()

function Layout-App {
    $width = [Math]::Max(726, $scroll.ClientSize.Width - 44)
    $content.Width = $width
    $targetCard.Width = $width
    $sequenceCard.Width = $width
    $questCard.Width = $width
    $questList.Width = $width - 40
    $questList.Columns[0].Width = [int](($width - 46) * 0.33)
    $questList.Columns[1].Width = 95
    $questList.Columns[2].Width = [Math]::Max(190, $width - 46 - $questList.Columns[0].Width - 95 - 102)
    $questList.Columns[3].Width = 102
    $questHelp.Width = $width - 40
    $questInfo.Width = $width - 40
    $combo.Width = $width - 163
    $refresh.Left = $width - 128
    $pinInfo.Width = $width - 200
    $subcombo.Width = $width - 40
    $targetHint.Width = $width - 40
    $sequenceHint.Width = $width - 40
    $grid.Width = $width - 290
    $gridHint.Width = $width - 305
    $side = $width - 254
    $chooseLabel.Left = $side
    $keyCombo.Left = $side
    $add.Left = $side
    $remove.Left = $side
    $up.Left = $side
    $down.Left = $side + 121
    $editHint.Left = $side
    $status.Width = [Math]::Max(200, $footer.ClientSize.Width - 46)
    $start.Left = $footer.ClientSize.Width - 354
    $stop.Left = $footer.ClientSize.Width - 177
    $version.Left = $header.ClientSize.Width - 169
    $hotkeyHint.Width = [Math]::Max(175, $footer.ClientSize.Width - 600)
}
$scroll.Add_Resize({ Layout-App })
$form.Add_Shown({ Layout-App })
$form.Add_Resize({ Layout-App })

function Refresh-Targets {
    $combo.Items.Clear()
    $windows = @(
        foreach ($process in [System.Diagnostics.Process]::GetProcesses()) {
            try {
                if ($process.Id -eq $PID) { continue }
                if ($process.MainWindowHandle -eq [IntPtr]::Zero) { continue }
                $windowTitle = $process.MainWindowTitle
                if ([string]::IsNullOrWhiteSpace($windowTitle)) { continue }
                [pscustomobject]@{
                    Display = ('{0}  [PID {1}]' -f $windowTitle, $process.Id)
                    Handle  = $process.MainWindowHandle
                    Title   = $windowTitle
                }
            } catch { continue }
        }
    )
    foreach ($item in ($windows | Sort-Object Display)) { [void]$combo.Items.Add($item) }
    if ($combo.Items.Count -gt 0) { $combo.SelectedIndex = 0 }
}

function Stop-Autoclick([string]$message = 'Parado.') {
    $script:timer.Stop()
    $script:isRunning = $false
    $script:isPaused = $false
    foreach ($control in @($grid, $keyCombo, $add, $remove, $up, $down, $subcombo, $methodCombo, $combo, $refresh, $pin)) {
        $control.Enabled = $true
    }
    $start.Enabled = $true
    $start.Text = 'Iniciar sequencia'
    $stop.Enabled = $false
    $status.ForeColor = $muted
    $status.Text = $message
}


function Pause-Autoclick {
    if (-not $script:isRunning) { return }
    $script:timer.Stop()
    $script:isRunning = $false
    $script:isPaused = $true
    $start.Enabled = $true
    $start.Text = 'Retomar sequencia'
    $stop.Enabled = $true
    $status.ForeColor = $accent
    $status.Text = ('Pausado | {0} teclas enviadas | atalho: {1}' -f $script:sentCount, $script:activeHotkeyLabel)
}

function Resume-Autoclick {
    if (-not $script:isPaused) { return }
    if (-not [BackgroundKeySender]::IsWindow($script:targetHandle)) {
        Stop-Autoclick 'O aplicativo de destino foi fechado. Fixe novamente.'
        return
    }
    $script:isPaused = $false
    $script:isRunning = $true
    $start.Enabled = $false
    $start.Text = 'Iniciar sequencia'
    $stop.Enabled = $true
    Send-Next
    if ($script:isRunning) { $script:timer.Start() }
}

function Toggle-Automation {
    if ($script:isRunning) {
        Pause-Autoclick
    } elseif ($script:isPaused) {
        Resume-Autoclick
    } else {
        $start.PerformClick()
    }
}

# Win32 RegisterHotKey: no global keyboard hook or SendInput. Other apps retain normal typing.
function Set-SelectedHotkey {
    if ($null -eq $hotkeyCombo.SelectedItem) { return }
    $selected = [string]$hotkeyCombo.SelectedItem
    $keyName = ($selected -split ' \+ ')[-1]
    $matchKey = [regex]::Match($keyName, '^F(1[01]|[1-9])$')
    if ($matchKey.Success) {
        $vk = 111 + [int]$matchKey.Groups[1].Value
    } elseif ($keyName.Length -eq 1 -and $keyName -match '^[A-Z0-9]$') {
        $vk = [int][char]$keyName
    } else {
        return
    }
    [uint32]$mods = 0
    if ($selected.Contains('Ctrl')) { $mods = $mods -bor 2 }
    if ($selected.Contains('Shift')) { $mods = $mods -bor 4 }
    if ($script:hotkeyManager.ChangeHotkey($vk, $mods)) {
        $script:activeHotkeyLabel = $selected
        $hotkeyHint.Text = 'Ativo: ' + $selected + ' (mesmo minimizado)'
        return
    }
    $hotkeyHint.Text = 'Atalho ocupado por outro aplicativo.'
    if ($script:activeHotkeyLabel -ne '') {
        $hotkeyCombo.SelectedItem = $script:activeHotkeyLabel
    }
    [System.Windows.Forms.MessageBox]::Show(
        ('Nao foi possivel registrar {0}. A tecla pode estar em uso por outro aplicativo. Escolha outra.' -f $selected),
        'Atalho global indisponivel',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
}

$script:hotkeyManager = New-Object AQWHotkeyReceiver
$script:hotkeyManager.add_HotkeyPressed({ Toggle-Automation })
$hotkeyCombo.Add_SelectedIndexChanged({
    if ($script:hotkeyInitialized -and ([string]$hotkeyCombo.SelectedItem -ne $script:activeHotkeyLabel)) {
        Set-SelectedHotkey
    }
})
$form.Add_Shown({
    if (-not $script:hotkeyInitialized) {
        $script:hotkeyInitialized = $true
        Set-SelectedHotkey
    }
})

$script:timer = New-Object System.Windows.Forms.Timer
$script:timer.Interval = 1000

function Send-Next {
    if (-not $script:isRunning) { return }
    if (-not [BackgroundKeySender]::IsWindow($script:targetHandle)) {
        Stop-Autoclick 'Destino fechado ou componente indisponivel. Envio interrompido.'
        return
    }
    $step = $script:activeSequence[$script:sequenceIndex]
    $accepted = [BackgroundKeySender]::SendVirtualKey($script:targetHandle, [int]$step.VK, [int]$script:sendMode)
    if (-not $accepted) {
        Stop-Autoclick 'O Windows recusou a mensagem para a janela selecionada.'
        return
    }
    $script:sentCount++
    $script:sequenceIndex = ($script:sequenceIndex + 1) % $script:activeSequence.Count
    $script:timer.Interval = [int]$step.Ms
    $status.ForeColor = $green
    $status.Text = ('Enviando | {0} mensagens | Ultima: {1} | Proxima em {2} ms (envio nao confirma execucao no jogo)' -f $script:sentCount, $step.Key, $step.Ms)
}
$script:timer.Add_Tick({ Send-Next })


# --- Windows OCR: recursos ja presentes no Windows 10/11, sem acesso ao Ruffle ---
function Start-AQWOcr {
    if ($script:ocrReady) { return $true }
    try {
        Add-Type -AssemblyName System.Runtime.WindowsRuntime
        $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
        $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
        $null = [Windows.Foundation.IAsyncOperation`1, Windows.Foundation, ContentType=WindowsRuntime]
        $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType=WindowsRuntime]
        $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType=WindowsRuntime]
        $null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
        $script:ocrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
        if ($null -eq $script:ocrEngine) { throw 'Sem pacote de idioma OCR do Windows. Verifique Idioma e regiao.' }
        $script:ocrAwaiter = [WindowsRuntimeSystemExtensions].GetMember('GetAwaiter', 'Method', 'Public,Static') | Where-Object { $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
        if ($null -eq $script:ocrAwaiter) { throw 'A API de OCR do Windows nao respondeu.' }
        $script:ocrReady = $true
        return $true
    } catch { $script:ocrError = $_.Exception.Message; return $false }
}
function Await-AQW($task, [Type]$type) {
    return $script:ocrAwaiter.MakeGenericMethod($type).Invoke($null, @($task)).GetResult()
}
function Read-AQWCounter([System.Drawing.Rectangle]$roi) {
    if (-not (Start-AQWOcr)) { return $null }
    $bmp = $null; $large = $null; $stream = $null; $soft = $null
    try {
        $bmp = [AQWQuestVision]::Capture($roi)
        $large = [System.Drawing.Bitmap]::new(([int]$roi.Width * 5), ([int]$roi.Height * 5))
        $graphics = [System.Drawing.Graphics]::FromImage($large)
        try {
            $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
            $graphics.Clear([System.Drawing.Color]::White)
            $graphics.DrawImage($bmp, 0, 0, $large.Width, $large.Height)
        } finally { $graphics.Dispose() }
        if (-not (Test-Path -LiteralPath $script:questsPath)) { [void](New-Item -ItemType Directory -Path $script:questsPath -Force) }
        $imagePath = Join-Path $script:questsPath 'ultima-leitura.png'
        $large.Save($imagePath, [System.Drawing.Imaging.ImageFormat]::Png)
        $file = Await-AQW ([Windows.Storage.StorageFile]::GetFileFromPathAsync($imagePath)) ([Windows.Storage.StorageFile])
        $stream = Await-AQW ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        $decoder = Await-AQW ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $soft = Await-AQW ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        $result = Await-AQW ($script:ocrEngine.RecognizeAsync($soft)) ([Windows.Media.Ocr.OcrResult])
        $raw = [string]$result.Text
        $script:lastRawOCR = $raw
        $raw = $raw -replace '[Il|]', '1' -replace '[oO]', '0'
        $match = [regex]::Match($raw, '(?<!\d)(\d{1,3})\s*[/\\]\s*(\d{1,3})(?!\d)')
        if (-not $match.Success) { return $null }
        $n = [int]$match.Groups[1].Value; $d = [int]$match.Groups[2].Value
        if ($d -le 0 -or $n -gt 999 -or $d -gt 999) { return $null }
        return [pscustomobject]@{ Count = $n; Need = $d; Raw = [string]$result.Text }
    } catch { $script:ocrError = $_.Exception.Message; $script:lastRawOCR = 'ERRO: ' + $script:ocrError; return $null }
    finally {
        if ($null -ne $soft) { try { $soft.Dispose() } catch {} }
        if ($null -ne $stream) { try { $stream.Dispose() } catch {} }
        if ($null -ne $large) { $large.Dispose() }
        if ($null -ne $bmp) { $bmp.Dispose() }
    }
}
function Save-QuestRecords {
    try {
        if (-not (Test-Path -LiteralPath $script:questsPath)) { [void](New-Item -ItemType Directory -Path $script:questsPath -Force) }
        $items = @(foreach ($q in $script:questRecords) {
            [pscustomobject]@{ Name=[string]$q.Name; Enabled=[bool]$q.Enabled; File=[string]$q.File;
                CX=[int]$q.CX; CY=[int]$q.CY; CW=[int]$q.CW; CH=[int]$q.CH;
                QX=[int]$q.QX; QY=[int]$q.QY; TX=[int]$q.TX; TY=[int]$q.TY; TW=[int]$q.TW; TH=[int]$q.TH }
        })
        [System.IO.File]::WriteAllText($script:questsFile, (([pscustomobject]@{ Threshold=[int]$questThreshold.Value; Items=$items }) | ConvertTo-Json -Depth 4), [System.Text.Encoding]::UTF8)
    } catch { $questInfo.Text = 'Falha ao salvar quests: ' + $_.Exception.Message }
}
function Add-QuestRecord($record) {
    $li = New-Object System.Windows.Forms.ListViewItem([string]$record.Name)
    $li.Tag = $record
    [void]$li.SubItems.Add('-')
    [void]$li.SubItems.Add('Aguardando')
    [void]$li.SubItems.Add('0')
    $li.Checked = [bool]$record.Enabled
    [void]$questList.Items.Add($li)
}
function Load-QuestRecords {
    if (-not (Test-Path -LiteralPath $script:questsFile)) { return }
    try {
        $saved = Get-Content -LiteralPath $script:questsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $script:questListLoading = $true
        foreach ($q in @($saved.Items)) {
            if ($null -eq $q -or [string]$q.File -notmatch '^[a-fA-F0-9-]{36}\.png$') { continue }
            $file = Join-Path $script:questsPath ([string]$q.File)
            if (-not (Test-Path -LiteralPath $file)) { continue }
            $image = [System.Drawing.Bitmap]::new($file)
            if ($image.Width -ne [int]$q.TW -or $image.Height -ne [int]$q.TH) { $image.Dispose(); continue }
            $record = [pscustomobject]@{
                Name=[string]$q.Name; Enabled=[bool]$q.Enabled; File=[string]$q.File;
                CX=[int]$q.CX; CY=[int]$q.CY; CW=[int]$q.CW; CH=[int]$q.CH;
                QX=[int]$q.QX; QY=[int]$q.QY; TX=[int]$q.TX; TY=[int]$q.TY; TW=[int]$q.TW; TH=[int]$q.TH;
                Stage='Idle'; Due=[datetime]::MinValue; Before=0; Hits=0; LastCounter=''; Turns=0; LastAlert=[datetime]::MinValue
            }
            $script:questImages[$record.File] = $image
            [void]$script:questRecords.Add($record)
            Add-QuestRecord $record
        }
        if ([int]$saved.Threshold -ge 75 -and [int]$saved.Threshold -le 99) { $questThreshold.Value = [int]$saved.Threshold }
    } catch { $questInfo.Text = 'Nao foi possivel carregar quests: ' + $_.Exception.Message }
    finally { $script:questListLoading = $false }
}
function Ask-QuestName {
    Add-Type -AssemblyName Microsoft.VisualBasic
    $name = [Microsoft.VisualBasic.Interaction]::InputBox('Nome da quest:', 'Calibrar quest', ('Quest {0}' -f ($script:questRecords.Count + 1)))
    if ([string]::IsNullOrWhiteSpace($name)) { return $null }
    return $name.Trim()
}
function Pick-AQWArea([string]$hint) {
    [System.Windows.Forms.MessageBox]::Show($hint + "`n`nSelecione a area com o mouse. ESC cancela.", 'Calibracao AQW', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    $snapshot = $null; $picker = $null
    try {
        $form.Hide()
        [AQWQuestVision]::Activate($script:mainHandle)
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 350
        $bounds = [AQWQuestVision]::ClientBounds($script:mainHandle)
        if ($bounds.IsEmpty) { throw 'Jogo nao localizado.' }
        $snapshot = [AQWQuestVision]::Capture($bounds)
        $picker = [AQWQuestPicker]::new($snapshot, $bounds.Location)
        if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
        return $picker.Selection
    } catch { $questInfo.Text = 'Falha na calibracao: ' + $_.Exception.Message; return $null }
    finally { if ($null -ne $picker) { $picker.Dispose() }; if ($null -ne $snapshot) { $snapshot.Dispose() }; $form.Show(); $form.BringToFront() }
}
function Register-QuestVisual {
    if ($script:mainHandle -eq [IntPtr]::Zero -or -not [BackgroundKeySender]::IsWindow($script:mainHandle)) {
        [System.Windows.Forms.MessageBox]::Show('Fixe a janela do AQW antes de calibrar.', 'AQW') | Out-Null; return
    }
    $name = Ask-QuestName
    if ([string]::IsNullOrWhiteSpace($name)) { return }
    $counter = Pick-AQWArea '1/3 - No CANTO DIREITO, marque somente os numeros X/Y (por exemplo 3/1), com uma pequena margem. A janela de quests deve estar aberta a esquerda.'
    if ($null -eq $counter) { return }
    $questButton = Pick-AQWArea '2/3 - Na janela de quests a ESQUERDA, marque o NOME da quest na lista, onde voce clica para abri-la. Nao marque o X de fechar.'
    if ($null -eq $questButton) { return }
    [System.Windows.Forms.MessageBox]::Show('Vou abrir a quest no jogo, usando a posicao que voce marcou. Depois selecione o botao Turn in! sem confirma-lo.', 'Preparar ultima captura') | Out-Null
    $form.Hide()
    [AQWQuestVision]::Activate($script:mainHandle)
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 350
    [void][AQWQuestVision]::Click($script:mainHandle, ($questButton.X + [int]($questButton.Width / 2)), ($questButton.Y + [int]($questButton.Height / 2)))
    Start-Sleep -Milliseconds 500
    $form.Show()
    $turnButton = Pick-AQWArea '3/3 - Com o detalhe da quest ABERTO, marque apenas o BOTAO Turn in! (o retangulo central inferior). Este sera o modelo visual para validar antes do clique.'
    if ($null -eq $turnButton) { return }
    try {
        $form.Hide()
        [AQWQuestVision]::Activate($script:mainHandle)
        Start-Sleep -Milliseconds 260
        $bounds = [AQWQuestVision]::ClientBounds($script:mainHandle)
        $part = [AQWQuestVision]::Capture([System.Drawing.Rectangle]::new(($bounds.Left + $turnButton.X), ($bounds.Top + $turnButton.Y), $turnButton.Width, $turnButton.Height))
        $form.Show()
        if (-not (Test-Path -LiteralPath $script:questsPath)) { [void](New-Item -ItemType Directory -Path $script:questsPath -Force) }
        $file = [guid]::NewGuid().ToString() + '.png'
        $part.Save((Join-Path $script:questsPath $file), [System.Drawing.Imaging.ImageFormat]::Png)
        $record = [pscustomobject]@{
            Name=$name; Enabled=$true; File=$file; CX=$counter.X; CY=$counter.Y; CW=$counter.Width; CH=$counter.Height;
            QX=($questButton.X + [int]($questButton.Width / 2)); QY=($questButton.Y + [int]($questButton.Height / 2));
            TX=$turnButton.X; TY=$turnButton.Y; TW=$turnButton.Width; TH=$turnButton.Height;
            Stage='Idle'; Due=[datetime]::MinValue; Before=0; Hits=0; LastCounter=''; Turns=0; LastAlert=[datetime]::MinValue
        }
        $script:questImages[$file] = $part
        [void]$script:questRecords.Add($record)
        Add-QuestRecord $record
        Save-QuestRecords
        $questInfo.Text = ('Quest cadastrada: {0}. Use Back para voltar a lista, teste OCR e so depois ative o monitor.' -f $name)
    } catch { $questInfo.Text = 'Falha ao salvar quest: ' + $_.Exception.Message; $form.Show() }
}
function Get-QuestProgress($quest, $clientRect) {
    if ($quest.CX -lt 0 -or $quest.CY -lt 0 -or ($quest.CX + $quest.CW) -gt $clientRect.Width -or ($quest.CY + $quest.CH) -gt $clientRect.Height) { return $null }
    return Read-AQWCounter ([System.Drawing.Rectangle]::new(($clientRect.Left + $quest.CX), ($clientRect.Top + $quest.CY), $quest.CW, $quest.CH))
}
function Tick-AQWQuests {
    if (-not $script:questWatchEnabled -or $script:questScanBusy -or $script:questRecords.Count -eq 0) { return }
    if ($script:isPaused) { $questInfo.Text = 'Pausado por F3. O monitor tambem aguarda.'; return }
    if ($script:mainHandle -eq [IntPtr]::Zero -or -not [BackgroundKeySender]::IsWindow($script:mainHandle)) { return }
    if (-not [AQWQuestVision]::IsActive($script:mainHandle)) { return }
    $clientRect = [AQWQuestVision]::ClientBounds($script:mainHandle)
    if ($clientRect.IsEmpty) { return }
    $script:questScanBusy = $true
    try {
        $pending = @($script:questRecords | Where-Object { $_.Stage -eq 'Open' -or $_.Stage -eq 'AwaitDecrease' })
        foreach ($li in $questList.Items) {
            $q = $li.Tag
            if (-not $q.Enabled) { $li.SubItems[2].Text = 'Desativada'; continue }
            if ($pending.Count -gt 0 -and $pending[0].File -ne $q.File) { continue }
            $now = [datetime]::Now
            if ($q.Stage -eq 'Halted') { $li.SubItems[2].Text = 'Conferencia necessaria'; continue }
            if ($now -lt $q.Due) { continue }
            if ($q.Stage -eq 'Open') {
                $roi = [System.Drawing.Rectangle]::new(($clientRect.Left + $q.TX), ($clientRect.Top + $q.TY), $q.TW, $q.TH)
                $image = $null
                try {
                    $image = [AQWQuestVision]::Capture($roi)
                    $score = [AQWQuestVision]::Compare($script:questImages[$q.File], $image)
                    if ($score -lt [int]$questThreshold.Value) {
                        $q.Stage = 'Idle'; $q.Due = $now.AddSeconds(4)
                        $li.SubItems[2].Text = ('Turn in diferente: {0}%' -f $score)
                        $questInfo.Text = 'Botao Turn in nao confere com a calibracao. Nao clicarei. Reabra a lista e confira zoom/posicao.'
                        continue
                    }
                    if (-not [AQWQuestVision]::Click($script:mainHandle, ($q.TX + [int]($q.TW / 2)), ($q.TY + [int]($q.TH / 2)))) { continue }
                    $q.Stage = 'AwaitDecrease'; $q.Due = $now.AddMilliseconds(850); $q.LastAlert = $now
                    $li.SubItems[2].Text = 'Entregue; verificando X/Y'
                } finally { if ($null -ne $image) { $image.Dispose() } }
                continue
            }
            $progress = Get-QuestProgress $q $clientRect
            if ($null -eq $progress) {
                $q.Hits = 0
                $li.SubItems[1].Text = 'Sem leitura'
                $li.SubItems[2].Text = 'OCR nao reconheceu X/Y'
                if ($q.Stage -eq 'AwaitDecrease' -and ($now - $q.LastAlert).TotalSeconds -gt 7) {
                    $q.Stage = 'Halted'; $questInfo.Text = 'Sem confirmacao de entrega. Monitor nao repetira cliques nesta quest ate ser reiniciado.'
                }
                continue
            }
            $li.SubItems[1].Text = ('{0}/{1}' -f $progress.Count, $progress.Need)
            if ($q.Stage -eq 'AwaitDecrease') {
                if ($progress.Count -le ($q.Before - $progress.Need) -and $progress.Count -ge 0) {
                    $q.Turns = [int]$q.Turns + 1
                    $li.SubItems[3].Text = [string]$q.Turns
                    $q.Stage = 'Idle'; $q.Due = $now.AddMilliseconds(950); $q.Hits = 0; $q.LastCounter = ''
                    $li.SubItems[2].Text = 'Entrega confirmada'
                    $questInfo.Text = ('{0}: confirmada {1} entrega(s). Saldo {2}/{3}.' -f $q.Name,$q.Turns,$progress.Count,$progress.Need)
                } elseif (($now - $q.LastAlert).TotalSeconds -gt 7) {
                    $q.Stage = 'Halted'
                    $li.SubItems[2].Text = 'Sem reducao confirmada'
                    $questInfo.Text = 'A leitura nao diminuiu apos Turn in. Quest suspensa para evitar clique duplo.'
                }
                continue
            }
            $value = ('{0}/{1}' -f $progress.Count, $progress.Need)
            if ($q.LastCounter -eq $value) { $q.Hits = [int]$q.Hits + 1 } else { $q.LastCounter = $value; $q.Hits = 1 }
            if ($progress.Count -lt $progress.Need) { $li.SubItems[2].Text = 'Coletando itens'; continue }
            if ($q.Hits -lt 2) { $li.SubItems[2].Text = 'Conferindo contador'; continue }
            $li.SubItems[2].Text = 'PRONTA PARA ENTREGA'
            if (-not $questAuto.Checked) {
                if (($now - $q.LastAlert).TotalSeconds -gt 10) { [System.Media.SystemSounds]::Asterisk.Play(); $q.LastAlert = $now }
                continue
            }
            if ([AQWQuestVision]::Click($script:mainHandle, $q.QX, $q.QY)) {
                $q.Stage = 'Open'; $q.Before = $progress.Count; $q.Due = $now.AddMilliseconds(650)
                $li.SubItems[2].Text = 'Abrindo quest...'
                $questInfo.Text = ('Abrindo {0} para entregar {1}/{2}.' -f $q.Name,$progress.Count,$progress.Need)
                break
            }
        }
    } catch { $questInfo.Text = 'Erro no monitor: ' + $_.Exception.Message }
    finally { $script:questScanBusy = $false }
}
$script:questTimer = New-Object System.Windows.Forms.Timer
$script:questTimer.Interval = 1000
$script:questTimer.Add_Tick({ Tick-AQWQuests })
$questAdd.Add_Click({ Register-QuestVisual })
$questRemove.Add_Click({
    if ($questList.SelectedItems.Count -eq 0 -or $script:questWatchEnabled) { return }
    $li = $questList.SelectedItems[0]; $q = $li.Tag
    if ($script:questImages.ContainsKey($q.File)) { $script:questImages[$q.File].Dispose(); $script:questImages.Remove($q.File) }
    [void]$script:questRecords.Remove($q); $questList.Items.Remove($li)
    $path = Join-Path $script:questsPath $q.File
    if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue }
    Save-QuestRecords
})
$questToggle.Add_Click({
    if ($script:questWatchEnabled) {
        $script:questWatchEnabled = $false; $script:questTimer.Stop()
        $questToggle.Text = 'Ativar monitor'; $questToggle.BackColor = $green
        $questInfo.Text = 'Monitor desligado.'
        $questAdd.Enabled = $true; $questRemove.Enabled = $true
    } else {
        if ($script:questRecords.Count -eq 0 -or $script:mainHandle -eq [IntPtr]::Zero) {
            [System.Windows.Forms.MessageBox]::Show('Fixe o jogo e calibre ao menos uma quest.', 'Monitor de quests') | Out-Null; return
        }
        if (-not (Start-AQWOcr)) {
            [System.Windows.Forms.MessageBox]::Show(('O OCR nativo do Windows nao foi iniciado: ' + $script:ocrError),'Reconhecimento de texto indisponivel') | Out-Null; return
        }
        foreach ($q in $script:questRecords) { $q.Stage='Idle'; $q.Hits=0; $q.LastCounter=''; $q.Due=[datetime]::MinValue }
        $script:questWatchEnabled = $true; $script:questTimer.Start()
        $questToggle.Text = 'Pausar monitor'; $questToggle.BackColor = $inputBg
        $questAdd.Enabled = $false; $questRemove.Enabled = $false
        $questInfo.Text = 'Monitor ativo. Volte ao AQW. Nao altere zoom nem a posicao das janelas de quest.'
    }
})
$questTest.Add_Click({
    if ($questList.SelectedItems.Count -eq 0) { $questInfo.Text = 'Selecione uma quest cadastrada para testar o OCR.'; return }
    if ($script:mainHandle -eq [IntPtr]::Zero) { return }
    $q = $questList.SelectedItems[0].Tag
    $form.Hide()
    [AQWQuestVision]::Activate($script:mainHandle)
    Start-Sleep -Milliseconds 400
    $bounds = [AQWQuestVision]::ClientBounds($script:mainHandle)
    $reading = Get-QuestProgress $q $bounds
    $form.Show(); $form.BringToFront()
    if ($null -eq $reading) { $questInfo.Text = 'OCR nao leu X/Y. Captura salva em QuestsV6\\ultima-leitura.png. Retorno: ' + [string]$script:lastRawOCR }
    else { $questInfo.Text = ('OCR reconheceu {0}/{1} para {2}. Se estiver errado, recalibre.' -f $reading.Count,$reading.Need,$q.Name) }
})
$questAuto.Add_CheckedChanged({ if ($questAuto.Checked) { $questInfo.Text = 'ATENCAO: com entrega automatica ativa, o mouse clicara em quest e Turn in. Teste OCR primeiro.' } })
$questThreshold.Add_ValueChanged({ Save-QuestRecords })
$questList.Add_ItemChecked({ param($sender, $e)
    if ($script:questListLoading -or $null -eq $e.Item.Tag) { return }
    $e.Item.Tag.Enabled = $e.Item.Checked
    Save-QuestRecords
})
Load-QuestRecords

$refresh.Add_Click({ Refresh-Targets })
$pin.Add_Click({
    if ($null -eq $combo.SelectedItem) {
        [System.Windows.Forms.MessageBox]::Show('Abra o aplicativo, clique em Atualizar e selecione a janela.', 'Sem destino') | Out-Null
        return
    }
    $target = $combo.SelectedItem
    if (-not [BackgroundKeySender]::IsWindow($target.Handle)) {
        [System.Windows.Forms.MessageBox]::Show('Janela indisponivel. Atualize a lista.', 'Destino fechado') | Out-Null
        return
    }
    $script:mainHandle = $target.Handle
    $script:targetHandle = $target.Handle
    $script:targetTitle = $target.Title
    $subcombo.Items.Clear()
    [void]$subcombo.Items.Add([pscustomobject]@{
        Display = 'Janela principal: ' + [BackgroundKeySender]::GetWindowClass($target.Handle)
        Handle  = $target.Handle
    })
    foreach ($child in [BackgroundKeySender]::GetChildren($target.Handle)) {
        if (-not [BackgroundKeySender]::IsWindow($child)) { continue }
        $name = [BackgroundKeySender]::GetWindowClass($child)
        [void]$subcombo.Items.Add([pscustomobject]@{
            Display = ('Componente interno: {0} | HWND {1}' -f $name, $child.ToInt64())
            Handle  = $child
        })
    }
    $subcombo.SelectedIndex = 0
    $pinInfo.Text = 'Fixada: ' + $script:targetTitle
    $pinInfo.ForeColor = $green
    $status.ForeColor = $muted
    $status.Text = ('Janela fixada. {0} componentes encontrados.' -f $subcombo.Items.Count)
})

$add.Add_Click({
    if ($null -eq $keyCombo.SelectedItem) { return }
    Add-KeyRow ([string]$keyCombo.SelectedItem) 1000 $true
})
$remove.Add_Click({
    if ($null -eq $grid.CurrentRow) { return }
    $idx = $grid.CurrentRow.Index
    if ($idx -ge 0) { $grid.Rows.RemoveAt($idx) }
})

function Move-Selected([int]$delta) {
    if ($null -eq $grid.CurrentRow) { return }
    $a = $grid.CurrentRow.Index
    $b = $a + $delta
    if ($a -lt 0 -or $b -lt 0 -or $b -ge $grid.Rows.Count) { return }
    $grid.EndEdit() | Out-Null
    $left = @($grid.Rows[$a].Cells[0].Value, $grid.Rows[$a].Cells[1].Value, $grid.Rows[$a].Cells[2].Value)
    $right = @($grid.Rows[$b].Cells[0].Value, $grid.Rows[$b].Cells[1].Value, $grid.Rows[$b].Cells[2].Value)
    for ($i = 0; $i -lt 3; $i++) {
        $grid.Rows[$a].Cells[$i].Value = $right[$i]
        $grid.Rows[$b].Cells[$i].Value = $left[$i]
    }
    $grid.ClearSelection()
    $grid.Rows[$b].Selected = $true
    $grid.CurrentCell = $grid.Rows[$b].Cells[1]
}
$up.Add_Click({ Move-Selected -1 })
$down.Add_Click({ Move-Selected 1 })
$grid.Add_CurrentCellDirtyStateChanged({
    if ($grid.IsCurrentCellDirty -and $grid.CurrentCell.ColumnIndex -eq 0) { $grid.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit) | Out-Null }
})
$grid.Add_DataError({ param($sender, $eventArgs) $eventArgs.ThrowException = $false })

$start.Add_Click({
    if ($script:isPaused) { Resume-Autoclick; return }
    if ($null -eq $subcombo.SelectedItem) {
        [System.Windows.Forms.MessageBox]::Show('Selecione e fixe o aplicativo antes de iniciar.', 'Selecione o destino') | Out-Null
        return
    }
    $script:targetHandle = $subcombo.SelectedItem.Handle
    if (-not [BackgroundKeySender]::IsWindow($script:targetHandle)) {
        [System.Windows.Forms.MessageBox]::Show('Janela indisponivel. Fixe o destino novamente.', 'Destino fechado') | Out-Null
        return
    }
    $grid.EndEdit() | Out-Null
    $chosen = @(
        foreach ($row in $grid.Rows) {
            if (-not [bool]$row.Cells[0].Value) { continue }
            $key = [string]$row.Cells[1].Value
            $num = 0
            if (-not [int]::TryParse([string]$row.Cells[2].Value, [ref]$num) -or $num -lt 50 -or $num -gt 60000) {
                [System.Windows.Forms.MessageBox]::Show(('Intervalo invalido na tecla {0}. Use de 50 a 60000 ms.' -f $key), 'Verifique os intervalos') | Out-Null
                return
            }
            if (-not $script:keyMap.ContainsKey($key)) { continue }
            [pscustomobject]@{
                Key = $key
                VK  = [int]$script:keyMap[$key]
                Ms  = $num
            }
        }
    )
    if ($chosen.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Marque ao menos uma tecla na coluna Usar.', 'Sequencia vazia') | Out-Null
        return
    }
    $script:activeSequence = $chosen
    $script:sequenceIndex = 0
    $script:sentCount = 0
    $script:sendMode = $methodCombo.SelectedIndex
    $script:isPaused = $false
    $script:isRunning = $true
    foreach ($control in @($grid, $keyCombo, $add, $remove, $up, $down, $subcombo, $methodCombo, $combo, $refresh, $pin)) {
        $control.Enabled = $false
    }
    $start.Enabled = $false
    $stop.Enabled = $true
    Send-Next
    if ($script:isRunning) { $script:timer.Start() }
})
$stop.Add_Click({ Stop-Autoclick 'Parado pelo usuario.' })
$form.Add_FormClosing({
    $script:timer.Stop()
    $script:questTimer.Stop()
    foreach ($img in @($script:questImages.Values)) { if ($null -ne $img) { $img.Dispose() } }
    if ($null -ne $script:hotkeyManager) { $script:hotkeyManager.Dispose() }
})

Refresh-Targets
Layout-App
[void]$form.ShowDialog()
$script:timer.Dispose()
$tooltip.Dispose()
$form.Dispose()
