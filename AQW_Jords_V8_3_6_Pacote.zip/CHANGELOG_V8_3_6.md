# AQW Jords V8.3.6 — Seleção dos cliques ao vivo

**Data:** 07/11/2026 | **Situação:** versão experimental, requer validação com Ruffle no Windows.

## Alteração principal

Separação entre **leitura por imagem** e **posição de clique**:

- **OCR**: continua selecionando uma região de imagem do requisito `X/Y` (um ou vários por quest).
- **Pontos de clique**: agora são selecionados diretamente sobre a janela visível do AQW, através de uma camada semitransparente que intercepta o clique de calibração. **Não é uma screenshot**.
- O programa captura `GetPhysicalCursorPos` no instante do clique, calcula `posição_relativa = posição_física - origem_física_da_área_jogável` e salva o ponto.
- O cadastro de quest solicita primeiro o recorte OCR, depois o clique vivo sobre o nome da quest, abre seu detalhe e pede o clique vivo sobre `Turn in!`.
- Novo botão **Editar cliques diretamente no AQW**, com opção de ajustar o ponto do nome **ou** do botão `Turn in!`, mantendo os requisitos OCR já cadastrados.
- `TPX/TPY` armazenam o ponto exato do Turn in; `TX/TY/TW/TH` servem apenas à comparação visual de segurança do botão. O template é capturado com o cursor afastado para reduzir diferenças de hover.
- Compatibilidade com configurações antigas: quando `TPX/TPY` não existem, o carregador usa temporariamente o centro da antiga região de `Turn in!`. **Recomenda-se editar ambos os pontos na tela ao vivo antes de ativar entregas.**
- Preservados OCR, verificação de todos os requisitos, F2/F3, envio de habilidades, movimentos suaves e ritmo do mouse, atalhos, overlay e menu da V8.3.

## Testes locais

- `python3 tests/test_coordinate_model.py`
- `python3 tests/test_live_click_picker.py`
- `GOOS=windows GOARCH=amd64 go build -ldflags='-H windowsgui -s -w' ...`

**Limite:** os testes validam o código e a conversão geométrica, não o clique real no Ruffle nem a criação da camada transparente no Windows. Primeiro testar com o monitor de quests desligado e a conclusão automática desativada.
