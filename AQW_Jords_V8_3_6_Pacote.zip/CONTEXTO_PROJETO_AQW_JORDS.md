# AQW Jords — Contexto técnico e histórico para manutenção

**Versão do pacote:** 8.3.6 (experimental, seleção física dos cliques ao vivo)  
**Data:** 07/11/2026  
**Sistema-alvo:** Windows 10/11, Artix Experimental Launcher com Ruffle  
**Status funcional:** usuário confirmou versão clássica 7.6 e interface 8.3 em seu computador; a seleção ao vivo introduzida na V8.3.6 não foi executada nem validada no Windows/Ruffle neste ambiente. 

> **LEIA ESTE ARQUIVO ANTES DE MODIFICAR O PROJETO.** O usuário prioriza manter a lógica que já funcionou. Não confundir compilação com teste funcional no jogo. Este documento acompanha o código-fonte, para permitir continuidade em novas conversas, correções e refatorações.

## 1. Objetivo e escopo

Ferramenta **local, portátil e sem instalação**, chamada **AQW Jords**, para reduzir tarefas repetitivas durante sessões de AdventureQuest Worlds, sem editar o Ruffle, o launcher ou o tráfego do jogo. O usuário deseja gerenciar manualmente seus itens, equipamentos e potions enquanto o programa facilita a repetição de comandos e o acompanhamento visual de quests. O aplicativo usa métodos de automação externos ao jogo; seu uso pode contrariar os termos da Artix e gerar sanções de conta. Não há tentativa de burlar proteções ou de acessar a memória do jogo.

**Restrições do projeto definidas pelo usuário:**
- Idioma de toda a interface e documentação: **português brasileiro**.
- Executável único `.exe`, portátil, sem arquivo `.bat` para abrir.
- Logo: símbolo original enviado pelo usuário, com fundo branco removido; não redesenhar a marca sem solicitação.
- UI: tema escuro, ícones Lucide de licença permissiva, navegação pelo botão **Menu** (sem barra lateral fixa).
- Preferência essencial: **preservar o motor de entrada, o OCR, o comportamento do mouse, as quests, o painel flutuante e os atalhos F2/F3** sempre que o pedido for exclusivamente visual.
- Não prometer teste real no Windows/Ruffle quando houver apenas testes estáticos no ambiente Linux.

## 2. Arquitetura concreta (não confundir com WebView2)

```
AQW_Jords_V8_3_6.exe  [src/main.go, binário Go Windows GUI]
  ├─ extrai arquivos incorporados para diretório temporário
  ├─ executa powershell.exe -STA -File engine.ps1 sem console
  │   ├─ classes C# compiladas com Add-Type
  │   │   ├─ BackgroundKeySender: PostMessage (teclas para janela)
  │   │   ├─ AQWQuestVision: captura de tela, cursor, cliques, comparação
  │   │   ├─ AQWQuestPicker: seletor da imagem capturada, ajuste/zoom
  │   │   ├─ AQWLivePointPicker: marcacao direta sobre o jogo real (sem screenshot)
  │   │   ├─ AQWHotkeyReceiver: atalhos globais RegisterHotKey
  │   │   └─ AQWStatusOverlay: painel flutuante sem capturar cliques
  │   ├─ Windows Forms: motor, controles e temporizadores
  │   ├─ WebBrowser do Windows Forms: interface HTML local
  │   └─ ponte COM AQWJordsWebBridge (JavaScript -> PowerShell)
  └─ fallback.ps1: interface clássica antiga se a principal não abrir
```

**ATENÇÃO:** o frontend atual é renderizado pelo controle **System.Windows.Forms.WebBrowser**, não pelo Microsoft WebView2. Recursos CSS modernos podem não funcionar como em um Chrome atual. O problema antigo de sobreposição da sidebar foi resolvido na V8.3 ao removê-la da UI. Qualquer migração futura para WebView2 exigiria trabalho específico e validação dos eventos da ponte.

### Arquivos essenciais

| Caminho | Conteúdo | Regra de manutenção |
|---|---|---|
| `src/main.go` | Empacotador, execução, diagnóstico e fallback | Evitar mudanças se estiver funcionando; compilar com `-H windowsgui` |
| `src/engine.ps1` | Lógica principal PowerShell, C# e WinForms | **Preservar**, salvo correção solicitada |
| `src/interface.html` | Estilos, navegação, cards, JS e comandos da ponte | Alterar isoladamente para demandas exclusivamente visuais |
| `src/fallback.ps1` | Interface de compatibilidade (antiga V6) | NÃO confundir com o motor atual completo; não atualizar por engano |
| `src/logo.png`, `src/logo_original.png`, `src/app.ico` | Identidade visual e ícone | Preservar imagem original enviada pelo usuário |
| `Icones_Lucide_SVG/` | Ícones abertos embarcados | Conferir `LICENCA_ICONES_LUCIDE.txt` |
| `CONTEXTO_PROJETO_AQW_JORDS.md` | **Este contexto** | Atualizar sempre que houver mudança de arquitetura, bugs ou decisões |
| `CHANGELOG_V8_3_6.md` | Alterações desta versão | Manter histórico de correções e testes |
| `tests/test_coordinate_model.py` e `tests/test_live_click_picker.py` | Testes geométricos e contratos de seleção ao vivo | Executar antes de publicar |

## 3. Fluxos funcionais a preservar

### Sequência de habilidades
- Seleção/fixação de janela do jogo (HWND); escolha opcional de componente interno.
- Adição, remoção, reordenação e ativação individual de teclas; intervalo individual após cada tecla em milissegundos.
- Envio direcionado por mensagens `WM_KEYDOWN/WM_KEYUP` via `PostMessage` (não interfere no teclado físico).
- **F3 global** inicia/pausa/retoma; programa pode estar minimizado. Modo alternativo `WM_CHAR` mantido.

### Quests visuais
- Quest cadastrada com nome, ponto de clique na lista, posição do botão **Turn in!** e 1+ requisitos `X/Y` selecionados na tela.
- O OCR nativo do Windows retorna `Count` e `Need`. Uma quest só é entregável se **todos** os requisitos estiverem legíveis e `Count >= Need`.
- Após clicar em `Turn in!`, verificar se ao menos um requisito consumível diminuiu adequadamente, relendo todos antes de nova entrega. Sem confirmação: estado `Recover`, sem clicar repetidamente às cegas.
- **F2 global** pede revalidação manual, seguido por novas leituras. F2 não deve forçar uma entrega enquanto ainda está sendo verificada.
- Clique na quest: método de mouse legado validado em V7.2. Clique de Turn in: `SendInput` validado em V7.2. Movimento suave e tempos individualmente configuráveis desde V7.3. **Não alterar a estratégia de clique para corrigir apenas coordenadas.**

### Painel flutuante
- Always-on-top e sem ativação/interceptação de mouse. Exibe cada requisito, estados e falhas de OCR.
- Os dados vêm da leitura normal do monitor, não de um OCR duplicado.

## 4. Problema de coordenadas: origem, correção e invariantes

**Sintoma reportado na V8.3.4:** o usuário calibra uma região com imagem aparentemente correta, mas o cursor percorre uma trajetória até **pontos incorretos**. Ambiente inclui monitor de aproximadamente 30 polegadas e possível DPI/escala não padrão.

**Causa técnica identificada:** `MonitorBounds`, `ClientBounds` e `Capture` da classe `AQWQuestVision` utilizam `SetThreadDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)` e trabalham em **pixels físicos**. Entretanto, `MoveSmooth`, `Click`, `ClickTurnIn` e `ReturnIfAtTarget` usavam `GetCursorPos` / `SetCursorPos`, que podem operar no espaço **lógico**, conforme a consciência de DPI do processo/thread. O cálculo correto da imagem não garantia o mesmo ponto no cursor.

**Correção V8.3.5:** todas as leituras e movimentações do mouse dentro do motor usam `GetPhysicalCursorPos` e `SetPhysicalCursorPos`, chamadas nativas que usam coordenadas de pixels físicos de tela. Mantivemos a duração do movimento e os eventos `mouse_event`/`SendInput`. Referências Microsoft: `https://learn.microsoft.com/en-us/windows/win32/menurc/about-cursors`, `https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setphysicalcursorpos` e `https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getphysicalcursorpos`.

**Sistema de coordenadas único:**

```text
pixels da captura do AQW / selecao do usuario (xrel, yrel)
  + origem fisica da area ativa (area.Left, area.Top)
= pixel fisico do monitor (xabs, yabs)
  => SetPhysicalCursorPos(xabs, yabs)
```

- A área manual é escolhida em uma captura **do monitor completo** e convertida em retângulo físico: `monitor.X + selection.X`, `monitor.Y + selection.Y`.
- `AQWQuestPicker` pode mostrar a captura reduzida/ampliada, mas devolve o retângulo nas coordenadas originais da imagem (`ConvertToOriginalPixels`).
- **Jamais** misturar DPI lógicos de WinForms com posições físicas do cursor.
- Monitores secundários podem ter origem negativa. Não assumir `(0,0)` nem que o monitor usado é o primário.
- A área manual é temporária (não persiste entre execuções). Se a janela do jogo mudou de posição/tamanho, V8.3.5 **bloqueia o uso da região antiga** em vez de voltar silenciosamente à detecção automática.
- Calibrações feitas com uma área diferente da atual podem precisar ser refeitas. Alterar a área após a calibração sem refazer os pontos é perigoso.

### Instrumento de diagnóstico seguro: teste de cursor sem clique

Na página **Quests**, botão **Testar posição sem clicar**. Só funciona com o monitor de quests desligado, uma quest selecionada e o jogo fixado. Oferece teste do nome da quest OU do centro do botão Turn in; move o mouse ao ponto, permanece 1,5 segundo, verifica desvio em pixels físicos e retorna o cursor. **Não clica**. O objetivo é o usuário observar visualmente se o cursor fica sobre o elemento marcado antes de reativar as entregas. Se o teste numérico mostrar desvio zero, mas o cursor cair fora do alvo, é sinal de calibração antiga ou área manual incorreta, não necessariamente falha da API.

## 5. Estado / arquivos de configuração do usuário

A pasta usada pelo código do monitor é construída em `LocalApplicationData` e aponta para **`AQWComandos\QuestsV6`** (apesar do nome, utilizada nas versões novas). Dentro, existem `quests-v6.json`, imagens de botões `.png`, `mouse-ritmo.json`, `painel-flutuante-v76.json` e imagens de diagnóstico OCR. **Nunca zerar essa pasta automaticamente em atualizações.**

Uma quest persistida contém `Name`, `Enabled`, `File`, `Requirements` (nome/região de cada requisito), `QX/QY` (clique no nome) e `TX/TY/TW/TH` (região do Turn in). Os estados transitórios (por exemplo, `Stage`, `Hits`, `BeforeReadings`, `Turns`) são reconstruídos em memória. Os pontos são relativos à área de captura usada quando se calibrou.

Antes de alterar schema ou coordenadas, faça backup dos registros e planeje migração. Não presumir que um item salvo foi calibrado para o monitor atual.

## 6. Evolução resumida

- **V2.1:** envio virtual para janela direcionada e correção de sintaxe PowerShell.
- **V3:** interface WinForms escura; teclas e intervalos individuais.
- **V4:** executável portátil; F3 global; início/pausa.
- **V5:** primeira leitura visual de quests por imagem.
- **V6/V7.1:** OCR `X/Y`, diagnóstico, mapa de tela e seletor de regiões.
- **V7.2:** correção do clique de Turn in usando `SendInput` e pausa maior.
- **V7.3:** movimento suave, hover e ritmo ajustável.
- **V7.4:** suporte a múltiplos requisitos por quest.
- **V7.5:** recuperação de OCR sem travamento permanente; revalidação manual.
- **V7.6:** F2 revalidar e overlay flutuante; versão clássica de referência confirmada funcionando.
- **V7.7:** tentativa de polimento WinForms e alteração de ícone.
- **V8.0:** interface HTML/CSS/JS sobre o motor WinForms, ponte COM; nome AQW Jords.
- **V8.1/V8.2:** ajustes de sidebar e ícone, sem resultado satisfatório no WebBrowser real.
- **V8.3:** retirada da sidebar; menu por botão; logo original transparente; ícones Lucide SVG. Usuário aprovou.
- **V8.3.1/V8.3.2:** respiro, tipografia e padronização de botões/cartões.
- **V8.3.3:** seletor de captura com Ajustar/100%/+/- para caber no monitor.
- **V8.3.4:** seleção manual da área jogável a partir de captura do monitor inteiro; resolve recorte, mas expôs desvio entre seleção e cursor.
- **V8.3.5:** correção do cursor físico, validação de janela/área e botão de teste sem clique.
- **V8.3.6:** separação de OCR (imagem) e clique (coordenada física marcada na tela do jogo), editor individual dos pontos e novo template de conferência do Turn in, mantendo cliques reais independentes do template (**pendente teste real no Windows**).

## 7. Checklist de manutenção e regressão

1. Leia este documento e compare `src/engine.ps1` com a última versão estável. Não reescrever o núcleo inteiro para corrigir CSS.
2. Confirme que a interface em português abre e que o menu navega por **Início, Aplicativo, Habilidades, Quests, Sobreposição, Atalhos, Configurações**.
3. Confirme a seleção/fixação do Ruffle e o envio das teclas de 1–5 sem deslocar o foco.
4. Confirme F3 iniciar/pausar/retomar e F2 revalidar, mesmo com a interface minimizada.
5. Execute **testar posição sem clicar** com escala 100%, 125% e 150%, preferencialmente em monitor secundário. Confirme visualmente os dois pontos.
6. Defina área manual do AQW, cadastre uma quest e teste OCR. Verifique no mapa se regiões correspondem à captura correta.
7. Com entrega automática desligada, confira a leitura de contadores `0/6`, `6/6`, `50/10` e múltiplos requisitos.
8. Só depois, teste uma entrega com observação manual e confirme que o contador diminui antes da próxima.
9. Teste movimento/redimensionamento da janela após selecionar área: deve **parar de usar coordenadas antigas**.
10. Teste a abertura sem PowerShell visível e o ícone da barra, sem prometer sucesso se não foi validado no Windows.
11. Verifique o pacote e os recursos embutidos (`app.ico`, `logo.png`, `interface.html`) e execute `tests/test_coordinate_model.py`.
12. Atualize o histórico de versão e **este documento**.

## 8. Build e diagnóstico

Linux com Go 1.23.2 neste ambiente (cross-compilação):

```bash
cd src
GOOS=windows GOARCH=amd64 go build -ldflags='-H windowsgui -s -w' -o ../AQW_Jords_V8_3_6.exe main.go
```

O `.exe` incorpora arquivos via `//go:embed` e extrai-os para diretório temporário ao iniciar. A interface principal exige Windows PowerShell 5.1 e os componentes nativos do Windows. Os logs de inicialização ficam sob `%LOCALAPPDATA%\AQW Jords\Diagnosticos`. A forma atual de distribuição não exige um instalador; pode haver alertas de reputação por ausência de assinatura digital.

**Limitações de verificação:** neste ambiente não há runtime Windows/Ruffle disponível para executar a GUI e testar cliques reais. Compile o Go, execute checagens estáticas e testes geométricos, mas **descreva a build como experimental até a validação pelo usuário**.

## 9. Próximas ações se o desvio persistir

- Pedir captura da área manual configurada, resultado de **Testar posição sem clicar**, resolução e percentual de escala dos dois monitores (se houver), e se o AQW estava maximizado.
- Distinguir falha de coordenada (**desvio calculado em pixels físicos**) de calibração antiga (**cursor chega exatamente ao ponto calculado, mas o elemento esperado está em outra parte do monitor**).
- Se ambos os pontos estiverem deslocados pela mesma distância, revisar origem da região manual. Se o desvio crescer proporcionalmente à posição, revisar escala de DPI e renderização do seletor.
- Não criar cliques de compensação por offset ad hoc sem corrigir o sistema de coordenadas.

**Princípio final:** arquitetura e comportamento validados antes de alterações cosméticas; isolamento de responsabilidades, testes reproduzíveis e documentação atualizada.

## 10. V8.3.6 — Separação obrigatória de OCR e clique ao vivo

### Decisão arquitetural

O usuário explicitou que **a captura de imagem só pode determinar onde o OCR deve ler o contador**, não a posição do mouse para abrir uma quest e concluir. O método antigo inferia `QX/QY` e o clique final pelo centro de retângulos selecionados em screenshots, causando deslocamentos em monitores grandes/com DPI e calibrações históricas.

A partir da V8.3.6, a classe C# `AQWLivePointPicker` exibe uma **janela translúcida sobre o monitor com o AQW visível, sem screenshot**, captura um clique do usuário e lê a posição real por `GetPhysicalCursorPos`. O clique é consumido pela camada e não deve ser encaminhado ao jogo. O usuário pode cancelar com ESC/botão direito. O ponto de tela em pixels físicos é validado contra a região real do jogo (`AQWQuestVision.ClientBounds`) e é salvo como ponto relativo apenas subtraindo a origem física da região; não aplicar zoom nem escalonamento nessa conversão.

- `QX/QY` = clique REAL no nome da quest (relativo ao início da região física do AQW).
- `TPX/TPY` = clique REAL no botão `Turn in!` (mesma convenção).
- `TX/TY/TW/TH` = pequeno retângulo da imagem de **verificação** de presença do `Turn in!`; não determina onde clicar. Preserva a comparação de segurança já validada pela V7.2.
- `Requirements[] {Name,X,Y,W,H}` = regiões OCR **por imagem**, sem alteração; número arbitrário de requisitos.
- O fluxo `Register-QuestVisual` usa primeiro `Pick-AQWArea` (somente requisito OCR), em seguida dois `Pick-AQWLiveClick` (nome e Turn in). `Edit-AQWClickPoints` permite mudar só um ponto, sem mexer nos contadores.
- `Save-AQWTurnInModel` salva a imagem de verificação em um novo arquivo GUID para evitar sobrescrever um arquivo válido em caso de falha. Afasta temporariamente o cursor do botão antes de fotografar, para capturar a aparência sem hover.
- `Save-QuestRecords` persiste `TPX/TPY` e `PointSource`. `Load-QuestRecords` aceita quests antigas sem esses campos: fallback para o centro do retângulo anterior; **recomendação: recadastrar ambos os pontos antigos ao vivo antes de reativar entrega automática.** A UI e o motor continuam com perfil de dados em `%LOCALAPPDATA%\AQWComandos\QuestsV6`.

### Cuidados com bugs futuros

1. **Nunca usar o centro do retângulo OCR como posição para clicar.** O método de clique deve usar `QX/QY` ou `TPX/TPY` exclusivamente.
2. A região física do jogo pode mudar: não gravar coordenadas absolutas permanentes se a janela for redimensionada/movida; validar a âncora.
3. O seletor semitransparente é uma janela real que recebe o clique. Testar no Windows com vários DPIs, monitor secundário com origem negativa e escala de 125%/150%. Se não cobrir o jogo inteiro, o bug fica restrito ao posicionamento do overlay, não ao OCR.
4. O preview de posição sem clicar continua necessário para verificar o resultado antes de ativar o monitor.
5. Não afirmar que `Add-Type` do C# e WinForms foram executados no Linux; o build Go e testes de fonte não cobrem esse runtime.
6. Testes relevantes: `tests/test_coordinate_model.py` e `tests/test_live_click_picker.py`.
