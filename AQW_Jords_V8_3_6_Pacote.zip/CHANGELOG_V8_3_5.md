# AQW Jords V8.3.5 — correção do posicionamento do mouse

## Corrigido
- Substituídas as leituras e movimentações do cursor por `GetPhysicalCursorPos` e `SetPhysicalCursorPos`, para alinhar o mouse aos pixels físicos usados na captura/seleção.
- Adicionada trava para não reutilizar uma área manual se a janela associada for movida ou redimensionada durante a sessão.
- Mensagem de erro mais clara ao detectar região manual desatualizada.

## Adicionado
- **Quests → Testar posição sem clicar:** permite conferir o alvo do nome da quest ou do Turn in. Move o cursor, aguarda 1,5 s, registra posições físicas e retorna, **sem pressionar mouse**.
- **CONTEXTO_PROJETO_AQW_JORDS.md**: arquitetura, histórico, funções, contratos de coordenadas, locais de configuração, manutenção, regressão e build.
- **tests/test_coordinate_model.py**: validação automática de geometria e contratos estáticos do código.

## Preservado
- Interface em português, botão Menu e ícones.
- Métodos de clique da quest e Turn in, duração de movimentos, OCR, leitura de múltiplos requisitos, automação de habilidades, F2/F3 e overlay.
- Configurações anteriores dos usuários. Não são apagadas pela atualização.

## Atenção
- Não há teste de execução no Windows com Ruffle neste ambiente. V8.3.5 **experimental**.
- Para posições corretas, selecione a área manual na sessão e **recalibre as quests se seus pontos foram salvos com uma referência de captura diferente**.
- Antes de marcar "Entregar automaticamente", pare o monitor e use **Testar posição sem clicar** nos dois alvos.
