"""Self-contained checks of physical-pixel coordinate mapping and source contracts.

Usage: python3 tests/test_coordinate_model.py
The Windows cursor APIs must still be tested in a real Windows session.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'src' / 'engine.ps1').read_text(encoding='utf-8-sig')
HTML = (ROOT / 'src' / 'interface.html').read_text(encoding='utf-8')


def choose_on_screen(monitor, region):
    # desktop monitor rect physical, region picked within screen image original px
    mx, my, mw, mh = monitor
    rx, ry, rw, rh = region
    assert 0 <= rx and 0 <= ry and rx + rw <= mw and ry + rh <= mh
    return mx + rx, my + ry, rw, rh


def screen_click(bounds, relative):
    ax, ay, aw, ah = bounds
    x, y = relative
    assert 0 <= x < aw and 0 <= y < ah
    return ax + x, ay + y


class CoordinateTests(unittest.TestCase):
    def test_screen_origin_100_percent(self):
        area = choose_on_screen((0, 0, 2560, 1440), (120, 80, 2200, 1150))
        self.assertEqual(screen_click(area, (600, 700)), (720, 780))

    def test_external_screen_negative_origin(self):
        area = choose_on_screen((-2560, 0, 2560, 1440), (100, 50, 2000, 1100))
        self.assertEqual(screen_click(area, (500, 300)), (-1960, 350))

    def test_external_screen_vertical_offset(self):
        area = choose_on_screen((1920, -300, 3840, 2160), (110, 160, 2500, 1200))
        self.assertEqual(screen_click(area, (920, 600)), (2950, 460))

    def test_dpi_scale_independent_after_image_selection(self):
        # The coordinates are measured in physical screenshot pixels; 100/125/150% UI scaling
        # should not change the physical absolute point.
        area = choose_on_screen((0, 0, 3840, 2160), (200, 150, 2800, 1600))
        for scale in (1.00, 1.25, 1.50, 2.00):
            with self.subTest(scale=scale):
                self.assertEqual(screen_click(area, (1200, 800)), (1400, 950))

    def test_new_physical_win32_calls_present(self):
        self.assertIn('private static extern bool GetPhysicalCursorPos(', SRC)
        self.assertIn('private static extern bool SetPhysicalCursorPos(', SRC)
        self.assertNotIn('private static extern bool GetCursorPos(', SRC)
        self.assertNotIn('private static extern bool SetCursorPos(', SRC)
        self.assertIn('GetPhysicalCursorPos(out actual)', SRC)
        self.assertIn('SetPhysicalCursorPos(x, y)', SRC)

    def test_click_methods_and_hotkeys_still_present(self):
        self.assertIn('public static bool ClickTurnIn(', SRC)
        self.assertIn('public static bool Click(', SRC)
        self.assertIn('private static bool SendMouseButton(', SRC)
        self.assertIn('private static bool MoveSmooth(', SRC)
        self.assertIn('function Tick-AQWQuests', SRC)
        self.assertIn('function Revalidate-AQWQuest', SRC)
        self.assertIn('function Send-Next', SRC)
        self.assertIn('function Test-AQWCursorPosition', SRC)

    def test_preview_never_presses_mouse(self):
        segment = SRC.split('public static bool PreviewPoint(', 1)[1].split('public static bool ClickTurnIn(', 1)[0]
        self.assertNotIn('SendMouseButton(', segment)
        self.assertNotIn('mouse_event(', segment)
        self.assertIn('System.Threading.Thread.Sleep(1500)', segment)

    def test_preview_button_bridged_to_engine(self):
        self.assertIn("act('testPointer')", HTML)
        self.assertIn("'testPointer' { Test-AQWCursorPosition }", SRC)
        self.assertIn('private static bool IsManualAnchorValid', SRC)
        self.assertIn('LastAreaError', SRC)


if __name__ == '__main__':
    unittest.main(verbosity=2)
