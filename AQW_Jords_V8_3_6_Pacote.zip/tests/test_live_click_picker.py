"""Contrato estatico e modelo geometrico da calibracao de clique ao vivo.
Nao substitui teste real com Windows e Ruffle.
"""
from pathlib import Path
import unittest
BASE = Path(__file__).resolve().parents[1]
engine = (BASE/'src'/'engine.ps1').read_text(encoding='utf-8-sig')
frontend = (BASE/'src'/'interface.html').read_text(encoding='utf-8')

class LiveClickContract(unittest.TestCase):
    def test_live_picker_does_not_capture_screenshot(self):
        picker = engine.split('public sealed class AQWLivePointPicker : Form',1)[1].split('public sealed class AQWQuestPicker : Form',1)[0]
        self.assertIn('GetPhysicalCursorPos(out current)', picker)
        self.assertIn('MouseDown +=',picker)
        self.assertIn('PhysicalPoint = chosen',picker)
        self.assertNotIn('Bitmap', picker)
        self.assertNotIn('Capture(', picker)
        self.assertNotIn('SendInput(',picker)
        self.assertNotIn('mouse_event(',picker)
    def test_real_coordinates_are_converted_only_by_subtraction(self):
        body=engine.split('function Pick-AQWLiveClick(',1)[1].split('function Save-AQWTurnInModel(',1)[0]
        self.assertIn('($physical.X - $latest.X)',body)
        self.assertIn('($physical.Y - $latest.Y)',body)
        self.assertNotIn('zoom',body.lower())
        for area, physical, relative in [((400,200),(525,501),(125,301)), ((-1920,100),(-1800,450),(120,350)),((1500,-1080),(1850,-800),(350,280))]:
            self.assertEqual((physical[0]-area[0],physical[1]-area[1]),relative)
    def test_turn_click_uses_selected_point_not_model_center(self):
        self.assertIn('ClickTurnIn($script:mainHandle, [int]$q.TPX, [int]$q.TPY)',engine)
        self.assertNotIn('ClickTurnIn($script:mainHandle, ($q.TX +',engine)
        self.assertIn('QX=[int]$q.QX; QY=[int]$q.QY;',engine)
    def test_existing_records_are_migrated_without_discarding_quests(self):
        self.assertIn('if ($null -ne $q.TPX)',engine)
        self.assertIn('if ($null -ne $q.TPY)',engine)
        self.assertIn("PointSource=$(if ([string]$q.PointSource -eq 'Tela')",engine)
        self.assertIn('Requirements=$reqs',engine)
    def test_ui_can_edit_without_recalibrating_ocr(self):
        self.assertIn("'editPoints' { Edit-AQWClickPoints }",engine)
        self.assertIn("act('editPoints')",frontend)
        editor = engine.split('function Edit-AQWClickPoints {',1)[1].split('function Register-QuestVisual {',1)[0]
        self.assertNotIn('Pick-AQWArea',editor)
        self.assertIn('Save-QuestRecords',editor)
        self.assertIn('questWatchEnabled',editor)
    def test_quest_first_step_uses_image_only_for_counter(self):
        reg = engine.split('function Register-QuestVisual {',1)[1].split('function Get-QuestProgress(',1)[0]
        self.assertIn('Pick-AQWArea',reg)
        self.assertEqual(reg.count('Pick-AQWArea'),1)
        self.assertEqual(reg.count('Pick-AQWLiveClick'),2)
        self.assertIn('Save-AQWTurnInModel',reg)
    def test_mouse_and_ocr_methods_preserved(self):
        for name in ['ClickTurnIn(', 'public static bool Click(', 'MoveSmooth(', 'Get-QuestProgress', 'RegisterHotKey', 'GetPhysicalCursorPos','PostMessage(']:
            self.assertIn(name,engine)

if __name__=='__main__': unittest.main(verbosity=2)
