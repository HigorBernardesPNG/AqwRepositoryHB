﻿# AQW - Comandos Direcionados V7.6 | Windows PowerShell 5.1
# Portatil: mensagens de janela, nunca injeta teclas no teclado global.
# Observacao: PostMessage enfileira mensagens; o aplicativo de destino pode ignora-las.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$source = @'
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

public static class BackgroundKeySender
{
    private const uint WM_KEYDOWN = 0x0100;
    private const uint WM_KEYUP   = 0x0101;
    private const uint WM_CHAR    = 0x0102;

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool PostMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool IsWindow(IntPtr hWnd);

    private delegate bool EnumWindowCallback(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumChildWindows(IntPtr hWnd, EnumWindowCallback callback, IntPtr data);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr hWnd, StringBuilder buffer, int maxCount);

    [DllImport("user32.dll")]
    private static extern uint MapVirtualKey(uint code, uint mapType);

    public static string GetWindowClass(IntPtr hWnd)
    {
        StringBuilder name = new StringBuilder(256);
        GetClassName(hWnd, name, name.Capacity);
        return name.ToString();
    }

    public static IntPtr[] GetChildren(IntPtr hWnd)
    {
        List<IntPtr> windows = new List<IntPtr>();
        EnumWindowCallback callback = delegate (IntPtr child, IntPtr data)
        {
            windows.Add(child);
            return windows.Count < 60;
        };
        EnumChildWindows(hWnd, callback, IntPtr.Zero);
        return windows.ToArray();
    }

    // mode 0 = KEYDOWN + KEYUP (compatibilidade V2.1)
    // mode 1 = KEYDOWN + CHAR (se aplicavel) + KEYUP
    // mode 2 = CHAR (se aplicavel) ou KEYDOWN + KEYUP
    public static bool SendVirtualKey(IntPtr target, int key, int mode)
    {
        if (!IsWindow(target) || key < 1 || key > 255) return false;
        uint scan = MapVirtualKey((uint)key, 0);
        long downInfo = 1L | ((long)scan << 16);
        long upInfo = downInfo | (1L << 30) | (1L << 31);
        int charCode = 0;
        if (key >= 0x30 && key <= 0x39) charCode = key;
        else if (key >= 0x41 && key <= 0x5A) charCode = key + 32;
        else if (key == 0x20 || key == 0x09 || key == 0x0D) charCode = key;

        if (mode == 2 && charCode != 0)
            return PostMessage(target, WM_CHAR, new IntPtr(charCode), new IntPtr(downInfo));

        bool down = PostMessage(target, WM_KEYDOWN, new IntPtr(key), new IntPtr(downInfo));
        bool middle = true;
        if (mode == 1 && charCode != 0)
            middle = PostMessage(target, WM_CHAR, new IntPtr(charCode), new IntPtr(downInfo));
        bool up = PostMessage(target, WM_KEYUP, new IntPtr(key), new IntPtr(upInfo));
        return down && middle && up;
    }
}

public static class AQWVisuals
{
    public static void Round(Control control, int radius)
    {
        if (control.Width <= 0 || control.Height <= 0) return;
        int r = Math.Min(radius * 2, Math.Min(control.Width, control.Height));
        using (GraphicsPath path = new GraphicsPath())
        {
            path.AddArc(0, 0, r, r, 180, 90);
            path.AddArc(control.Width - r - 1, 0, r, r, 270, 90);
            path.AddArc(control.Width - r - 1, control.Height - r - 1, r, r, 0, 90);
            path.AddArc(0, control.Height - r - 1, r, r, 90, 90);
            path.CloseFigure();
            Region old = control.Region;
            control.Region = new Region(path);
            if (old != null) old.Dispose();
        }
    }
}

// A dedicated message-only window receives system-wide WM_HOTKEY messages.
// No keyboard hook or simulated global keypresses are used.
public sealed class AQWHotkeyReceiver : NativeWindow, IDisposable
{
    private const int WmHotkey = 0x0312;
    private const int HotkeyId = 0x2A71;
    private const uint ModNoRepeat = 0x4000;
    private bool registered;
    private int previousVk;
    private uint previousMods;

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint vk);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    public event EventHandler HotkeyPressed;

    public AQWHotkeyReceiver()
    {
        CreateParams cp = new CreateParams();
        cp.Caption = "AQW Atalho Global";
        cp.Parent = new IntPtr(-3); // HWND_MESSAGE: no taskbar entry or visible window.
        CreateHandle(cp);
    }

    public bool ChangeHotkey(int virtualKey, uint modifiers)
    {
        int oldVk = previousVk;
        uint oldMods = previousMods;
        if (registered)
        {
            UnregisterHotKey(Handle, HotkeyId);
            registered = false;
        }
        if (RegisterHotKey(Handle, HotkeyId, modifiers | ModNoRepeat, (uint)virtualKey))
        {
            registered = true;
            previousVk = virtualKey;
            previousMods = modifiers;
            return true;
        }
        // If the new key is unavailable, restore the previous registration.
        if (oldVk != 0 && RegisterHotKey(Handle, HotkeyId, oldMods | ModNoRepeat, (uint)oldVk))
        {
            registered = true;
            previousVk = oldVk;
            previousMods = oldMods;
        }
        return false;
    }

    public void ReleaseHotkey()
    {
        if (registered)
        {
            UnregisterHotKey(Handle, HotkeyId);
            registered = false;
        }
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WmHotkey && m.WParam.ToInt32() == HotkeyId)
        {
            EventHandler callback = HotkeyPressed;
            if (callback != null) callback(this, EventArgs.Empty);
            return;
        }
        base.WndProc(ref m);
    }

    public void Dispose()
    {
        if (registered)
        {
            UnregisterHotKey(Handle, HotkeyId);
            registered = false;
        }
        DestroyHandle();
    }
}

// A sobreposicao nao recebe foco nem intercepta cliques do jogo.
public sealed class AQWStatusOverlay : Form
{
    protected override bool ShowWithoutActivation { get { return true; } }
    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams p = base.CreateParams;
            // WS_EX_TRANSPARENT | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW
            p.ExStyle |= 0x00080000 | 0x00000020 | 0x08000000 | 0x00000080;
            return p;
        }
    }
}

// Captura visual somente da area visivel do cliente do jogo.
// Nao altera arquivos, memoria ou comunicacao do launcher.
public static class AQWQuestVision
{
    [StructLayout(LayoutKind.Sequential)]
    public struct NativePoint { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)]
    public struct NativeRect { public int Left; public int Top; public int Right; public int Bottom; }

    [DllImport("user32.dll")]
    private static extern bool GetClientRect(IntPtr hwnd, out NativeRect r);
    [DllImport("user32.dll")]
    private static extern bool ClientToScreen(IntPtr hwnd, ref NativePoint pt);
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    private static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out NativePoint pt);
    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")]
    private static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);

    // Usar pixels FISICOS no calculo da janela e na captura. Um monitor
    // configurado a 125%/150% pode cortar a imagem se as duas APIs usarem
    // contextos de DPI diferentes. A mudanca e local a cada chamada.
    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll")]
    private static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo information);
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct MonitorInfo
    {
        public int Size;
        public NativeRect Monitor;
        public NativeRect Work;
        public uint Flags;
    }

    private static IntPtr PhysicalPixels()
    {
        try { return SetThreadDpiAwarenessContext(new IntPtr(-4)); }
        catch (EntryPointNotFoundException) { return IntPtr.Zero; }
    }
    private static void RestoreDpi(IntPtr previous)
    {
        if (previous != IntPtr.Zero) SetThreadDpiAwarenessContext(previous);
    }

    private static IntPtr manualHandle = IntPtr.Zero;
    private static Rectangle manualBounds = Rectangle.Empty;
    public static bool HasManualBounds(IntPtr hwnd)
    {
        return hwnd != IntPtr.Zero && hwnd == manualHandle && !manualBounds.IsEmpty;
    }
    public static void SetManualBounds(IntPtr hwnd, Rectangle area)
    {
        if (hwnd == IntPtr.Zero || !BackgroundKeySender.IsWindow(hwnd) ||
            area.Width < 100 || area.Height < 100) throw new ArgumentException("Area manual invalida");
        manualHandle = hwnd;
        manualBounds = area;
    }
    public static void ClearManualBounds()
    {
        manualHandle = IntPtr.Zero;
        manualBounds = Rectangle.Empty;
    }
    public static Rectangle MonitorBounds(IntPtr hwnd)
    {
        IntPtr previous = PhysicalPixels();
        try
        {
            IntPtr monitor = MonitorFromWindow(hwnd, 2); // mais proximo
            MonitorInfo mi = new MonitorInfo();
            mi.Size = Marshal.SizeOf(typeof(MonitorInfo));
            if (monitor == IntPtr.Zero || !GetMonitorInfo(monitor, ref mi)) return Rectangle.Empty;
            return Rectangle.FromLTRB(mi.Monitor.Left, mi.Monitor.Top,
                                      mi.Monitor.Right, mi.Monitor.Bottom);
        }
        finally { RestoreDpi(previous); }
    }
    public static Rectangle ClientBounds(IntPtr hwnd)
    {
        if (HasManualBounds(hwnd))
        {
            if (BackgroundKeySender.IsWindow(hwnd)) return manualBounds;
            ClearManualBounds();
        }
        IntPtr previous = PhysicalPixels();
        try
        {
            NativeRect r;
            if (!GetClientRect(hwnd, out r)) return Rectangle.Empty;
            NativePoint pt = new NativePoint();
            if (!ClientToScreen(hwnd, ref pt)) return Rectangle.Empty;
            int w = r.Right - r.Left;
            int h = r.Bottom - r.Top;
            if (w < 100 || h < 100) return Rectangle.Empty;
            return new Rectangle(pt.X, pt.Y, w, h);
        }
        finally { RestoreDpi(previous); }
    }

    public static bool IsActive(IntPtr hwnd)
    {
        IntPtr active = GetForegroundWindow();
        return active != IntPtr.Zero && GetAncestor(active, 2) == GetAncestor(hwnd, 2);
    }

    public static void Activate(IntPtr hwnd) { SetForegroundWindow(hwnd); }

    public static Bitmap Capture(Rectangle bounds)
    {
        if (bounds.Width <= 0 || bounds.Height <= 0) throw new ArgumentException("Area vazia");
        IntPtr previous = PhysicalPixels();
        Bitmap bitmap = null;
        try
        {
            bitmap = new Bitmap(bounds.Width, bounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            using (Graphics g = Graphics.FromImage(bitmap))
                g.CopyFromScreen(bounds.Location, Point.Empty, bounds.Size, CopyPixelOperation.SourceCopy);
            return bitmap;
        }
        catch { if (bitmap != null) bitmap.Dispose(); throw; }
        finally { RestoreDpi(previous); }
    }

    // A contagem usa fonte pequena e contraste variavel sobre o fundo do jogo.
    // Gera varias leituras sem depender do idioma do nome da missao.
    public static Bitmap CounterVersion(Bitmap original, int mode)
    {
        bool rightSide = (mode != 0);
        int left = rightSide ? Math.Max(0, original.Width / 3) : 0;
        int sourceWidth = original.Width - left;
        int sourceHeight = original.Height;
        Bitmap prepared = new Bitmap(sourceWidth, sourceHeight, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
        if (mode == 0 || mode == 1)
        {
            using (Graphics g = Graphics.FromImage(prepared))
                g.DrawImage(original, new Rectangle(0, 0, sourceWidth, sourceHeight),
                    new Rectangle(left, 0, sourceWidth, sourceHeight), GraphicsUnit.Pixel);
        }
        else
        {
            // 2: reforca o contraste, 3: binarizacao. Processa antes de ampliar.
            for (int y = 0; y < sourceHeight; y++)
            for (int x = 0; x < sourceWidth; x++)
            {
                Color c = original.GetPixel(x + left, y);
                int gray = (299 * c.R + 587 * c.G + 114 * c.B) / 1000;
                int v = mode == 2 ? Math.Max(0, Math.Min(255, (gray - 125) * 3 + 125))
                                  : (gray >= 155 ? 255 : 0);
                prepared.SetPixel(x, y, Color.FromArgb(v, v, v));
            }
        }
        Bitmap enlarged = new Bitmap(sourceWidth * 5 + 40, sourceHeight * 5 + 40,
            System.Drawing.Imaging.PixelFormat.Format24bppRgb);
        using (Graphics g = Graphics.FromImage(enlarged))
        {
            g.Clear(Color.White);
            g.InterpolationMode = mode == 3 ? InterpolationMode.NearestNeighbor : InterpolationMode.HighQualityBicubic;
            g.DrawImage(prepared, new Rectangle(20, 20, sourceWidth * 5, sourceHeight * 5));
        }
        prepared.Dispose();
        return enlarged;
    }

    // Similaridade de amostragem com tolerancia a pequenas variacoes da interface.
    // O resultado vai de 0 a 100; exigir duas leituras antes de agir.
    public static int Compare(Bitmap expected, Bitmap observed)
    {
        if (expected == null || observed == null ||
            expected.Width != observed.Width || expected.Height != observed.Height) return 0;
        int dx = Math.Max(1, expected.Width / 52);
        int dy = Math.Max(1, expected.Height / 20);
        long diff = 0;
        long samples = 0;
        long matchingPixels = 0;
        long pixels = 0;
        for (int y = 0; y < expected.Height; y += dy)
        {
            for (int x = 0; x < expected.Width; x += dx)
            {
                Color a = expected.GetPixel(x, y);
                Color b = observed.GetPixel(x, y);
                int dr = Math.Abs((int)a.R - (int)b.R);
                int dg = Math.Abs((int)a.G - (int)b.G);
                int db = Math.Abs((int)a.B - (int)b.B);
                diff += dr + dg + db;
                if (Math.Max(dr, Math.Max(dg, db)) <= 35) matchingPixels++;
                pixels++;
                samples += 3;
            }
        }
        if (samples == 0 || pixels == 0) return 0;
        double pixelScore = matchingPixels * 100.0 / pixels;
        double colorScore = 100.0 - diff * 100.0 / (255.0 * samples);
        return (int)Math.Round(0.60 * pixelScore + 0.40 * colorScore);
    }

    // SendInput injeta um evento do mouse atraves do Windows, nao atraves
    // do teclado. Os eventos sao enviados SOMENTE se o launcher esta ativo.
    // Especificacao nativa: INPUT + MOUSEINPUT (alinhamento x64 automatico).
    [StructLayout(LayoutKind.Sequential)]
    private struct InputMouse
    {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct InputEvent
    {
        public uint type;
        public InputMouse mi;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, [In] InputEvent[] inputs, int cbSize);

    public static string LastTurnClickError = "";

    private static bool SendMouseButton(uint flag)
    {
        InputEvent[] input = new InputEvent[1];
        input[0].type = 0; // INPUT_MOUSE
        input[0].mi.dwFlags = flag;
        return SendInput(1, input, Marshal.SizeOf(typeof(InputEvent))) == 1;
    }

    // Os tempos podem ser ajustados na tela, sem alterar a rotina de OCR.
    public static int MoveDurationMs = 420;
    public static int HoverDurationMs = 600;
    public static int PressDurationMs = 180;
    public static int PostClickDurationMs = 650;

    // Movimento gradual e suave. O usuario ve a trajetoria e o Ruffle
    // recebe varios eventos de mousemove antes da pressao.
    private static bool MoveSmooth(int targetX, int targetY, int durationMs)
    {
        NativePoint from;
        if (!GetCursorPos(out from)) return false;
        int steps = Math.Max(1, Math.Min(100, durationMs / 18));
        int sleep = durationMs / steps;
        for (int i = 1; i <= steps; i++)
        {
            double u = (double)i / (double)steps;
            double ease = u * u * (3.0 - 2.0 * u);
            int x = (int)Math.Round(from.X + (targetX - from.X) * ease);
            int y = (int)Math.Round(from.Y + (targetY - from.Y) * ease);
            if (!SetCursorPos(x, y)) return false;
            if (sleep > 0) System.Threading.Thread.Sleep(sleep);
        }
        return SetCursorPos(targetX, targetY);
    }

    // Quando o usuario movimentar o mouse durante a pausa, nao forcar
    // o cursor de volta a uma posicao antiga.
    private static void ReturnIfAtTarget(NativePoint previous, int clickX, int clickY)
    {
        NativePoint current;
        if (GetCursorPos(out current) && Math.Abs(current.X-clickX) <= 8 && Math.Abs(current.Y-clickY) <= 8)
        {
            MoveSmooth(previous.X, previous.Y, Math.Max(75, MoveDurationMs / 2));
        }
    }

    // Para Turn in mantemos SendInput, que ja foi confirmado funcionando.
    public static bool ClickTurnIn(IntPtr hwnd, int clientX, int clientY)
    {
        LastTurnClickError = "";
        if (!IsActive(hwnd)) { LastTurnClickError = "AQW nao esta em primeiro plano."; return false; }
        Rectangle region = ClientBounds(hwnd);
        if (region.IsEmpty || clientX < 2 || clientY < 2 ||
            clientX >= region.Width - 2 || clientY >= region.Height - 2)
        { LastTurnClickError = "Coordenadas do Turn in fora da janela."; return false; }

        NativePoint previous;
        if (!GetCursorPos(out previous))
        { LastTurnClickError = "Falha ao obter a posicao do cursor."; return false; }

        int x = region.Left + clientX;
        int y = region.Top + clientY;
        bool mouseDown = false;
        try
        {
            if (!MoveSmooth(x, y, MoveDurationMs))
            { LastTurnClickError = "Nao consegui mover o cursor ate o botao."; return false; }
            // Espera no alvo: nao clicar assim que o cursor chegar.
            System.Threading.Thread.Sleep(HoverDurationMs);
            NativePoint actual;
            if (!IsActive(hwnd) || !GetCursorPos(out actual) ||
                Math.Abs(actual.X-x) > 5 || Math.Abs(actual.Y-y) > 5)
            { LastTurnClickError = "O mouse saiu do Turn in ou o jogo perdeu foco. Clique cancelado."; return false; }

            if (!SendMouseButton(0x0002)) // MOUSEEVENTF_LEFTDOWN
            {
                LastTurnClickError = "SendInput falhou no pressionamento. Windows: " +
                    Marshal.GetLastWin32Error().ToString();
                return false;
            }
            mouseDown = true;
            System.Threading.Thread.Sleep(PressDurationMs);
            if (!SendMouseButton(0x0004)) // MOUSEEVENTF_LEFTUP
            {
                LastTurnClickError = "SendInput falhou ao soltar o botao. Windows: " +
                    Marshal.GetLastWin32Error().ToString();
                return false;
            }
            mouseDown = false;
            System.Threading.Thread.Sleep(PostClickDurationMs);
            return true;
        }
        finally
        {
            if (mouseDown) SendMouseButton(0x0004);
            ReturnIfAtTarget(previous, x, y);
        }
    }

    // Mantem mouse_event para abrir a quest, como na V7.2 estavel.
    // Apenas movimento, espera e pressionamento ficam mais tranquilos.
    public static bool Click(IntPtr hwnd, int clientX, int clientY)
    {
        if (!IsActive(hwnd)) return false;
        Rectangle region = ClientBounds(hwnd);
        if (region.IsEmpty || clientX < 0 || clientY < 0 ||
            clientX >= region.Width || clientY >= region.Height) return false;
        NativePoint previous;
        if (!GetCursorPos(out previous)) return false;
        int x = region.Left + clientX;
        int y = region.Top + clientY;
        bool mouseDown = false;
        try
        {
            if (!MoveSmooth(x, y, MoveDurationMs)) return false;
            System.Threading.Thread.Sleep(HoverDurationMs);
            NativePoint actual;
            if (!IsActive(hwnd) || !GetCursorPos(out actual) ||
                Math.Abs(actual.X - x) > 5 || Math.Abs(actual.Y - y) > 5) return false;
            mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero);
            mouseDown = true;
            System.Threading.Thread.Sleep(PressDurationMs);
            mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);
            mouseDown = false;
            System.Threading.Thread.Sleep(PostClickDurationMs);
            return true;
        }
        finally
        {
            if (mouseDown) mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);
            ReturnIfAtTarget(previous, x, y);
        }
    }

}

// Seletor de calibracao: a captura original mantem a resolucao real do cliente.
// O usuario visualiza uma copia ajustada ao monitor ou com zoom/rolagem.
// A selecao e sempre convertida de volta para pixels da imagem ORIGINAL;
// assim OCR, cliques e coordenadas salvas nao precisam de alteracoes.
public sealed class AQWQuestPicker : Form
{
    private readonly Bitmap snapshot;
    private readonly Panel viewport;
    private readonly PictureBox picture;
    private readonly Label information;
    private Point starting;
    private bool dragging;
    private Rectangle visualSelection = Rectangle.Empty;
    private float zoom = 1f;
    private bool autoFit = true;

    public Rectangle Selection { get; private set; }

    public AQWQuestPicker(Bitmap image, Point screenOrigin)
        : this(image, screenOrigin, false) { }

    public AQWQuestPicker(Bitmap image, Point screenOrigin, bool allowEntireMonitor)
    {
        snapshot = image;
        Selection = Rectangle.Empty;
        AutoScaleMode = AutoScaleMode.None; // coordenadas estaveis no formulario
        FormBorderStyle = FormBorderStyle.Sizable;
        ShowInTaskbar = false;
        TopMost = true;
        StartPosition = FormStartPosition.Manual;
        Text = "AQW Jords - Calibrar regiao da quest";
        BackColor = Color.FromArgb(10, 20, 32);
        ForeColor = Color.White;
        Font = new Font("Segoe UI", 9f);
        KeyPreview = true;
        DoubleBuffered = true;
        MinimizeBox = false;

        // LIMITA o dialogo ao monitor real em vez de usar o tamanho da captura
        // como tamanho da janela. Evita a imagem gigantesca e fora da tela.
        Rectangle area = Screen.FromPoint(screenOrigin).WorkingArea;
        int maxWidth = Math.Max(460, area.Width - 64);
        int maxHeight = Math.Max(350, area.Height - 64);
        int preferredWidth = Math.Max(740, image.Width + 32);
        int preferredHeight = Math.Max(520, image.Height + 80);
        int windowWidth = Math.Min(maxWidth, preferredWidth);
        int windowHeight = Math.Min(maxHeight, preferredHeight);
        ClientSize = new Size(windowWidth, windowHeight);
        MinimumSize = new Size(Math.Min(windowWidth, 520), Math.Min(windowHeight, 350));
        Location = new Point(area.Left + Math.Max(0, (area.Width - Width) / 2),
                             area.Top + Math.Max(0, (area.Height - Height) / 2));

        viewport = new Panel();
        viewport.Dock = DockStyle.Fill;
        viewport.AutoScroll = true;
        viewport.BackColor = Color.FromArgb(5, 12, 20);
        viewport.BorderStyle = BorderStyle.FixedSingle;

        picture = new PictureBox();
        picture.SizeMode = PictureBoxSizeMode.StretchImage;
        picture.Image = snapshot;
        picture.BackColor = Color.Black;
        picture.Cursor = Cursors.Cross;
        picture.MouseDown += delegate(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dragging = true;
                starting = ClampPoint(e.Location);
                visualSelection = Rectangle.Empty;
                picture.Capture = true;
            }
        };
        picture.MouseMove += delegate(object sender, MouseEventArgs e)
        {
            if (!dragging) return;
            Point end = ClampPoint(e.Location);
            visualSelection = Rectangle.FromLTRB(Math.Min(starting.X, end.X), Math.Min(starting.Y, end.Y),
                                                 Math.Max(starting.X, end.X), Math.Max(starting.Y, end.Y));
            picture.Invalidate();
        };
        picture.MouseUp += delegate(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left || !dragging) return;
            dragging = false;
            picture.Capture = false;
            Point end = ClampPoint(e.Location);
            visualSelection = Rectangle.FromLTRB(Math.Min(starting.X, end.X), Math.Min(starting.Y, end.Y),
                                                 Math.Max(starting.X, end.X), Math.Max(starting.Y, end.Y));
            Rectangle selection = ConvertToOriginalPixels(visualSelection);
            if (selection.Width >= 18 && selection.Height >= 10)
            {
                Selection = selection;
                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                visualSelection = Rectangle.Empty;
                information.Text = "Area pequena demais. Amplie com + ou 100% e selecione novamente.";
                picture.Invalidate();
            }
        };
        picture.Paint += delegate(object sender, PaintEventArgs e)
        {
            if (visualSelection.IsEmpty) return;
            using (Brush fill = new SolidBrush(Color.FromArgb(65, 70, 177, 255)))
                e.Graphics.FillRectangle(fill, visualSelection);
            using (Pen pen = new Pen(Color.FromArgb(255, 71, 196, 255), 2f))
                e.Graphics.DrawRectangle(pen, visualSelection);
        };
        viewport.Controls.Add(picture);
        Controls.Add(viewport);

        FlowLayoutPanel toolbar = new FlowLayoutPanel();
        toolbar.Dock = DockStyle.Top;
        toolbar.Height = 59;
        toolbar.WrapContents = false;
        toolbar.Padding = new Padding(9, 8, 5, 4);
        toolbar.BackColor = Color.FromArgb(19, 36, 55);
        toolbar.AutoScroll = true;
        information = new Label();
        information.Text = "Arraste para marcar. ESC cancela.";
        information.AutoSize = false;
        information.Size = new Size(290, 39);
        information.TextAlign = ContentAlignment.MiddleLeft;
        information.ForeColor = Color.FromArgb(226, 238, 252);
        toolbar.Controls.Add(information);

        Button fit = ToolbarButton("Ajustar", 85);
        Button actual = ToolbarButton("100%", 72);
        Button minus = ToolbarButton("-", 38);
        Button plus = ToolbarButton("+", 38);
        toolbar.Controls.Add(fit);
        toolbar.Controls.Add(actual);
        toolbar.Controls.Add(minus);
        toolbar.Controls.Add(plus);
        if (allowEntireMonitor)
        {
            Button allScreen = ToolbarButton("Monitor inteiro", 130);
            toolbar.Controls.Add(allScreen);
            allScreen.Click += delegate(object sender, EventArgs e)
            {
                Selection = new Rectangle(0, 0, snapshot.Width, snapshot.Height);
                DialogResult = DialogResult.OK;
                Close();
            };
        }
        Controls.Add(toolbar);
        toolbar.BringToFront();

        fit.Click += delegate(object sender, EventArgs e) { autoFit = true; ApplyFit(); };
        actual.Click += delegate(object sender, EventArgs e) { autoFit = false; ApplyZoom(1f); };
        minus.Click += delegate(object sender, EventArgs e) { autoFit = false; ApplyZoom(zoom / 1.25f); };
        plus.Click += delegate(object sender, EventArgs e) { autoFit = false; ApplyZoom(zoom * 1.25f); };
        viewport.Resize += delegate(object sender, EventArgs e)
        {
            if (autoFit) ApplyFit(); else ApplyZoom(zoom);
        };
        Shown += delegate(object sender, EventArgs e) { ApplyFit(); };
    }

    private Button ToolbarButton(string caption, int width)
    {
        Button result = new Button();
        result.Text = caption;
        result.Width = width;
        result.Height = 34;
        result.Margin = new Padding(3, 3, 3, 0);
        result.FlatStyle = FlatStyle.Flat;
        result.FlatAppearance.BorderColor = Color.FromArgb(75, 110, 150);
        result.BackColor = Color.FromArgb(34, 57, 82);
        result.ForeColor = Color.White;
        result.Cursor = Cursors.Hand;
        return result;
    }

    private void ApplyFit()
    {
        if (viewport.ClientSize.Width <= 20 || viewport.ClientSize.Height <= 20) return;
        float scaleX = (float)(viewport.ClientSize.Width - 20) / snapshot.Width;
        float scaleY = (float)(viewport.ClientSize.Height - 20) / snapshot.Height;
        ApplyZoom(Math.Min(1f, Math.Min(scaleX, scaleY)));
    }

    private void ApplyZoom(float value)
    {
        zoom = Math.Max(0.10f, Math.Min(4f, value));
        int width = Math.Max(1, (int)Math.Round(snapshot.Width * zoom));
        int height = Math.Max(1, (int)Math.Round(snapshot.Height * zoom));
        viewport.AutoScrollMinSize = new Size(width, height);
        picture.Size = new Size(width, height);
        picture.Location = new Point(Math.Max(0, (viewport.ClientSize.Width - width) / 2),
                                     Math.Max(0, (viewport.ClientSize.Height - height) / 2));
        visualSelection = Rectangle.Empty;
        picture.Invalidate();
        information.Text = string.Format("Imagem {0} x {1} | Zoom {2:0}% | ESC cancela",
                                         snapshot.Width, snapshot.Height, zoom * 100);
    }

    private Point ClampPoint(Point location)
    {
        return new Point(Math.Max(0, Math.Min(picture.Width, location.X)),
                         Math.Max(0, Math.Min(picture.Height, location.Y)));
    }

    private Rectangle ConvertToOriginalPixels(Rectangle selection)
    {
        // Converter do preview para a resolucao original da captura; as
        // coordenadas existentes de quests, OCR e Turn in! permanecem identicas.
        int left = Math.Max(0, Math.Min(snapshot.Width, (int)Math.Round(selection.Left / zoom)));
        int top = Math.Max(0, Math.Min(snapshot.Height, (int)Math.Round(selection.Top / zoom)));
        int right = Math.Max(left, Math.Min(snapshot.Width, (int)Math.Round(selection.Right / zoom)));
        int bottom = Math.Max(top, Math.Min(snapshot.Height, (int)Math.Round(selection.Bottom / zoom)));
        return Rectangle.FromLTRB(left, top, right, bottom);
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape)
        {
            DialogResult = DialogResult.Cancel;
            Close();
            e.Handled = true;
            return;
        }
        base.OnKeyDown(e);
    }
}
public static class AQWJordsIdentity
{
    [System.Runtime.InteropServices.DllImport("shell32.dll", CharSet=System.Runtime.InteropServices.CharSet.Unicode)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(string appID);
    public static void Apply() { SetCurrentProcessExplicitAppUserModelID("AQWJords.Desktop.V8"); }
}

[System.Runtime.InteropServices.ComVisible(true)]
[System.Runtime.InteropServices.ClassInterface(System.Runtime.InteropServices.ClassInterfaceType.AutoDual)]
public class AQWJordsWebBridge
{
    public event Action<string> Request;
    public void Send(string command)
    {
        Action<string> callback = Request;
        if (callback != null) callback(command);
    }
}

'@
Add-Type -TypeDefinition $source -ReferencedAssemblies @('System.Windows.Forms', 'System.Drawing') -ErrorAction Stop

[System.Windows.Forms.Application]::EnableVisualStyles()

# --- Estado / paleta ---
$script:targetHandle = [IntPtr]::Zero
$script:mainHandle = [IntPtr]::Zero
$script:targetTitle = ''
$script:activeSequence = @()
$script:sequenceIndex = 0
$script:sentCount = 0
$script:sendMode = 0
$script:isRunning = $false
$script:isPaused = $false
$script:hotkeyInitialized = $false
$script:activeHotkeyLabel = ''

$bg = [System.Drawing.Color]::FromArgb(11, 18, 32)
$card = [System.Drawing.Color]::FromArgb(23, 34, 53)
$inputBg = [System.Drawing.Color]::FromArgb(32, 47, 70)
$line = [System.Drawing.Color]::FromArgb(52, 72, 100)
$accent = [System.Drawing.Color]::FromArgb(81, 137, 249)
$green = [System.Drawing.Color]::FromArgb(39, 174, 128)
$text = [System.Drawing.Color]::FromArgb(239, 245, 255)
$muted = [System.Drawing.Color]::FromArgb(159, 178, 207)
$subtle = [System.Drawing.Color]::FromArgb(121, 145, 178)

try { [AQWJordsIdentity]::Apply() } catch { }
$form = New-Object System.Windows.Forms.Form
$form.Text = 'AQW Jords | V8.3.4'
$form.Size = New-Object System.Drawing.Size(990, 785)
$form.MinimumSize = New-Object System.Drawing.Size(790, 640)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$form.BackColor = $bg
$form.ForeColor = $text
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
# The executable passes its icon and a readiness marker for error diagnostics.
try {
    if (-not [string]::IsNullOrWhiteSpace($env:AQW_HOST_EXE) -and (Test-Path -LiteralPath $env:AQW_HOST_EXE)) {
        $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($env:AQW_HOST_EXE)
    }
    if (-not [string]::IsNullOrWhiteSpace($env:AQW_ICON_FILE) -and (Test-Path -LiteralPath $env:AQW_ICON_FILE)) {
        $form.Icon = [System.Drawing.Icon]::new($env:AQW_ICON_FILE)
    }
} catch { }
$form.Add_Shown({
    $form.BringToFront()
    [void]$form.Activate()
    if (-not [string]::IsNullOrWhiteSpace($env:AQW_READY_FILE)) {
        try { [System.IO.File]::WriteAllText($env:AQW_READY_FILE, 'shown') } catch { }
    }
})

$layoutRoot = New-Object System.Windows.Forms.TableLayoutPanel
$layoutRoot.Dock = [System.Windows.Forms.DockStyle]::Fill
$layoutRoot.ColumnCount = 1
$layoutRoot.RowCount = 3
$layoutRoot.Padding = New-Object System.Windows.Forms.Padding(0)
$layoutRoot.Margin = New-Object System.Windows.Forms.Padding(0)
$columnStyle = New-Object System.Windows.Forms.ColumnStyle
$columnStyle.SizeType = [System.Windows.Forms.SizeType]::Percent
$columnStyle.Width = 100
[void]$layoutRoot.ColumnStyles.Add($columnStyle)
$rowHeader = New-Object System.Windows.Forms.RowStyle
$rowHeader.SizeType = [System.Windows.Forms.SizeType]::Absolute
$rowHeader.Height = 91
[void]$layoutRoot.RowStyles.Add($rowHeader)
$rowBody = New-Object System.Windows.Forms.RowStyle
$rowBody.SizeType = [System.Windows.Forms.SizeType]::Percent
$rowBody.Height = 100
[void]$layoutRoot.RowStyles.Add($rowBody)
$rowFooter = New-Object System.Windows.Forms.RowStyle
$rowFooter.SizeType = [System.Windows.Forms.SizeType]::Absolute
$rowFooter.Height = 186
[void]$layoutRoot.RowStyles.Add($rowFooter)
$form.Controls.Add($layoutRoot)

function New-UiLabel($parent, [string]$value, [int]$x, [int]$y, [int]$w, [int]$h, [int]$size = 10, [bool]$bold = $false, $color = $null) {
    $control = New-Object System.Windows.Forms.Label
    $control.Text = $value
    $control.Location = New-Object System.Drawing.Point($x, $y)
    $control.Size = New-Object System.Drawing.Size($w, $h)
    $style = [System.Drawing.FontStyle]::Regular
    if ($bold) { $style = [System.Drawing.FontStyle]::Bold }
    $control.Font = New-Object System.Drawing.Font('Segoe UI', $size, $style)
    $control.ForeColor = $text
    if ($null -ne $color) { $control.ForeColor = $color }
    $control.BackColor = [System.Drawing.Color]::Transparent
    $parent.Controls.Add($control)
    return $control
}

function New-UiButton($parent, [string]$value, [int]$x, [int]$y, [int]$w, [int]$h, $background, [bool]$isPrimary = $false) {
    $control = New-Object System.Windows.Forms.Button
    $control.Text = $value
    $control.Location = New-Object System.Drawing.Point($x, $y)
    $control.Size = New-Object System.Drawing.Size($w, $h)
    $control.BackColor = $background
    $control.ForeColor = $text
    $control.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $control.FlatAppearance.BorderSize = 0
    $control.Cursor = [System.Windows.Forms.Cursors]::Hand
    $control.UseVisualStyleBackColor = $false
    if ($isPrimary) { $control.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold) }
    $control.Add_Resize({ param($sender, $eventArgs) [AQWVisuals]::Round($sender, 9) })
    $parent.Controls.Add($control)
    [AQWVisuals]::Round($control, 9)
    return $control
}

function New-UiCombo($parent, [int]$x, [int]$y, [int]$w) {
    $control = New-Object System.Windows.Forms.ComboBox
    $control.Location = New-Object System.Drawing.Point($x, $y)
    $control.Size = New-Object System.Drawing.Size($w, 32)
    $control.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    $control.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $control.BackColor = $inputBg
    $control.ForeColor = $text
    $parent.Controls.Add($control)
    return $control
}

# --- Cabecalho ---
$header = New-Object System.Windows.Forms.Panel
$header.Dock = [System.Windows.Forms.DockStyle]::Fill
$header.Margin = New-Object System.Windows.Forms.Padding(0)
$header.Height = 91
$header.BackColor = $bg
$layoutRoot.Controls.Add($header, 0, 0)
$title = New-UiLabel $header 'Comandos direcionados' 23 13 620 39 20 $true
$desc = New-UiLabel $header 'Envio virtual para a janela escolhida, sem usar o teclado fisico.' 25 55 780 25 10 $false $muted
$version = New-UiLabel $header 'AQW  /  V7.6' 800 23 142 26 10 $true $accent
$version.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$version.Anchor = 'Top,Right'

# --- Rodape sempre visivel ---
$footer = New-Object System.Windows.Forms.Panel
$footer.Dock = [System.Windows.Forms.DockStyle]::Fill
$footer.Margin = New-Object System.Windows.Forms.Padding(0)
$footer.Height = 186
$footer.BackColor = [System.Drawing.Color]::FromArgb(16, 27, 44)
$layoutRoot.Controls.Add($footer, 0, 2)
$sendLabel = New-UiLabel $footer 'MODO DE ENVIO' 23 12 280 22 9 $true $muted
$methodCombo = New-UiCombo $footer 23 38 348
[void]$methodCombo.Items.Add('KeyDown + KeyUp (V2.1)')
[void]$methodCombo.Items.Add('KeyDown + Char + KeyUp')
[void]$methodCombo.Items.Add('Char (experimental)')
$methodCombo.SelectedIndex = 0
$start = New-UiButton $footer 'Iniciar sequencia' 608 33 166 42 $green $true
$stop = New-UiButton $footer 'Parar' 786 33 150 42 $inputBg $true
$stop.Enabled = $false
# Atalho global continua ativo mesmo se esta janela estiver minimizada.
$hotkeyLabel = New-UiLabel $footer 'ATALHO GLOBAL PARA INICIAR / PAUSAR' 23 87 310 22 9 $true $muted
$hotkeyCombo = New-UiCombo $footer 347 84 216
foreach ($n in 1..11) { [void]$hotkeyCombo.Items.Add("F$n") }
foreach ($n in 1..11) { [void]$hotkeyCombo.Items.Add("Ctrl + F$n") }
foreach ($n in 1..11) { [void]$hotkeyCombo.Items.Add("Ctrl + Shift + F$n") }
foreach ($letter in [char[]]'ABCDEFGHIJKLMNOPQRSTUVWXYZ') { [void]$hotkeyCombo.Items.Add("Ctrl + $letter") }
foreach ($digit in 0..9) { [void]$hotkeyCombo.Items.Add("Ctrl + $digit") }
$hotkeyCombo.SelectedItem = 'F3'
$hotkeyHint = New-UiLabel $footer 'Funciona com o app minimizado.' 575 88 370 30 9 $false $muted
$status = New-UiLabel $footer 'Pronto. Escolha e fixe uma janela.' 23 138 915 30 10 $false $muted
$status.AutoEllipsis = $true

# --- Conteudo rolavel, redimensionavel ---
$scroll = New-Object System.Windows.Forms.Panel
$scroll.Dock = [System.Windows.Forms.DockStyle]::Fill
$scroll.Margin = New-Object System.Windows.Forms.Padding(0)
$scroll.AutoScroll = $true
$scroll.BackColor = $bg
$layoutRoot.Controls.Add($scroll, 0, 1)

$content = New-Object System.Windows.Forms.Panel
$content.Location = New-Object System.Drawing.Point(22, 5)
$content.Size = New-Object System.Drawing.Size(928, 1570)
$content.BackColor = $bg
$scroll.Controls.Add($content)

$targetCard = New-Object System.Windows.Forms.Panel
$targetCard.Location = New-Object System.Drawing.Point(0, 0)
$targetCard.Size = New-Object System.Drawing.Size(928, 235)
$targetCard.BackColor = $card
$content.Controls.Add($targetCard)
[AQWVisuals]::Round($targetCard, 14)
$targetCard.Add_Resize({ param($sender, $eventArgs) [AQWVisuals]::Round($sender, 14) })

$targetHeading = New-UiLabel $targetCard '01   Aplicativo de destino' 20 14 600 30 13 $true
$targetHint = New-UiLabel $targetCard 'Selecione o aplicativo e fixe a janela. Mantenha o mesmo componente que funcionou antes.' 20 46 850 24 9 $false $muted
$appLabel = New-UiLabel $targetCard 'JANELAS ABERTAS' 20 74 250 18 8 $true $subtle
$combo = New-UiCombo $targetCard 20 96 765
$combo.DisplayMember = 'Display'
$refresh = New-UiButton $targetCard 'Atualizar' 799 94 108 34 $inputBg
$pin = New-UiButton $targetCard 'Fixar janela' 20 139 150 39 $accent $true
$pinInfo = New-UiLabel $targetCard 'Nenhuma janela fixada.' 183 145 720 32 9 $false $muted
$pinInfo.AutoEllipsis = $true
$componentLabel = New-UiLabel $targetCard 'COMPONENTE DO APLICATIVO (AVANCADO)' 20 182 590 18 8 $true $subtle
$subcombo = New-UiCombo $targetCard 20 202 887
$subcombo.DisplayMember = 'Display'

$sequenceCard = New-Object System.Windows.Forms.Panel
$sequenceCard.Location = New-Object System.Drawing.Point(0, 250)
$sequenceCard.Size = New-Object System.Drawing.Size(928, 424)
$sequenceCard.BackColor = $card
$content.Controls.Add($sequenceCard)
[AQWVisuals]::Round($sequenceCard, 14)
$sequenceCard.Add_Resize({ param($sender, $eventArgs) [AQWVisuals]::Round($sender, 14) })

$sequenceHeading = New-UiLabel $sequenceCard '02   Sequencia e tempo de cada tecla' 20 15 800 30 13 $true
$sequenceHint = New-UiLabel $sequenceCard 'A ordem e de cima para baixo. O intervalo e a espera APOS cada envio.' 20 47 850 24 9 $false $muted

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object System.Drawing.Point(20, 86)
$grid.Size = New-Object System.Drawing.Size(634, 273)
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.AllowUserToResizeRows = $false
$grid.AllowUserToResizeColumns = $false
$grid.RowHeadersVisible = $false
$grid.MultiSelect = $false
$grid.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
$grid.EditMode = [System.Windows.Forms.DataGridViewEditMode]::EditOnEnter
$grid.BackgroundColor = $inputBg
$grid.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$grid.GridColor = $line
$grid.EnableHeadersVisualStyles = $false
$grid.ColumnHeadersHeight = 38
$grid.RowTemplate.Height = 36
$grid.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(42, 61, 87)
$grid.ColumnHeadersDefaultCellStyle.ForeColor = $text
$grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(42, 61, 87)
$grid.ColumnHeadersDefaultCellStyle.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
$grid.DefaultCellStyle.BackColor = $inputBg
$grid.DefaultCellStyle.ForeColor = $text
$grid.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(55, 79, 113)
$grid.DefaultCellStyle.SelectionForeColor = $text
$grid.DefaultCellStyle.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$grid.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(8, 1, 8, 1)
$grid.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(36, 52, 75)
$grid.AlternatingRowsDefaultCellStyle.ForeColor = $text
$grid.AlternatingRowsDefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(55, 79, 113)
$grid.AlternatingRowsDefaultCellStyle.SelectionForeColor = $text
$grid.CellBorderStyle = [System.Windows.Forms.DataGridViewCellBorderStyle]::SingleHorizontal

$cEnabled = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$cEnabled.Name = 'Ativar'
$cEnabled.HeaderText = 'Usar'
$cEnabled.Width = 69
$cEnabled.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::NotSortable
$cEnabled.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
[void]$grid.Columns.Add($cEnabled)
$cKey = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$cKey.Name = 'Tecla'
$cKey.HeaderText = 'Tecla'
$cKey.Width = 120
$cKey.ReadOnly = $true
$cKey.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::NotSortable
[void]$grid.Columns.Add($cKey)
$cMs = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$cMs.Name = 'Espera'
$cMs.HeaderText = 'Espera apos (ms)'
$cMs.AutoSizeMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
$cMs.MinimumWidth = 175
$cMs.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::NotSortable
$cMs.DefaultCellStyle.Alignment = [System.Windows.Forms.DataGridViewContentAlignment]::MiddleRight
[void]$grid.Columns.Add($cMs)
$sequenceCard.Controls.Add($grid)

$chooseLabel = New-UiLabel $sequenceCard 'ADICIONAR UMA TECLA' 674 88 235 19 8 $true $subtle
$keyCombo = New-UiCombo $sequenceCard 674 111 232
foreach ($digit in 0..9) { [void]$keyCombo.Items.Add([string]$digit) }
foreach ($letter in [char[]]'ABCDEFGHIJKLMNOPQRSTUVWXYZ') { [void]$keyCombo.Items.Add([string]$letter) }
foreach ($n in 1..12) { [void]$keyCombo.Items.Add("F$n") }
foreach ($special in @('Espaco', 'Enter', 'Tab', 'Esc', 'Seta cima', 'Seta baixo', 'Seta esquerda', 'Seta direita')) { [void]$keyCombo.Items.Add($special) }
$keyCombo.SelectedItem = '1'
$add = New-UiButton $sequenceCard '+  Adicionar' 674 151 232 39 $accent $true
$remove = New-UiButton $sequenceCard 'Remover selecionada' 674 201 232 37 $inputBg
$up = New-UiButton $sequenceCard 'Subir  ↑' 674 249 111 37 $inputBg
$down = New-UiButton $sequenceCard 'Descer  ↓' 795 249 111 37 $inputBg
$editHint = New-UiLabel $sequenceCard 'Edite os ms diretamente na tabela. Voce pode repetir teclas e desativar linhas sem exclui-las.' 674 302 234 78 9 $false $muted
$gridHint = New-UiLabel $sequenceCard 'Exemplo: tecla 1 = 200 ms; tecla 2 = 300 ms. Apos a ultima, a sequencia recomeça.' 20 371 633 42 9 $false $muted


# --- 03  Quests por leitura de contador e clique visual (Windows OCR) ---
$script:questsPath = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'AQWComandos\QuestsV6'
$script:questsFile = Join-Path $script:questsPath 'quests-v6.json'
$script:questRecords = New-Object System.Collections.ArrayList
$script:questImages = @{}
$script:questWatchEnabled = $false
$script:questListLoading = $false
$script:ocrReady = $false
$script:ocrError = ''
$script:questSelected = $null
$script:questScanBusy = $false
$script:overlayReadings = @{}
$script:revalidateHotkeyInitialized = $false
$script:revalidateHotkeyLabel = ''
$script:overlaySignature = ''

$questCard = New-Object System.Windows.Forms.Panel
$questCard.Location = New-Object System.Drawing.Point(0, 689)
$questCard.Size = New-Object System.Drawing.Size(928, 845)
$questCard.BackColor = $card
$content.Controls.Add($questCard)
[AQWVisuals]::Round($questCard, 14)
$questCard.Add_Resize({ param($sender, $eventArgs) [AQWVisuals]::Round($sender, 14) })
$questHeading = New-UiLabel $questCard '03   Quests | contador + entrega visual' 20 15 850 30 13 $true
$questHelp = New-UiLabel $questCard 'Fluxo: ler TODOS os contadores X/Y; entregar apenas se todos estao completos; conferir a reducao apos o Turn in!' 20 48 880 50 9 $false $muted
$questHelp.AutoSize = $false
$questAdd = New-UiButton $questCard '+  Calibrar quest' 20 106 204 39 $accent $true
$questRemove = New-UiButton $questCard 'Remover' 238 106 126 39 $inputBg
$questToggle = New-UiButton $questCard 'Ativar monitor' 378 106 172 39 $green $true
$questAuto = New-Object System.Windows.Forms.CheckBox
$questAuto.Text = 'Entregar automaticamente'
$questAuto.Location = New-Object System.Drawing.Point(568, 112)
$questAuto.Size = New-Object System.Drawing.Size(320, 28)
$questAuto.ForeColor = $text
$questAuto.Checked = $false
$questCard.Controls.Add($questAuto)
$questList = New-Object System.Windows.Forms.ListView
$questList.Location = New-Object System.Drawing.Point(20, 212)
$questList.Size = New-Object System.Drawing.Size(888, 202)
$questList.View = [System.Windows.Forms.View]::Details
$questList.CheckBoxes = $true
$questList.FullRowSelect = $true
$questList.GridLines = $false
$questList.MultiSelect = $false
$questList.BackColor = $inputBg
$questList.ForeColor = $text
$questList.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$questList.Font = New-Object System.Drawing.Font('Segoe UI', 10)
[void]$questList.Columns.Add('Quest', 300)
[void]$questList.Columns.Add('Requisitos', 105)
[void]$questList.Columns.Add('Estado', 310)
[void]$questList.Columns.Add('Entregas', 102)
$questCard.Controls.Add($questList)
$questAddReq = New-UiButton $questCard '+ Requisito' 20 159 178 37 $inputBg
$questRemoveReq = New-UiButton $questCard '- Requisito' 211 159 178 37 $inputBg
$questReqDetails = New-UiButton $questCard 'Ver requisitos' 402 159 180 37 $inputBg
$questRevalidate = New-UiButton $questCard 'Revalidar quest' 596 159 174 37 $inputBg
$questReqHelp = New-UiLabel $questCard 'Recuperacao manual' 780 164 130 28 8 $false $muted
$questReqHelp.AutoSize = $false
$questThresholdLabel = New-UiLabel $questCard 'SIMILARIDADE DO BOTAO (%)' 20 428 275 25 9 $true $muted
$questThreshold = New-Object System.Windows.Forms.NumericUpDown
$questThreshold.Location = New-Object System.Drawing.Point(306, 428)
$questThreshold.Size = New-Object System.Drawing.Size(85, 28)
$questThreshold.Minimum = 75
$questThreshold.Maximum = 99
$questThreshold.Value = 88
$questThreshold.BackColor = $inputBg
$questThreshold.ForeColor = $text
$questCard.Controls.Add($questThreshold)
$questTest = New-UiButton $questCard 'Testar OCR + detalhes' 421 424 200 36 $inputBg
$questMap = New-UiButton $questCard 'Ver mapa da tela' 636 424 240 36 $inputBg
$mouseHeading = New-UiLabel $questCard 'RITMO DO MOUSE  |  EDITE EM MILISSEGUNDOS (MS)' 20 474 710 24 9 $true $muted
function New-MouseTimingControl([string]$label, [int]$x, [int]$initial, [int]$minimum, [int]$maximum) {
    [void](New-UiLabel $questCard $label $x 503 173 21 8 $true $subtle)
    $ctrl = New-Object System.Windows.Forms.NumericUpDown
    $ctrl.Location = New-Object System.Drawing.Point($x, 527)
    $ctrl.Size = New-Object System.Drawing.Size(150, 30)
    $ctrl.Minimum = $minimum
    $ctrl.Maximum = $maximum
    $ctrl.Increment = 50
    $ctrl.Value = $initial
    $ctrl.BackColor = $inputBg
    $ctrl.ForeColor = $text
    $ctrl.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $ctrl.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Right
    $questCard.Controls.Add($ctrl)
    return $ctrl
}
$mouseMove = New-MouseTimingControl 'MOVIMENTO' 20 420 50 1800
$mouseHover = New-MouseTimingControl 'ESPERA NO ALVO' 200 600 100 2500
$mousePress = New-MouseTimingControl 'CLIQUE PRESSIONADO' 380 180 60 650
$mouseAfter = New-MouseTimingControl 'PAUSA APOS CLIQUE' 560 650 100 3000

$script:mouseTimingFile = Join-Path $script:questsPath 'mouse-ritmo.json'
function Apply-MouseTiming {
    [AQWQuestVision]::MoveDurationMs = [int]$mouseMove.Value
    [AQWQuestVision]::HoverDurationMs = [int]$mouseHover.Value
    [AQWQuestVision]::PressDurationMs = [int]$mousePress.Value
    [AQWQuestVision]::PostClickDurationMs = [int]$mouseAfter.Value
}
function Save-MouseTiming {
    try {
        if (-not (Test-Path -LiteralPath $script:questsPath)) {
            [void](New-Item -ItemType Directory -Force -Path $script:questsPath)
        }
        $data = [ordered]@{
            Movement = [int]$mouseMove.Value
            Hover = [int]$mouseHover.Value
            Press = [int]$mousePress.Value
            After = [int]$mouseAfter.Value
        }
        [System.IO.File]::WriteAllText($script:mouseTimingFile, ($data | ConvertTo-Json), [System.Text.Encoding]::UTF8)
    } catch { $questInfo.Text = 'Nao foi possivel salvar ritmo: ' + $_.Exception.Message }
}
if (Test-Path -LiteralPath $script:mouseTimingFile) {
    try {
        $savedTiming = Get-Content -LiteralPath $script:mouseTimingFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $entries = @(
            [pscustomobject]@{ Control = $mouseMove; Stored = $savedTiming.Movement },
            [pscustomobject]@{ Control = $mouseHover; Stored = $savedTiming.Hover },
            [pscustomobject]@{ Control = $mousePress; Stored = $savedTiming.Press },
            [pscustomobject]@{ Control = $mouseAfter; Stored = $savedTiming.After }
        )
        foreach ($entry in $entries) {
            $ctrl = $entry.Control; $requested = [int]$entry.Stored
            if ($requested -ge [int]$ctrl.Minimum -and $requested -le [int]$ctrl.Maximum) {
                $ctrl.Value = $requested
            }
        }
    } catch { }
}
Apply-MouseTiming
foreach ($timingInput in @($mouseMove, $mouseHover, $mousePress, $mouseAfter)) {
    $timingInput.Add_ValueChanged({ Apply-MouseTiming; Save-MouseTiming })
}
$questInfo = New-UiLabel $questCard 'Falha de leitura? Use o painel de requisitos e F2 para revalidar, apos conferir a quest no jogo. A confirmacao do Turn in continua protegida.' 20 571 882 35 9 $false $muted
$questInfo.AutoSize = $false

# Painel flutuante: usa as leituras do proprio monitor, sem OCR duplicado.
$overlayCheckbox = New-Object System.Windows.Forms.CheckBox
$overlayCheckbox.Text = 'Exibir painel de requisitos sobre as janelas (sem capturar cliques)'
$overlayCheckbox.Location = New-Object System.Drawing.Point(20, 608)
$overlayCheckbox.Size = New-Object System.Drawing.Size(710, 29)
$overlayCheckbox.ForeColor = $text
$overlayCheckbox.Checked = $true
$questCard.Controls.Add($overlayCheckbox)
$overlayHotkeyLabel = New-UiLabel $questCard 'ATALHO GLOBAL PARA REVALIDAR' 20 651 290 24 9 $true $muted
$overlayHotkeyCombo = New-UiCombo $questCard 318 644 225
foreach ($n in 1..11) { [void]$overlayHotkeyCombo.Items.Add("F$n") }
foreach ($n in 1..11) { [void]$overlayHotkeyCombo.Items.Add("Ctrl + F$n") }
foreach ($n in 1..11) { [void]$overlayHotkeyCombo.Items.Add("Ctrl + Shift + F$n") }
foreach ($letter in [char[]]'ABCDEFGHIJKLMNOPQRSTUVWXYZ') { [void]$overlayHotkeyCombo.Items.Add("Ctrl + $letter") }
$overlayHotkeyCombo.SelectedItem = 'F2'
$overlayHotkeyHint = New-UiLabel $questCard 'F2: revalidar sem abrir o app' 558 648 352 28 9 $false $muted
$overlayCornerLabel = New-UiLabel $questCard 'POSICAO DO PAINEL' 20 698 240 22 9 $true $muted
$overlayCorner = New-UiCombo $questCard 231 690 315
foreach ($c in @('Inferior direito','Inferior esquerdo','Superior direito','Superior esquerdo')) { [void]$overlayCorner.Items.Add($c) }
$overlayCorner.SelectedIndex = 0
$overlayHint = New-UiLabel $questCard 'O painel e somente leitura: nao interfere no mouse. F2 prioriza quest com erro; outras devem ser selecionadas na lista.' 20 741 877 63 9 $false $muted
$overlayHint.AutoSize = $false
$manualAreaButton = New-UiButton $questCard 'Definir area do jogo (monitor)' 625 691 278 36 $inputBg
$manualAreaButton.Add_Click({ Set-AQWCaptureRegion })
$script:overlayConfigFile = Join-Path $script:questsPath 'painel-flutuante-v76.json'
if (Test-Path -LiteralPath $script:overlayConfigFile) {
    try {
        $oc = Get-Content -LiteralPath $script:overlayConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -ne $oc.Visible) { $overlayCheckbox.Checked = [bool]$oc.Visible }
        if ([string]$oc.Corner -in @('Inferior direito','Inferior esquerdo','Superior direito','Superior esquerdo')) { $overlayCorner.SelectedItem = [string]$oc.Corner }
        if (-not [string]::IsNullOrWhiteSpace([string]$oc.Hotkey) -and $overlayHotkeyCombo.Items.Contains([string]$oc.Hotkey)) { $overlayHotkeyCombo.SelectedItem = [string]$oc.Hotkey }
    } catch { }
}
function Save-OverlayConfig {
    try {
        if (-not (Test-Path -LiteralPath $script:questsPath)) { [void](New-Item -ItemType Directory -Force -Path $script:questsPath) }
        $cfg = [ordered]@{ Visible=[bool]$overlayCheckbox.Checked; Corner=[string]$overlayCorner.SelectedItem; Hotkey=[string]$overlayHotkeyCombo.SelectedItem }
        [System.IO.File]::WriteAllText($script:overlayConfigFile,($cfg | ConvertTo-Json),[System.Text.Encoding]::UTF8)
    } catch { $questInfo.Text = 'Falha ao salvar painel: ' + $_.Exception.Message }
}

$tooltip = New-Object System.Windows.Forms.ToolTip
$tooltip.SetToolTip($grid, 'Edite os intervalos em milissegundos: minimo 50, maximo 60000.')
$tooltip.SetToolTip($questRevalidate, 'Libera manualmente uma quest cuja ultima entrega nao pode ser confirmada. Confira primeiro no AQW.')
$tooltip.SetToolTip($subcombo, 'Se a versao anterior usou um componente interno, selecione o mesmo aqui.')
$tooltip.SetToolTip($methodCombo, 'O modo inicial corresponde ao funcionamento da V2.1.')

$script:keyMap = @{}
foreach ($d in 0..9) { $script:keyMap[[string]$d] = 48 + $d }
foreach ($ch in [char[]]'ABCDEFGHIJKLMNOPQRSTUVWXYZ') { $script:keyMap[[string]$ch] = [int]$ch }
foreach ($i in 1..12) { $script:keyMap["F$i"] = 111 + $i }
$script:keyMap['Espaco'] = 32
$script:keyMap['Enter'] = 13
$script:keyMap['Tab'] = 9
$script:keyMap['Esc'] = 27
$script:keyMap['Seta cima'] = 38
$script:keyMap['Seta baixo'] = 40
$script:keyMap['Seta esquerda'] = 37
$script:keyMap['Seta direita'] = 39

function Add-KeyRow([string]$key, [int]$ms = 1000, [bool]$enabled = $true) {
    $index = $grid.Rows.Add([object[]]@($enabled, $key, [string]$ms))
    $grid.ClearSelection()
    $grid.Rows[$index].Selected = $true
    $grid.CurrentCell = $grid.Rows[$index].Cells[1]
}
foreach ($key in @('1','2','3','4','5')) { Add-KeyRow $key 1000 $true }
$grid.ClearSelection()

function Layout-App {
    $width = [Math]::Max(726, $scroll.ClientSize.Width - 44)
    $content.Width = $width
    $targetCard.Width = $width
    $sequenceCard.Width = $width
    $questCard.Width = $width
    $questList.Width = $width - 40
    $questList.Columns[0].Width = [int](($width - 46) * 0.33)
    $questList.Columns[1].Width = 95
    $questList.Columns[2].Width = [Math]::Max(190, $width - 46 - $questList.Columns[0].Width - 95 - 102)
    $questList.Columns[3].Width = 102
    $questHelp.Width = $width - 40
    $questInfo.Width = $width - 40
    $questMap.Left = $width - 260
    $combo.Width = $width - 163
    $refresh.Left = $width - 128
    $pinInfo.Width = $width - 200
    $subcombo.Width = $width - 40
    $targetHint.Width = $width - 40
    $sequenceHint.Width = $width - 40
    $grid.Width = $width - 290
    $gridHint.Width = $width - 305
    $side = $width - 254
    $chooseLabel.Left = $side
    $keyCombo.Left = $side
    $add.Left = $side
    $remove.Left = $side
    $up.Left = $side
    $down.Left = $side + 121
    $editHint.Left = $side
    $status.Width = [Math]::Max(200, $footer.ClientSize.Width - 46)
    $start.Left = $footer.ClientSize.Width - 354
    $stop.Left = $footer.ClientSize.Width - 177
    $version.Left = $header.ClientSize.Width - 169
    $hotkeyHint.Width = [Math]::Max(175, $footer.ClientSize.Width - 600)
}
$scroll.Add_Resize({ Layout-App })
$form.Add_Shown({ Layout-App })
$form.Add_Resize({ Layout-App })

function Refresh-Targets {
    $combo.Items.Clear()
    $windows = @(
        foreach ($process in [System.Diagnostics.Process]::GetProcesses()) {
            try {
                if ($process.Id -eq $PID) { continue }
                if ($process.MainWindowHandle -eq [IntPtr]::Zero) { continue }
                $windowTitle = $process.MainWindowTitle
                if ([string]::IsNullOrWhiteSpace($windowTitle)) { continue }
                [pscustomobject]@{
                    Display = ('{0}  [PID {1}]' -f $windowTitle, $process.Id)
                    Handle  = $process.MainWindowHandle
                    Title   = $windowTitle
                }
            } catch { continue }
        }
    )
    foreach ($item in ($windows | Sort-Object Display)) { [void]$combo.Items.Add($item) }
    if ($combo.Items.Count -gt 0) { $combo.SelectedIndex = 0 }
}

function Stop-Autoclick([string]$message = 'Parado.') {
    $script:timer.Stop()
    $script:isRunning = $false
    $script:isPaused = $false
    foreach ($control in @($grid, $keyCombo, $add, $remove, $up, $down, $subcombo, $methodCombo, $combo, $refresh, $pin)) {
        $control.Enabled = $true
    }
    $start.Enabled = $true
    $start.Text = 'Iniciar sequencia'
    $stop.Enabled = $false
    $status.ForeColor = $muted
    $status.Text = $message
}


function Pause-Autoclick {
    if (-not $script:isRunning) { return }
    $script:timer.Stop()
    $script:isRunning = $false
    $script:isPaused = $true
    $start.Enabled = $true
    $start.Text = 'Retomar sequencia'
    $stop.Enabled = $true
    $status.ForeColor = $accent
    $status.Text = ('Pausado | {0} teclas enviadas | atalho: {1}' -f $script:sentCount, $script:activeHotkeyLabel)
}

function Resume-Autoclick {
    if (-not $script:isPaused) { return }
    if (-not [BackgroundKeySender]::IsWindow($script:targetHandle)) {
        Stop-Autoclick 'O aplicativo de destino foi fechado. Fixe novamente.'
        return
    }
    $script:isPaused = $false
    $script:isRunning = $true
    $start.Enabled = $false
    $start.Text = 'Iniciar sequencia'
    $stop.Enabled = $true
    Send-Next
    if ($script:isRunning) { $script:timer.Start() }
}

function Toggle-Automation {
    if ($script:isRunning) {
        Pause-Autoclick
    } elseif ($script:isPaused) {
        Resume-Autoclick
    } else {
        $start.PerformClick()
    }
}

# Win32 RegisterHotKey: no global keyboard hook or SendInput. Other apps retain normal typing.
function Set-SelectedHotkey {
    if ($null -eq $hotkeyCombo.SelectedItem) { return }
    $selected = [string]$hotkeyCombo.SelectedItem
    $keyName = ($selected -split ' \+ ')[-1]
    $matchKey = [regex]::Match($keyName, '^F(1[01]|[1-9])$')
    if ($matchKey.Success) {
        $vk = 111 + [int]$matchKey.Groups[1].Value
    } elseif ($keyName.Length -eq 1 -and $keyName -match '^[A-Z0-9]$') {
        $vk = [int][char]$keyName
    } else {
        return
    }
    [uint32]$mods = 0
    if ($selected.Contains('Ctrl')) { $mods = $mods -bor 2 }
    if ($selected.Contains('Shift')) { $mods = $mods -bor 4 }
    if ($script:hotkeyManager.ChangeHotkey($vk, $mods)) {
        $script:activeHotkeyLabel = $selected
        $hotkeyHint.Text = 'Ativo: ' + $selected + ' (mesmo minimizado)'
        return
    }
    $hotkeyHint.Text = 'Atalho ocupado por outro aplicativo.'
    if ($script:activeHotkeyLabel -ne '') {
        $hotkeyCombo.SelectedItem = $script:activeHotkeyLabel
    }
    [System.Windows.Forms.MessageBox]::Show(
        ('Nao foi possivel registrar {0}. A tecla pode estar em uso por outro aplicativo. Escolha outra.' -f $selected),
        'Atalho global indisponivel',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
}

$script:hotkeyManager = New-Object AQWHotkeyReceiver
$script:hotkeyManager.add_HotkeyPressed({ Toggle-Automation })
$hotkeyCombo.Add_SelectedIndexChanged({
    if ($script:hotkeyInitialized -and ([string]$hotkeyCombo.SelectedItem -ne $script:activeHotkeyLabel)) {
        Set-SelectedHotkey
    }
})
$form.Add_Shown({
    if (-not $script:hotkeyInitialized) {
        $script:hotkeyInitialized = $true
        Set-SelectedHotkey
    }
})

$script:timer = New-Object System.Windows.Forms.Timer
$script:timer.Interval = 1000

function Send-Next {
    if (-not $script:isRunning) { return }
    if (-not [BackgroundKeySender]::IsWindow($script:targetHandle)) {
        Stop-Autoclick 'Destino fechado ou componente indisponivel. Envio interrompido.'
        return
    }
    $step = $script:activeSequence[$script:sequenceIndex]
    $accepted = [BackgroundKeySender]::SendVirtualKey($script:targetHandle, [int]$step.VK, [int]$script:sendMode)
    if (-not $accepted) {
        Stop-Autoclick 'O Windows recusou a mensagem para a janela selecionada.'
        return
    }
    $script:sentCount++
    $script:sequenceIndex = ($script:sequenceIndex + 1) % $script:activeSequence.Count
    $script:timer.Interval = [int]$step.Ms
    $status.ForeColor = $green
    $status.Text = ('Enviando | {0} mensagens | Ultima: {1} | Proxima em {2} ms (envio nao confirma execucao no jogo)' -f $script:sentCount, $step.Key, $step.Ms)
}
$script:timer.Add_Tick({ Send-Next })


# --- Windows OCR: recursos ja presentes no Windows 10/11, sem acesso ao Ruffle ---
function Start-AQWOcr {
    if ($script:ocrReady) { return $true }
    try {
        Add-Type -AssemblyName System.Runtime.WindowsRuntime
        $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
        $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
        $null = [Windows.Foundation.IAsyncOperation`1, Windows.Foundation, ContentType=WindowsRuntime]
        $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType=WindowsRuntime]
        $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType=WindowsRuntime]
        $null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
        $script:ocrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
        if ($null -eq $script:ocrEngine) { throw 'Sem pacote de idioma OCR do Windows. Verifique Idioma e regiao.' }
        $script:ocrAwaiter = [WindowsRuntimeSystemExtensions].GetMember('GetAwaiter', 'Method', 'Public,Static') | Where-Object { $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
        if ($null -eq $script:ocrAwaiter) { throw 'A API de OCR do Windows nao respondeu.' }
        $script:ocrReady = $true
        return $true
    } catch { $script:ocrError = $_.Exception.Message; return $false }
}
function Await-AQW($task, [Type]$type) {
    return $script:ocrAwaiter.MakeGenericMethod($type).Invoke($null, @($task)).GetResult()
}
function Read-AQWCounter([System.Drawing.Rectangle]$roi, [int]$index = 1) {
    if (-not (Start-AQWOcr)) { $script:lastRawOCR = 'OCR indisponivel: ' + $script:ocrError; return $null }
    $bmp = $null
    $script:lastRawOCR = ''
    $script:ocrError = ''
    try {
        $bmp = [AQWQuestVision]::Capture($roi)
        if (-not (Test-Path -LiteralPath $script:questsPath)) { [void](New-Item -ItemType Directory -Path $script:questsPath -Force) }
        $bmp.Save((Join-Path $script:questsPath ('contador-req-{0}-original.png' -f $index)), [System.Drawing.Imaging.ImageFormat]::Png)
        for ($mode = 0; $mode -le 3; $mode++) {
            $large = $null; $stream = $null; $soft = $null
            try {
                $large = [AQWQuestVision]::CounterVersion($bmp, $mode)
                $imagePath = Join-Path $script:questsPath ('contador-req-{0}-ocr-{1}.png' -f $index,$mode)
                $large.Save($imagePath, [System.Drawing.Imaging.ImageFormat]::Png)
                $file = Await-AQW ([Windows.Storage.StorageFile]::GetFileFromPathAsync($imagePath)) ([Windows.Storage.StorageFile])
                $stream = Await-AQW ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
                $decoder = Await-AQW ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
                $soft = Await-AQW ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
                $result = Await-AQW ($script:ocrEngine.RecognizeAsync($soft)) ([Windows.Media.Ocr.OcrResult])
                $raw = [string]$result.Text
                $script:lastRawOCR += ('Teste {0}: [{1}]' -f $mode, $raw) + [Environment]::NewLine
                $normalized = $raw -replace '[Il]', '1' -replace '[oO]', '0'
                # A barra pode aparecer como | ou \\; nao a converta em um algarismo.
                $match = [regex]::Match($normalized, '(?<!\d)(\d{1,3})\s*[/\\|]\s*(\d{1,3})(?!\d)')
                if (-not $match.Success) { continue }
                $n = [int]$match.Groups[1].Value; $d = [int]$match.Groups[2].Value
                if ($d -le 0 -or $n -gt 999 -or $d -gt 999) { continue }
                return [pscustomobject]@{ Count=$n; Need=$d; Raw=$raw; Mode=$mode }
            } catch {
                $script:ocrError = $_.Exception.Message
                $script:lastRawOCR += ('Teste {0} ERRO: {1}' -f $mode, $script:ocrError) + [Environment]::NewLine
                # Uma falha na API nao deve apagar o motivo real do problema.
                if ($mode -eq 0 -and $script:ocrError -match 'Access|Denied|Cannot|nao foi possivel') { break }
            } finally {
                if ($null -ne $soft) { try { $soft.Dispose() } catch {} }
                if ($null -ne $stream) { try { $stream.Dispose() } catch {} }
                if ($null -ne $large) { $large.Dispose() }
            }
        }
        return $null
    } catch {
        $script:ocrError = $_.Exception.Message
        $script:lastRawOCR += ('Erro ao capturar o contador: ' + $script:ocrError)
        return $null
    } finally { if ($null -ne $bmp) { $bmp.Dispose() } }
}


# Preserva compatibilidade com quests V7.4, que tinham somente um X/Y.
function Get-AQWRequirements($q) {
    if ($null -ne $q.Requirements -and @($q.Requirements).Count -gt 0) {
        return @($q.Requirements | ForEach-Object { $_ })
    }
    return @([pscustomobject]@{ Name='Requisito 1'; X=[int]$q.CX; Y=[int]$q.CY; W=[int]$q.CW; H=[int]$q.CH })
}
function New-AQWRequirement($selection, [string]$name) {
    return [pscustomobject]@{ Name=$name; X=[int]$selection.X; Y=[int]$selection.Y; W=[int]$selection.Width; H=[int]$selection.Height }
}
function Save-QuestRecords {
    try {
        if (-not (Test-Path -LiteralPath $script:questsPath)) { [void](New-Item -ItemType Directory -Path $script:questsPath -Force) }
        $items = @(foreach ($q in $script:questRecords) {
            $reqs = @(foreach ($r in @(Get-AQWRequirements $q)) {
                [pscustomobject]@{ Name=[string]$r.Name; X=[int]$r.X; Y=[int]$r.Y; W=[int]$r.W; H=[int]$r.H }
            })
            [pscustomobject]@{ Name=[string]$q.Name; Enabled=[bool]$q.Enabled; File=[string]$q.File;
                CX=[int]$q.CX; CY=[int]$q.CY; CW=[int]$q.CW; CH=[int]$q.CH; Requirements=$reqs;
                QX=[int]$q.QX; QY=[int]$q.QY; TX=[int]$q.TX; TY=[int]$q.TY; TW=[int]$q.TW; TH=[int]$q.TH }
        })
        [System.IO.File]::WriteAllText($script:questsFile, (([pscustomobject]@{ Version=2; Threshold=[int]$questThreshold.Value; Items=$items }) | ConvertTo-Json -Depth 6), [System.Text.Encoding]::UTF8)
    } catch { $questInfo.Text = 'Falha ao salvar quests: ' + $_.Exception.Message }
}
function Add-QuestRecord($record) {
    $li = New-Object System.Windows.Forms.ListViewItem([string]$record.Name)
    $li.Tag = $record
    [void]$li.SubItems.Add(('{0} req.' -f @(Get-AQWRequirements $record).Count))
    [void]$li.SubItems.Add('Aguardando')
    [void]$li.SubItems.Add('0')
    $li.Checked = [bool]$record.Enabled
    [void]$questList.Items.Add($li)
}
function Load-QuestRecords {
    if (-not (Test-Path -LiteralPath $script:questsFile)) { return }
    try {
        $saved = Get-Content -LiteralPath $script:questsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $script:questListLoading = $true
        foreach ($q in @($saved.Items)) {
            if ($null -eq $q -or [string]$q.File -notmatch '^[a-fA-F0-9-]{36}\.png$') { continue }
            $file = Join-Path $script:questsPath ([string]$q.File)
            if (-not (Test-Path -LiteralPath $file)) { continue }
            $image = [System.Drawing.Bitmap]::new($file)
            if ($image.Width -ne [int]$q.TW -or $image.Height -ne [int]$q.TH) { $image.Dispose(); continue }
            $reqs = New-Object System.Collections.ArrayList
            if ($null -ne $q.Requirements) {
                foreach ($r in @($q.Requirements)) {
                    if ($null -eq $r -or [int]$r.W -lt 4 -or [int]$r.H -lt 4) { continue }
                    [void]$reqs.Add([pscustomobject]@{ Name=[string]$r.Name; X=[int]$r.X; Y=[int]$r.Y; W=[int]$r.W; H=[int]$r.H })
                }
            }
            if ($reqs.Count -eq 0) {
                [void]$reqs.Add([pscustomobject]@{ Name='Requisito 1'; X=[int]$q.CX; Y=[int]$q.CY; W=[int]$q.CW; H=[int]$q.CH })
            }
            $record = [pscustomobject]@{
                Name=[string]$q.Name; Enabled=[bool]$q.Enabled; File=[string]$q.File;
                CX=[int]$q.CX; CY=[int]$q.CY; CW=[int]$q.CW; CH=[int]$q.CH; Requirements=$reqs;
                QX=[int]$q.QX; QY=[int]$q.QY; TX=[int]$q.TX; TY=[int]$q.TY; TW=[int]$q.TW; TH=[int]$q.TH;
                Stage='Idle'; Due=[datetime]::MinValue; Before=0; BeforeReadings=@(); Hits=0; LastCounter=''; Turns=0; LastAlert=[datetime]::MinValue
            }
            $script:questImages[$record.File] = $image
            [void]$script:questRecords.Add($record)
            Add-QuestRecord $record
        }
        if ([int]$saved.Threshold -ge 75 -and [int]$saved.Threshold -le 99) { $questThreshold.Value = [int]$saved.Threshold }
    } catch { $questInfo.Text = 'Nao foi possivel carregar quests: ' + $_.Exception.Message }
    finally { $script:questListLoading = $false }
}
function Ask-QuestName {
    Add-Type -AssemblyName Microsoft.VisualBasic
    $name = [Microsoft.VisualBasic.Interaction]::InputBox('Nome da quest:', 'Calibrar quest', ('Quest {0}' -f ($script:questRecords.Count + 1)))
    if ([string]::IsNullOrWhiteSpace($name)) { return $null }
    return $name.Trim()
}
# Recurso opt-in para contornar captura parcial/monitor com DPI diferente.
# A regiao escolhida torna-se a MESMA origem para OCR e cliques; as selecoes
# originais continuam relativas a ClientBounds, que passa a ser a area manual.
function Set-AQWCaptureRegion {
    if ($script:mainHandle -eq [IntPtr]::Zero -or -not [BackgroundKeySender]::IsWindow($script:mainHandle)) {
        [System.Windows.Forms.MessageBox]::Show('Primeiro fixe a janela do AQW.', 'AQW Jords') | Out-Null
        return
    }
    $answer = [System.Windows.Forms.MessageBox]::Show(
        'A captura automatica pode estar cortando a area do jogo.' + "`n`n" +
        'Sera feita uma captura do MONITOR INTEIRO. Arraste um retangulo sobre toda a area jogavel do AQW (sem a barra de titulo do Windows).' + "`n" +
        'Se o jogo ocupar todo o monitor, clique em Monitor inteiro.' + "`n`n" +
        'Mantenha o AQW nesta posicao enquanto estiver monitorando. Deseja continuar?',
        'AQW Jords - Area manual da captura',
        [System.Windows.Forms.MessageBoxButtons]::OKCancel, [System.Windows.Forms.MessageBoxIcon]::Information)
    if ($answer -ne [System.Windows.Forms.DialogResult]::OK) { return }
    $snapshot = $null; $picker = $null
    try {
        $form.Hide()
        [AQWQuestVision]::Activate($script:mainHandle)
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 500
        $monitor = [AQWQuestVision]::MonitorBounds($script:mainHandle)
        if ($monitor.IsEmpty) { throw 'O monitor do AQW nao foi identificado.' }
        $snapshot = [AQWQuestVision]::Capture($monitor)
        $picker = [AQWQuestPicker]::new($snapshot, $monitor.Location, $true)
        $picker.Text = 'AQW Jords - Marcar area completa do jogo no monitor'
        if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $selection = $picker.Selection
        $selected = [System.Drawing.Rectangle]::new(($monitor.X + $selection.X), ($monitor.Y + $selection.Y), $selection.Width, $selection.Height)
        if ($selected.Width -lt 400 -or $selected.Height -lt 260) {
            throw 'Marque toda a area jogavel do AQW, e nao apenas o contador ou uma quest.'
        }
        [AQWQuestVision]::SetManualBounds($script:mainHandle, $selected)
        $questInfo.Text = ('Area manual: {0}x{1} pixels (X={2}, Y={3}). Agora calibre os requisitos.' -f $selected.Width,$selected.Height,$selected.X,$selected.Y)
        $status.Text = 'Area do AQW definida manualmente. Recalibre as quests se a janela mudou de tamanho.'
        [System.Windows.Forms.MessageBox]::Show(
            ('Captura definida: {0} x {1} pixels.' -f $selected.Width, $selected.Height) + "`n`n" +
            'Agora use Calibrar quest para marcar nome, contador e Turn in!.' + "`n" +
            'Se mover ou redimensionar a janela do AQW, defina a area novamente.',
            'AQW Jords - Captura configurada', [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    } catch {
        $questInfo.Text = 'Erro ao definir area manual: ' + $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'AQW Jords - Area de captura') | Out-Null
    } finally {
        if ($null -ne $picker) { $picker.Dispose() }
        if ($null -ne $snapshot) { $snapshot.Dispose() }
        $form.Show()
        $form.BringToFront()
    }
}

function Pick-AQWArea([string]$hint) {
    [System.Windows.Forms.MessageBox]::Show($hint + "`n`nSelecione a area com o mouse. ESC cancela.", 'Calibracao AQW', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    $snapshot = $null; $picker = $null
    try {
        $form.Hide()
        [AQWQuestVision]::Activate($script:mainHandle)
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 350
        $bounds = [AQWQuestVision]::ClientBounds($script:mainHandle)
        if ($bounds.IsEmpty) { throw 'Jogo nao localizado.' }
        $snapshot = [AQWQuestVision]::Capture($bounds)
        $picker = [AQWQuestPicker]::new($snapshot, $bounds.Location)
        if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
        return $picker.Selection
    } catch { $questInfo.Text = 'Falha na calibracao: ' + $_.Exception.Message; return $null }
    finally { if ($null -ne $picker) { $picker.Dispose() }; if ($null -ne $snapshot) { $snapshot.Dispose() }; $form.Show(); $form.BringToFront() }
}
function Register-QuestVisual {
    if ($script:mainHandle -eq [IntPtr]::Zero -or -not [BackgroundKeySender]::IsWindow($script:mainHandle)) {
        [System.Windows.Forms.MessageBox]::Show('Fixe a janela do AQW antes de calibrar.', 'AQW') | Out-Null; return
    }
    $name = Ask-QuestName
    if ([string]::IsNullOrWhiteSpace($name)) { return }
    $counter = Pick-AQWArea '1/3 - Selecione o PRIMEIRO requisito da quest, incluindo o nome do item e o contador X/Y. Depois de criar a quest, use + Requisito para cadastrar os demais.'
    if ($null -eq $counter) { return }
    $questButton = Pick-AQWArea '2/3 - Na janela de quests a ESQUERDA, marque o NOME da quest na lista, onde voce clica para abri-la. Nao marque o X de fechar.'
    if ($null -eq $questButton) { return }
    [System.Windows.Forms.MessageBox]::Show('Vou abrir a quest no jogo, usando a posicao que voce marcou. Depois selecione o botao Turn in! sem confirma-lo.', 'Preparar ultima captura') | Out-Null
    $form.Hide()
    [AQWQuestVision]::Activate($script:mainHandle)
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 350
    [void][AQWQuestVision]::Click($script:mainHandle, ($questButton.X + [int]($questButton.Width / 2)), ($questButton.Y + [int]($questButton.Height / 2)))
    Start-Sleep -Milliseconds 500
    $form.Show()
    $turnButton = Pick-AQWArea '3/3 - Com o detalhe da quest ABERTO, marque apenas o BOTAO Turn in! (o retangulo central inferior). Este sera o modelo visual para validar antes do clique.'
    if ($null -eq $turnButton) { return }
    try {
        $form.Hide()
        [AQWQuestVision]::Activate($script:mainHandle)
        Start-Sleep -Milliseconds 260
        $bounds = [AQWQuestVision]::ClientBounds($script:mainHandle)
        $part = [AQWQuestVision]::Capture([System.Drawing.Rectangle]::new(($bounds.Left + $turnButton.X), ($bounds.Top + $turnButton.Y), $turnButton.Width, $turnButton.Height))
        $form.Show()
        if (-not (Test-Path -LiteralPath $script:questsPath)) { [void](New-Item -ItemType Directory -Path $script:questsPath -Force) }
        $file = [guid]::NewGuid().ToString() + '.png'
        $part.Save((Join-Path $script:questsPath $file), [System.Drawing.Imaging.ImageFormat]::Png)
        $firstRequirements = New-Object System.Collections.ArrayList
        [void]$firstRequirements.Add((New-AQWRequirement $counter 'Requisito 1'))
        $record = [pscustomobject]@{
            Name=$name; Enabled=$true; File=$file; CX=$counter.X; CY=$counter.Y; CW=$counter.Width; CH=$counter.Height;
            Requirements=$firstRequirements;
            QX=($questButton.X + [int]($questButton.Width / 2)); QY=($questButton.Y + [int]($questButton.Height / 2));
            TX=$turnButton.X; TY=$turnButton.Y; TW=$turnButton.Width; TH=$turnButton.Height;
            Stage='Idle'; Due=[datetime]::MinValue; Before=0; BeforeReadings=@(); Hits=0; LastCounter=''; Turns=0; LastAlert=[datetime]::MinValue
        }
        $script:questImages[$file] = $part
        [void]$script:questRecords.Add($record)
        Add-QuestRecord $record
        Save-QuestRecords
        $questInfo.Text = ('Quest cadastrada: {0}. Se houver mais itens, selecione a quest e use + Requisito. Teste OCR antes de ativar.' -f $name)
    } catch { $questInfo.Text = 'Falha ao salvar quest: ' + $_.Exception.Message; $form.Show() }
}
function Get-QuestProgress($quest, $clientRect) {
    $requirements = @(Get-AQWRequirements $quest)
    if ($requirements.Count -eq 0) { return $null }
    $values = New-Object System.Collections.ArrayList
    $raws = New-Object System.Collections.ArrayList
    $rows = New-Object System.Collections.ArrayList
    foreach ($one in $requirements) {
        [void]$rows.Add([pscustomobject]@{ Name=[string]$one.Name; Value='--'; Status='Aguardando leitura' })
    }
    $index = 0
    $anyReadError = $false
    foreach ($req in $requirements) {
        $index++
        if ([int]$req.X -lt 0 -or [int]$req.Y -lt 0 -or [int]$req.W -lt 4 -or [int]$req.H -lt 4 -or
            ([int]$req.X + [int]$req.W) -gt $clientRect.Width -or
            ([int]$req.Y + [int]$req.H) -gt $clientRect.Height) {
            $rows[$index-1].Status = 'Falha: area fora da janela'
            [void]$raws.Add(('Requisito {0}: posicao fora da janela do AQW.' -f $index))
            $anyReadError = $true
            continue
        }
        $rect = [System.Drawing.Rectangle]::new(($clientRect.Left + [int]$req.X), ($clientRect.Top + [int]$req.Y), [int]$req.W, [int]$req.H)
        $reading = Read-AQWCounter $rect $index
        [void]$raws.Add(('Requisito {0} - {1}:{2}{3}' -f $index, [string]$req.Name, [Environment]::NewLine, $script:lastRawOCR))
        if ($null -eq $reading) {
            $rows[$index-1].Status = 'Falha de leitura (OCR)'
            $anyReadError = $true
            continue
        }
        $rows[$index-1].Value = ('{0}/{1}' -f $reading.Count,$reading.Need)
        $rows[$index-1].Status = $(if ([int]$reading.Count -ge [int]$reading.Need) { 'Completo' } else { 'Incompleto' })
        [void]$values.Add([pscustomobject]@{
            Name=[string]$req.Name; Count=[int]$reading.Count; Need=[int]$reading.Need;
            Ready=([int]$reading.Count -ge [int]$reading.Need); Mode=[int]$reading.Mode
        })
    }
    $script:overlayReadings[[string]$quest.File] = @($rows.ToArray())
    $script:lastRawOCR = ($raws -join ([Environment]::NewLine + [Environment]::NewLine))
    if ($anyReadError) { return $null }
    $readyCount = @($values | Where-Object { $_.Ready }).Count
    $signature = (@($values | ForEach-Object { '{0}/{1}' -f $_.Count, $_.Need }) -join ';')
    return [pscustomobject]@{
        Requirements=@($values.ToArray()); Ready=($readyCount -eq $values.Count);
        ReadyCount=$readyCount; Total=$values.Count; Signature=$signature;
        Count=[int]$values[0].Count; Need=[int]$values[0].Need; Mode=[int]$values[0].Mode
    }
}
# Diagnostico: captura a janela inteira e sobrepoe as coordenadas calibradas.
# Desenha apenas no arquivo de diagnostico; nao altera a imagem do jogo.
function Show-AQWQuestMap {
    if ($questList.SelectedItems.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Selecione uma quest cadastrada para visualizar as regioes.', 'Mapa visual') | Out-Null
        return
    }
    if ($script:mainHandle -eq [IntPtr]::Zero -or -not [BackgroundKeySender]::IsWindow($script:mainHandle)) { return }
    $q = $questList.SelectedItems[0].Tag
    $full = $null; $marked = $null; $viewer = $null
    try {
        $form.Hide()
        [AQWQuestVision]::Activate($script:mainHandle)
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 500
        $bounds = [AQWQuestVision]::ClientBounds($script:mainHandle)
        if ($bounds.IsEmpty) { throw 'Janela do AQW indisponivel.' }
        $full = [AQWQuestVision]::Capture($bounds)
        $marked = [System.Drawing.Bitmap]::new($full)
        $g = [System.Drawing.Graphics]::FromImage($marked)
        try {
            $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $f = [System.Drawing.Font]::new('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
            $counterPen = [System.Drawing.Pen]::new([System.Drawing.Color]::Lime, 3)
            $questPen = [System.Drawing.Pen]::new([System.Drawing.Color]::Yellow, 3)
            $turnPen = [System.Drawing.Pen]::new([System.Drawing.Color]::Cyan, 3)
            try {
                $ix = 0
                foreach ($r in @(Get-AQWRequirements $q)) {
                    $ix++
                    $g.DrawRectangle($counterPen, [int]$r.X, [int]$r.Y, [int]$r.W, [int]$r.H)
                    $g.DrawString(('REQUISITO {0}' -f $ix), $f, [System.Drawing.Brushes]::Lime, [float][Math]::Max(0,[int]$r.X), [float][Math]::Max(0,([int]$r.Y - 22)))
                }
                $g.DrawRectangle($questPen, [int]$q.QX - 8, [int]$q.QY - 8, 16, 16)
                $g.DrawRectangle($turnPen, [int]$q.TX, [int]$q.TY, [int]$q.TW, [int]$q.TH)
                # Os requisitos ja foram identificados acima.
                $g.DrawString('NOME DA QUEST', $f, [System.Drawing.Brushes]::Yellow, [float][Math]::Max(0,$q.QX), [float][Math]::Max(0,($q.QY - 25)))
                $g.DrawString('TURN IN', $f, [System.Drawing.Brushes]::Cyan, [float][Math]::Max(0,$q.TX), [float][Math]::Max(0,($q.TY - 22)))
            } finally { $counterPen.Dispose(); $questPen.Dispose(); $turnPen.Dispose(); $f.Dispose() }
        } finally { $g.Dispose() }
        if (-not (Test-Path -LiteralPath $script:questsPath)) { [void](New-Item -ItemType Directory -Path $script:questsPath -Force) }
        $savedPath = Join-Path $script:questsPath 'diagnostico_tela.png'
        $marked.Save($savedPath, [System.Drawing.Imaging.ImageFormat]::Png)
        $form.Show(); $form.BringToFront()
        $viewer = New-Object System.Windows.Forms.Form
        $viewer.Text = 'AQW V7 | Referencia visual - ' + [string]$q.Name
        $viewer.StartPosition = 'CenterParent'
        $viewer.Size = New-Object System.Drawing.Size(1050, 740)
        $viewer.MinimumSize = New-Object System.Drawing.Size(600, 430)
        $viewer.BackColor = $bg
        $image = New-Object System.Windows.Forms.PictureBox
        $image.Dock = [System.Windows.Forms.DockStyle]::Fill
        $image.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
        $image.Image = $marked
        $viewer.Controls.Add($image)
        $viewer.ShowDialog($form) | Out-Null
        $questInfo.Text = 'Mapa da janela salvo em ' + $savedPath + ' . Verde=contador, amarelo=quest, azul=Turn in.'
    } catch { $questInfo.Text = 'Erro no mapa: ' + $_.Exception.Message }
    finally {
        if ($null -ne $viewer) { $viewer.Dispose() }
        if ($null -ne $marked) { $marked.Dispose() }
        if ($null -ne $full) { $full.Dispose() }
        $form.Show(); $form.BringToFront()
    }
}


function Choose-AQWQuestRequirement($q) {
    $reqs = @(Get-AQWRequirements $q)
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Requisitos de ' + [string]$q.Name
    $dialog.Size = New-Object System.Drawing.Size(560, 400)
    $dialog.StartPosition = 'CenterParent'
    $dialog.BackColor = $card; $dialog.ForeColor = $text
    $dialog.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $list = New-Object System.Windows.Forms.ListBox
    $list.Location = New-Object System.Drawing.Point(16, 16)
    $list.Size = New-Object System.Drawing.Size(508, 273)
    $list.BackColor = $inputBg; $list.ForeColor = $text
    foreach ($r in $reqs) {
        [void]$list.Items.Add(('{0} | X={1}, Y={2}, {3}x{4}' -f $r.Name,$r.X,$r.Y,$r.W,$r.H))
    }
    $dialog.Controls.Add($list)
    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = 'Selecionar'; $ok.Location = New-Object System.Drawing.Point(270, 302)
    $ok.Size = New-Object System.Drawing.Size(118, 38)
    $ok.BackColor = $accent; $ok.ForeColor = $text
    $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dialog.Controls.Add($ok)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = 'Cancelar'; $cancel.Location = New-Object System.Drawing.Point(404, 302)
    $cancel.Size = New-Object System.Drawing.Size(118, 38)
    $cancel.BackColor = $inputBg; $cancel.ForeColor = $text
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dialog.Controls.Add($cancel)
    $dialog.AcceptButton = $ok; $dialog.CancelButton = $cancel
    try {
        if ($list.Items.Count -gt 0) { $list.SelectedIndex = 0 }
        if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) { return [int]$list.SelectedIndex }
    } finally { $dialog.Dispose() }
    return -1
}
function Add-AQWRequirementToSelectedQuest {
    if ($script:questWatchEnabled) { return }
    if ($questList.SelectedItems.Count -eq 0) { $questInfo.Text = 'Selecione uma quest para adicionar um requisito.'; return }
    $li = $questList.SelectedItems[0]; $q = $li.Tag
    $reqs = @(Get-AQWRequirements $q)
    Add-Type -AssemblyName Microsoft.VisualBasic
    $defaultName = 'Requisito ' + [string]($reqs.Count + 1)
    $name = [Microsoft.VisualBasic.Interaction]::InputBox('Nome do requisito (por exemplo Fragmento de Alma):','Novo requisito', $defaultName)
    if ([string]::IsNullOrWhiteSpace($name)) { return }
    $selected = Pick-AQWArea ('Marque o contador X/Y para ' + $name + '. Inclua o nome do item no recorte se isso melhorar o OCR.')
    if ($null -eq $selected) { return }
    [void]$q.Requirements.Add((New-AQWRequirement $selected $name.Trim()))
    $li.SubItems[1].Text = ('{0} req.' -f $q.Requirements.Count)
    $q.Hits = 0; $q.LastCounter = ''; $q.Stage = 'Idle'
    Save-QuestRecords
    $questInfo.Text = ('Adicionado requisito {0} a {1}. A entrega exige TODOS os requisitos.' -f $name,$q.Name)
}
function Remove-AQWRequirementFromSelectedQuest {
    if ($script:questWatchEnabled) { return }
    if ($questList.SelectedItems.Count -eq 0) { $questInfo.Text = 'Selecione a quest para remover um requisito.'; return }
    $li = $questList.SelectedItems[0]; $q = $li.Tag
    if (@(Get-AQWRequirements $q).Count -le 1) { $questInfo.Text = 'A quest precisa manter pelo menos um requisito.'; return }
    $ix = Choose-AQWQuestRequirement $q
    if ($ix -lt 0) { return }
    $q.Requirements.RemoveAt($ix)
    $q.Hits = 0; $q.LastCounter = ''; $q.Stage = 'Idle'
    $li.SubItems[1].Text = ('{0} req.' -f $q.Requirements.Count)
    Save-QuestRecords
    $questInfo.Text = 'Requisito removido. Os demais foram preservados.'
}
function Show-AQWRequirementDetails {
    if ($questList.SelectedItems.Count -eq 0) { $questInfo.Text = 'Selecione uma quest.'; return }
    $q = $questList.SelectedItems[0].Tag
    $rows = @('Quest: ' + [string]$q.Name, '', 'Requisitos cadastrados:')
    $i = 0
    foreach ($r in @(Get-AQWRequirements $q)) {
        $i++
        $rows += ('{0}. {1} | X={2}; Y={3}; {4}x{5}' -f $i,$r.Name,$r.X,$r.Y,$r.W,$r.H)
    }
    $rows += ''; $rows += 'A entrega exige que todos os contadores estejam completos.'
    [System.Windows.Forms.MessageBox]::Show(($rows -join [Environment]::NewLine),'Requisitos da quest') | Out-Null
}
# Overlay nao ativavel, TopMost, sem clique e com as leituras reais dos requisitos.
$script:overlayForm = New-Object AQWStatusOverlay
$script:overlayForm.Text = 'AQW Requisitos'
$script:overlayForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
$script:overlayForm.ShowInTaskbar = $false
$script:overlayForm.TopMost = $true
$script:overlayForm.Opacity = 0.92
$script:overlayForm.BackColor = [System.Drawing.Color]::FromArgb(12,20,34)
$script:overlayForm.Size = New-Object System.Drawing.Size(350,170)
$script:overlayBody = New-Object System.Windows.Forms.FlowLayoutPanel
$script:overlayBody.Dock = [System.Windows.Forms.DockStyle]::Fill
$script:overlayBody.FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown
$script:overlayBody.WrapContents = $false
$script:overlayBody.AutoScroll = $true
$script:overlayBody.Padding = New-Object System.Windows.Forms.Padding(10,8,8,6)
$script:overlayForm.Controls.Add($script:overlayBody)

function Get-OverlayRevalidateTarget {
    # Falhas primeiro; somente depois a quest selecionada na lista.
    foreach ($q in $script:questRecords) {
        if ($q.Enabled -and ($q.Stage -eq 'Recover' -or $q.Stage -eq 'Halted')) { return $q }
    }
    # Se nenhum clique ficou pendente, F2 atende um requisito que falhou no OCR.
    foreach ($q in $script:questRecords) {
        if (-not $q.Enabled -or -not $script:overlayReadings.ContainsKey([string]$q.File)) { continue }
        foreach ($r in @($script:overlayReadings[[string]$q.File])) {
            if ([string]$r.Status -match 'Falha') { return $q }
        }
    }
    if ($questList.SelectedItems.Count -gt 0) {
        $selectedQ = $questList.SelectedItems[0].Tag
        if ($selectedQ.Enabled) { return $selectedQ }
    }
    $enabled = @($script:questRecords | Where-Object { $_.Enabled })
    if ($enabled.Count -eq 1) { return $enabled[0] }
    return $null
}
function Revalidate-AQWQuest($q) {
    if ($null -eq $q) { $questInfo.Text = 'F2: selecione a quest na lista (mais de uma ativa sem erro).'; return }
    if (-not $script:questWatchEnabled) { $questInfo.Text = 'F2: ative o monitoramento antes de revalidar.'; return }
    if ($script:questScanBusy) { $questInfo.Text = 'OCR em andamento; tente F2 novamente.'; return }
    if ($q.Stage -eq 'Open' -or $q.Stage -eq 'AwaitDecrease') {
        $questInfo.Text = 'Ainda conferindo a entrega. F2 so libera apos entrar em recuperacao.'
        return
    }
    # F2 expressa a confirmacao MANUAL do usuario sobre a ultima entrega.
    # Nao faz clique aqui: exige novas leituras antes da proxima entrega.
    $q.Stage = 'Idle'; $q.Hits = 0; $q.LastCounter = ''
    $q.BeforeReadings = @(); $q.Due = [datetime]::Now
    foreach ($li in $questList.Items) {
        if ($li.Tag.File -eq $q.File) { $li.SubItems[2].Text = 'Revalidando (F2)'; break }
    }
    $questInfo.Text = ('F2: {0} revalidada. Sem clique imediato; exige duas novas leituras.' -f $q.Name)
    $script:overlaySignature = ''
    Refresh-AQWOverlay
}
function Set-OverlayHotkey {
    $selected = [string]$overlayHotkeyCombo.SelectedItem
    if ([string]::IsNullOrWhiteSpace($selected)) { return }
    if (-not $script:questWatchEnabled) {
        $script:revalidateHotkeyLabel = $selected
        $overlayHotkeyHint.Text = ('{0}: ativado com o monitor' -f $selected)
        Save-OverlayConfig
        return
    }
    $keyName = ($selected -split ' \+ ')[-1]
    $matchKey = [regex]::Match($keyName,'^F(1[01]|[1-9])$')
    if ($matchKey.Success) { $vk = 111 + [int]$matchKey.Groups[1].Value }
    elseif ($keyName.Length -eq 1 -and $keyName -match '^[A-Z]$') { $vk = [int][char]$keyName }
    else { return }
    [uint32]$mods = 0
    if ($selected.Contains('Ctrl')) { $mods = $mods -bor 2 }
    if ($selected.Contains('Shift')) { $mods = $mods -bor 4 }
    if ($script:revalidateHotkeyManager.ChangeHotkey($vk,$mods)) {
        $script:revalidateHotkeyLabel = $selected
        $overlayHotkeyHint.Text = ('Ativo: {0}, mesmo minimizado' -f $selected)
        Save-OverlayConfig
    } else {
        $overlayHotkeyHint.Text = 'Atalho ocupado. Escolha outro.'
        if ($script:revalidateHotkeyLabel) { $overlayHotkeyCombo.SelectedItem = $script:revalidateHotkeyLabel }
    }
}
function Refresh-AQWOverlay {
    if (-not $script:questWatchEnabled -or -not $overlayCheckbox.Checked) {
        if ($script:overlayForm.Visible) { $script:overlayForm.Hide() }
        return
    }
    $target = Get-OverlayRevalidateTarget
    $targetName = $(if ($null -ne $target) { [string]$target.Name } else { 'selecione uma quest' })
    $foreground = ($script:mainHandle -ne [IntPtr]::Zero -and [AQWQuestVision]::IsActive($script:mainHandle))
    $lines = New-Object System.Collections.ArrayList
    [void]$lines.Add([pscustomobject]@{Text=('  MONITOR DE REQUISITOS  |  {0}' -f $script:revalidateHotkeyLabel); Color=$accent; Bold=$true})
    [void]$lines.Add([pscustomobject]@{Text=('  Revalidar: {0}' -f $targetName); Color=$muted; Bold=$false})
    if (-not $foreground) { [void]$lines.Add([pscustomobject]@{Text='  AQW fora de foco: leituras pausadas';Color=[System.Drawing.Color]::FromArgb(244,184,91);Bold=$false}) }
    if ($script:isPaused) { [void]$lines.Add([pscustomobject]@{Text='  Pausado (F3)';Color=[System.Drawing.Color]::FromArgb(244,184,91);Bold=$false}) }
    $shown = 0
    foreach ($q in $script:questRecords) {
        if (-not $q.Enabled) { continue }
        $shown++
        [void]$lines.Add([pscustomobject]@{Text=('  {0}  |  {1}' -f $q.Name, $q.Stage);Color=$text;Bold=$true})
        $reads = @()
        if ($script:overlayReadings.ContainsKey([string]$q.File)) { $reads = @($script:overlayReadings[[string]$q.File]) }
        if ($reads.Count -eq 0) {
            foreach ($r in @(Get-AQWRequirements $q)) {
                [void]$lines.Add([pscustomobject]@{Text=('     {0}: aguardando leitura' -f $r.Name); Color=$muted; Bold=$false})
            }
        } else {
            foreach ($r in $reads) {
                $rc = $muted
                if ($r.Status -eq 'Completo') { $rc = [System.Drawing.Color]::FromArgb(87,214,158) }
                elseif ($r.Status -eq 'Incompleto') { $rc = [System.Drawing.Color]::FromArgb(255,202,92) }
                elseif ($r.Status -match 'Falha') { $rc = [System.Drawing.Color]::FromArgb(255,109,109) }
                [void]$lines.Add([pscustomobject]@{Text=('     {0}: {1}  |  {2}' -f $r.Name,$r.Value,$r.Status); Color=$rc; Bold=$false})
            }
        }
    }
    if ($shown -eq 0) { [void]$lines.Add([pscustomobject]@{Text='  Nenhuma quest habilitada';Color=$muted;Bold=$false}) }
    $fingerprint = ($lines | ForEach-Object { $_.Text }) -join '|'
    if ($script:overlaySignature -ne $fingerprint) {
        $script:overlaySignature = $fingerprint
        $script:overlayBody.SuspendLayout()
        try {
            foreach ($ctrl in @($script:overlayBody.Controls)) { $script:overlayBody.Controls.Remove($ctrl); $ctrl.Dispose() }
            foreach ($line in $lines) {
                $label = New-Object System.Windows.Forms.Label
                $label.Text = [string]$line.Text
                $label.ForeColor = $line.Color
                $label.AutoSize = $false
                $label.Size = New-Object System.Drawing.Size(325,22)
                $label.Margin = New-Object System.Windows.Forms.Padding(1,0,1,0)
                $label.BackColor = [System.Drawing.Color]::Transparent
                $style = $(if ($line.Bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular })
                $label.Font = New-Object System.Drawing.Font('Segoe UI',9,$style)
                $script:overlayBody.Controls.Add($label)
            }
        } finally { $script:overlayBody.ResumeLayout() }
    }
    $height = [Math]::Max(105,[Math]::Min(480,16 + 22 * $lines.Count))
    if ($script:overlayForm.Height -ne $height) { $script:overlayForm.Height = $height }
    $scr = [System.Windows.Forms.Screen]::PrimaryScreen
    if ($script:mainHandle -ne [IntPtr]::Zero -and [BackgroundKeySender]::IsWindow($script:mainHandle)) { $scr = [System.Windows.Forms.Screen]::FromHandle($script:mainHandle) }
    $area = $scr.WorkingArea
    $corner = [string]$overlayCorner.SelectedItem
    $x = $(if ($corner.EndsWith('direito')) { $area.Right - $script:overlayForm.Width - 18 } else { $area.Left + 18 })
    $y = $(if ($corner.StartsWith('Inferior')) { $area.Bottom - $height - 20 } else { $area.Top + 20 })
    $script:overlayForm.Location = New-Object System.Drawing.Point($x,$y)
    if (-not $script:overlayForm.Visible) { $script:overlayForm.Show() }
}
$overlayCheckbox.Add_CheckedChanged({ Save-OverlayConfig; $script:overlaySignature=''; Refresh-AQWOverlay })
$overlayCorner.Add_SelectedIndexChanged({ Save-OverlayConfig; Refresh-AQWOverlay })
$overlayHotkeyCombo.Add_SelectedIndexChanged({
    if ($script:revalidateHotkeyInitialized -and [string]$overlayHotkeyCombo.SelectedItem -ne $script:revalidateHotkeyLabel) { Set-OverlayHotkey }
})
$script:revalidateHotkeyManager = New-Object AQWHotkeyReceiver
$script:revalidateHotkeyManager.add_HotkeyPressed({ Revalidate-AQWQuest (Get-OverlayRevalidateTarget) })
$form.Add_Shown({
    if (-not $script:revalidateHotkeyInitialized) {
        $script:revalidateHotkeyInitialized = $true
        Set-OverlayHotkey
    }
})
$script:overlayTimer = New-Object System.Windows.Forms.Timer
$script:overlayTimer.Interval = 900
$script:overlayTimer.Add_Tick({ Refresh-AQWOverlay })
$script:overlayTimer.Start()

function Tick-AQWQuests {
    if (-not $script:questWatchEnabled -or $script:questScanBusy -or $script:questRecords.Count -eq 0) { return }
    if ($script:isPaused) { $questInfo.Text = 'Pausado por F3. O monitor tambem aguarda.'; return }
    if ($script:mainHandle -eq [IntPtr]::Zero -or -not [BackgroundKeySender]::IsWindow($script:mainHandle)) { return }
    if (-not [AQWQuestVision]::IsActive($script:mainHandle)) { return }
    $clientRect = [AQWQuestVision]::ClientBounds($script:mainHandle)
    if ($clientRect.IsEmpty) { return }
    $script:questScanBusy = $true
    try {
        $pending = @($script:questRecords | Where-Object { $_.Stage -eq 'Open' -or $_.Stage -eq 'AwaitDecrease' -or $_.Stage -eq 'Recover' })
        foreach ($li in $questList.Items) {
            $q = $li.Tag
            if (-not $q.Enabled) { $li.SubItems[2].Text = 'Desativada'; continue }
            if ($pending.Count -gt 0 -and $pending[0].File -ne $q.File) { continue }
            $now = [datetime]::Now
            if ($q.Stage -eq 'Halted') { $li.SubItems[2].Text = 'Falha no clique: revalidar'; continue }
            if ($now -lt $q.Due) { continue }
            if ($q.Stage -eq 'Open') {
                $roi = [System.Drawing.Rectangle]::new(($clientRect.Left + $q.TX), ($clientRect.Top + $q.TY), $q.TW, $q.TH)
                $image = $null
                try {
                    $image = [AQWQuestVision]::Capture($roi)
                    $score = [AQWQuestVision]::Compare($script:questImages[$q.File], $image)
                    if ($score -lt [int]$questThreshold.Value) {
                        $q.Stage = 'Idle'; $q.Due = $now.AddSeconds(4)
                        $li.SubItems[2].Text = ('Turn in diferente: {0}%' -f $score)
                        $questInfo.Text = 'Botao Turn in nao confere com a calibracao. Nao clicarei. Reabra a lista e confira zoom/posicao.'
                        continue
                    }
                    if (-not [AQWQuestVision]::ClickTurnIn($script:mainHandle, ($q.TX + [int]($q.TW / 2)), ($q.TY + [int]($q.TH / 2)))) {
                        $li.SubItems[2].Text = 'Falha no clique Turn in'
                        $questInfo.Text = 'Turn in: ' + [AQWQuestVision]::LastTurnClickError
                        $q.Stage = 'Halted'
                        continue
                    }
                    $q.Stage = 'AwaitDecrease'; $q.Due = ([datetime]::Now).AddMilliseconds(950); $q.LastAlert = [datetime]::Now
                    $li.SubItems[2].Text = 'Clique enviado; verificando X/Y'
                } finally { if ($null -ne $image) { $image.Dispose() } }
                continue
            }
            $progress = Get-QuestProgress $q $clientRect
            if ($null -eq $progress) {
                $q.Hits = 0
                $li.SubItems[1].Text = 'Sem leitura'
                if ($q.Stage -eq 'AwaitDecrease' -or $q.Stage -eq 'Recover') {
                    # Uma pausa na atualizacao do tracker nao e prova de falha da entrega.
                    # Continuar monitorando; NUNCA emitir um segundo Turn in sem confirmacao.
                    if ($q.Stage -eq 'AwaitDecrease' -and ($now - $q.LastAlert).TotalSeconds -gt 18) {
                        $q.Stage = 'Recover'
                    }
                    $q.Due = $now.AddMilliseconds(1800)
                    $li.SubItems[2].Text = 'Aguardando contador reaparecer'
                    $questInfo.Text = ('{0}: OCR temporariamente indisponivel apos o clique. Tentando de novo sem novos cliques.' -f $q.Name)
                } else {
                    $li.SubItems[2].Text = 'OCR falhou em um requisito'
                }
                continue
            }
            $li.SubItems[1].Text = $(if ($progress.Total -eq 1) { $progress.Signature } else { ('{0}/{1} OK' -f $progress.ReadyCount, $progress.Total) })
            if ($q.Stage -eq 'AwaitDecrease' -or $q.Stage -eq 'Recover') {
                # A entrega e confirmada apenas quando um requisito consumivel
                # cai pelo menos o minimo exigido, preservando a leitura dos demais.
                $reduced = $false
                $beforeItems = @($q.BeforeReadings)
                $currentItems = @($progress.Requirements)
                if ($beforeItems.Count -gt 0 -and $beforeItems.Count -eq $currentItems.Count) {
                    for ($i = 0; $i -lt $beforeItems.Count; $i++) {
                        $oldItem = $beforeItems[$i]; $newItem = $currentItems[$i]
                        if ([int]$oldItem.Need -ne [int]$newItem.Need) { continue }
                        if ([int]$newItem.Count -le ([int]$oldItem.Count - [int]$oldItem.Need)) {
                            $reduced = $true; break
                        }
                    }
                }
                if ($reduced) {
                    $q.Turns = [int]$q.Turns + 1
                    $li.SubItems[3].Text = [string]$q.Turns
                    $q.Stage = 'Idle'
                    $q.BeforeReadings = @()
                    $q.Due = ([datetime]::Now).AddMilliseconds(1150)
                    $q.Hits = 0; $q.LastCounter = ''
                    $li.SubItems[2].Text = 'Entrega confirmada'
                    $questInfo.Text = ('{0}: confirmada {1} entrega(s). Requisitos: {2}.' -f $q.Name,$q.Turns,$progress.Signature)
                } else {
                    # Nao sabemos se o servidor processou o Turn in ou se o OCR
                    # capturou um frame antigo. Recuperar a leitura automaticamente,
                    # mas nunca repetir o clique com resultado ambiguo.
                    if (($now - $q.LastAlert).TotalSeconds -gt 18) {
                        $q.Stage = 'Recover'
                        $li.SubItems[2].Text = 'Aguardando reducao / revalidacao'
                        $questInfo.Text = ('{0}: contador {1}, sem reducao comprovada desde o clique. Continua verificando. Se a entrega ocorreu, use Revalidar quest.' -f $q.Name,$progress.Signature)
                    } else {
                        $li.SubItems[2].Text = 'Conferindo apos Turn in'
                    }
                    $q.Due = ([datetime]::Now).AddMilliseconds(1800)
                }
                continue
            }
            $value = [string]$progress.Signature
            if ($q.LastCounter -eq $value) { $q.Hits = [int]$q.Hits + 1 } else { $q.LastCounter = $value; $q.Hits = 1 }
            if (-not $progress.Ready) { $li.SubItems[2].Text = ('Coletando itens | {0}/{1} OK' -f $progress.ReadyCount,$progress.Total); continue }
            if ($q.Hits -lt 2) { $li.SubItems[2].Text = 'Conferindo contador'; continue }
            $li.SubItems[2].Text = 'PRONTA PARA ENTREGA'
            if (-not $questAuto.Checked) {
                if (($now - $q.LastAlert).TotalSeconds -gt 10) { [System.Media.SystemSounds]::Asterisk.Play(); $q.LastAlert = $now }
                continue
            }
            if ([AQWQuestVision]::Click($script:mainHandle, $q.QX, $q.QY)) {
                $q.Stage = 'Open'; $q.Before = $progress.Count; $q.BeforeReadings = @($progress.Requirements); $q.Due = ([datetime]::Now).AddMilliseconds(950)
                $li.SubItems[2].Text = 'Abrindo quest...'
                $questInfo.Text = ('Abrindo {0}: todos os {1} requisitos satisfeitos ({2}).' -f $q.Name,$progress.Total,$progress.Signature)
                break
            }
        }
    } catch { $questInfo.Text = 'Erro no monitor: ' + $_.Exception.Message }
    finally { $script:questScanBusy = $false }
}
$script:questTimer = New-Object System.Windows.Forms.Timer
$script:questTimer.Interval = 1600
$script:questTimer.Add_Tick({ Tick-AQWQuests })
$questAdd.Add_Click({ Register-QuestVisual })
$questAddReq.Add_Click({ Add-AQWRequirementToSelectedQuest })
$questRemoveReq.Add_Click({ Remove-AQWRequirementFromSelectedQuest })
$questReqDetails.Add_Click({ Show-AQWRequirementDetails })
$questRevalidate.Add_Click({
    if ($questList.SelectedItems.Count -eq 0) { $questInfo.Text = 'Selecione a quest para revalidar.'; return }
    $q = $questList.SelectedItems[0].Tag
    $answer = [System.Windows.Forms.MessageBox]::Show(
        ('Confirme que verificou no AQW se a ultima entrega de "{0}" foi processada. Revalidar permite outra entrega somente apos novas leituras. Continuar?' -f $q.Name),
        'Revalidar quest', [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) { Revalidate-AQWQuest $q }
})
$questRemove.Add_Click({
    if ($questList.SelectedItems.Count -eq 0 -or $script:questWatchEnabled) { return }
    $li = $questList.SelectedItems[0]; $q = $li.Tag
    if ($script:questImages.ContainsKey($q.File)) { $script:questImages[$q.File].Dispose(); $script:questImages.Remove($q.File) }
    [void]$script:questRecords.Remove($q); $questList.Items.Remove($li)
    [void]$script:overlayReadings.Remove([string]$q.File); $script:overlaySignature = ''
    $path = Join-Path $script:questsPath $q.File
    if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue }
    Save-QuestRecords
})
$questToggle.Add_Click({
    if ($script:questWatchEnabled) {
        $script:questWatchEnabled = $false; $script:questTimer.Stop()
        $questToggle.Text = 'Ativar monitor'; $questToggle.BackColor = $green
        $questInfo.Text = 'Monitor desligado.'
        $script:revalidateHotkeyManager.ReleaseHotkey()
        $overlayHotkeyHint.Text = ('{0}: ativado com o monitor' -f $script:revalidateHotkeyLabel)
        Refresh-AQWOverlay
        $questAdd.Enabled = $true; $questRemove.Enabled = $true; $questAddReq.Enabled = $true; $questRemoveReq.Enabled = $true
    } else {
        if ($script:questRecords.Count -eq 0 -or $script:mainHandle -eq [IntPtr]::Zero) {
            [System.Windows.Forms.MessageBox]::Show('Fixe o jogo e calibre ao menos uma quest.', 'Monitor de quests') | Out-Null; return
        }
        if (-not (Start-AQWOcr)) {
            [System.Windows.Forms.MessageBox]::Show(('O OCR nativo do Windows nao foi iniciado: ' + $script:ocrError),'Reconhecimento de texto indisponivel') | Out-Null; return
        }
        foreach ($q in $script:questRecords) { $q.Stage='Idle'; $q.Hits=0; $q.LastCounter=''; $q.BeforeReadings=@(); $q.Due=[datetime]::MinValue }
        $script:questWatchEnabled = $true; $script:questTimer.Start()
        Set-OverlayHotkey
        $script:overlaySignature = ''; Refresh-AQWOverlay
        $questToggle.Text = 'Pausar monitor'; $questToggle.BackColor = $inputBg
        $questAdd.Enabled = $false; $questRemove.Enabled = $false; $questAddReq.Enabled = $false; $questRemoveReq.Enabled = $false
        $questInfo.Text = 'Monitor ativo. Todos os requisitos precisam estar completos. Nao altere zoom nem a posicao das janelas.'
    }
})
$questTest.Add_Click({
    if ($questList.SelectedItems.Count -eq 0) { $questInfo.Text = 'Selecione uma quest cadastrada para testar o OCR.'; return }
    if ($script:mainHandle -eq [IntPtr]::Zero) { return }
    $q = $questList.SelectedItems[0].Tag
    $form.Hide()
    [AQWQuestVision]::Activate($script:mainHandle)
    Start-Sleep -Milliseconds 400
    $bounds = [AQWQuestVision]::ClientBounds($script:mainHandle)
    $reading = $null
    try { $reading = Get-QuestProgress $q $bounds }
    finally { $form.Show(); $form.BringToFront() }
    $folder = [string]$script:questsPath
    if ($null -eq $reading) { $questInfo.Text = 'Falha na leitura. Use Ver mapa da tela; detalhes abaixo.' }
    else { $questInfo.Text = ('OCR reconheceu {0} para {1}. Completos: {2}/{3}.' -f $reading.Signature,$q.Name,$reading.ReadyCount,$reading.Total) }
    $details = @(
        ('Quest: {0}' -f $q.Name),
        ('Requisitos cadastrados: {0}' -f @(Get-AQWRequirements $q).Count),
        ('Resultado: {0}' -f $(if ($null -ne $reading) { $reading.Signature } else { 'NAO RECONHECIDO' })),
        '', 'Texto bruto e erros retornados pelo Windows:', [string]$script:lastRawOCR,
        '', 'Imagens de teste:', $folder, 'contador-req-N-original.png, contador-req-N-ocr-0.png a contador-req-N-ocr-3.png',
        '', 'Se algum requisito falhar, ajuste a selecao incluindo o nome e o contador X/Y.'
    ) -join [Environment]::NewLine
    [System.Windows.Forms.MessageBox]::Show($details, 'Diagnostico de leitura V7.2', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
})
$questMap.Add_Click({ Show-AQWQuestMap })

$questAuto.Add_CheckedChanged({ if ($questAuto.Checked) { $questInfo.Text = 'ATENCAO: com entrega automatica ativa, o mouse clicara em quest e Turn in. Teste OCR primeiro.' } })
$questThreshold.Add_ValueChanged({ Save-QuestRecords })
$questList.Add_ItemChecked({ param($sender, $e)
    if ($script:questListLoading -or $null -eq $e.Item.Tag) { return }
    $e.Item.Tag.Enabled = $e.Item.Checked
    Save-QuestRecords
})
Load-QuestRecords

$refresh.Add_Click({ Refresh-Targets })
$pin.Add_Click({
    if ($null -eq $combo.SelectedItem) {
        [System.Windows.Forms.MessageBox]::Show('Abra o aplicativo, clique em Atualizar e selecione a janela.', 'Sem destino') | Out-Null
        return
    }
    $target = $combo.SelectedItem
    if (-not [BackgroundKeySender]::IsWindow($target.Handle)) {
        [System.Windows.Forms.MessageBox]::Show('Janela indisponivel. Atualize a lista.', 'Destino fechado') | Out-Null
        return
    }
    if ($script:mainHandle -ne $target.Handle) { [AQWQuestVision]::ClearManualBounds() }
    $script:mainHandle = $target.Handle
    $script:targetHandle = $target.Handle
    $script:targetTitle = $target.Title
    $subcombo.Items.Clear()
    [void]$subcombo.Items.Add([pscustomobject]@{
        Display = 'Janela principal: ' + [BackgroundKeySender]::GetWindowClass($target.Handle)
        Handle  = $target.Handle
    })
    foreach ($child in [BackgroundKeySender]::GetChildren($target.Handle)) {
        if (-not [BackgroundKeySender]::IsWindow($child)) { continue }
        $name = [BackgroundKeySender]::GetWindowClass($child)
        [void]$subcombo.Items.Add([pscustomobject]@{
            Display = ('Componente interno: {0} | HWND {1}' -f $name, $child.ToInt64())
            Handle  = $child
        })
    }
    $subcombo.SelectedIndex = 0
    $pinInfo.Text = 'Fixada: ' + $script:targetTitle
    $pinInfo.ForeColor = $green
    $status.ForeColor = $muted
    $status.Text = ('Janela fixada. {0} componentes encontrados.' -f $subcombo.Items.Count)
})

$add.Add_Click({
    if ($null -eq $keyCombo.SelectedItem) { return }
    Add-KeyRow ([string]$keyCombo.SelectedItem) 1000 $true
})
$remove.Add_Click({
    if ($null -eq $grid.CurrentRow) { return }
    $idx = $grid.CurrentRow.Index
    if ($idx -ge 0) { $grid.Rows.RemoveAt($idx) }
})

function Move-Selected([int]$delta) {
    if ($null -eq $grid.CurrentRow) { return }
    $a = $grid.CurrentRow.Index
    $b = $a + $delta
    if ($a -lt 0 -or $b -lt 0 -or $b -ge $grid.Rows.Count) { return }
    $grid.EndEdit() | Out-Null
    $left = @($grid.Rows[$a].Cells[0].Value, $grid.Rows[$a].Cells[1].Value, $grid.Rows[$a].Cells[2].Value)
    $right = @($grid.Rows[$b].Cells[0].Value, $grid.Rows[$b].Cells[1].Value, $grid.Rows[$b].Cells[2].Value)
    for ($i = 0; $i -lt 3; $i++) {
        $grid.Rows[$a].Cells[$i].Value = $right[$i]
        $grid.Rows[$b].Cells[$i].Value = $left[$i]
    }
    $grid.ClearSelection()
    $grid.Rows[$b].Selected = $true
    $grid.CurrentCell = $grid.Rows[$b].Cells[1]
}
$up.Add_Click({ Move-Selected -1 })
$down.Add_Click({ Move-Selected 1 })
$grid.Add_CurrentCellDirtyStateChanged({
    if ($grid.IsCurrentCellDirty -and $grid.CurrentCell.ColumnIndex -eq 0) { $grid.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit) | Out-Null }
})
$grid.Add_DataError({ param($sender, $eventArgs) $eventArgs.ThrowException = $false })

$start.Add_Click({
    if ($script:isPaused) { Resume-Autoclick; return }
    if ($null -eq $subcombo.SelectedItem) {
        [System.Windows.Forms.MessageBox]::Show('Selecione e fixe o aplicativo antes de iniciar.', 'Selecione o destino') | Out-Null
        return
    }
    $script:targetHandle = $subcombo.SelectedItem.Handle
    if (-not [BackgroundKeySender]::IsWindow($script:targetHandle)) {
        [System.Windows.Forms.MessageBox]::Show('Janela indisponivel. Fixe o destino novamente.', 'Destino fechado') | Out-Null
        return
    }
    $grid.EndEdit() | Out-Null
    $chosen = @(
        foreach ($row in $grid.Rows) {
            if (-not [bool]$row.Cells[0].Value) { continue }
            $key = [string]$row.Cells[1].Value
            $num = 0
            if (-not [int]::TryParse([string]$row.Cells[2].Value, [ref]$num) -or $num -lt 50 -or $num -gt 60000) {
                [System.Windows.Forms.MessageBox]::Show(('Intervalo invalido na tecla {0}. Use de 50 a 60000 ms.' -f $key), 'Verifique os intervalos') | Out-Null
                return
            }
            if (-not $script:keyMap.ContainsKey($key)) { continue }
            [pscustomobject]@{
                Key = $key
                VK  = [int]$script:keyMap[$key]
                Ms  = $num
            }
        }
    )
    if ($chosen.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Marque ao menos uma tecla na coluna Usar.', 'Sequencia vazia') | Out-Null
        return
    }
    $script:activeSequence = $chosen
    $script:sequenceIndex = 0
    $script:sentCount = 0
    $script:sendMode = $methodCombo.SelectedIndex
    $script:isPaused = $false
    $script:isRunning = $true
    foreach ($control in @($grid, $keyCombo, $add, $remove, $up, $down, $subcombo, $methodCombo, $combo, $refresh, $pin)) {
        $control.Enabled = $false
    }
    $start.Enabled = $false
    $stop.Enabled = $true
    Send-Next
    if ($script:isRunning) { $script:timer.Start() }
})
$stop.Add_Click({ Stop-Autoclick 'Parado pelo usuario.' })
$form.Add_FormClosing({
    $script:timer.Stop()
    $script:questTimer.Stop()
    $script:overlayTimer.Stop()
    $script:overlayForm.Close()
    $script:overlayForm.Dispose()
    $script:overlayTimer.Dispose()
    if ($null -ne $script:revalidateHotkeyManager) { $script:revalidateHotkeyManager.Dispose() }
    foreach ($img in @($script:questImages.Values)) { if ($null -ne $img) { $img.Dispose() } }
    if ($null -ne $script:hotkeyManager) { $script:hotkeyManager.Dispose() }
})


# ===========================================================================
# AQW JORDS V8.0 — CAMADA VISUAL (SEM REESCREVER O MOTOR V7.6)
# WebBrowser apresenta a pagina local. As acoes encaminham-se aos controles
# originais, que continuam como unica fonte de verdade (OCR/teclas/hotkeys).
# Em caso de falha de HTML/COM, a janela classica fica disponivel.
# ===========================================================================
$script:jordsWebReady = $false
$script:jordsStartup = [datetime]::Now
$script:jordsWebError = ''
$script:jordsWebEnabled = $true
$script:jordsWebBrowser = $null
$script:jordsWebTick = $null

function Get-JordsWebState {
    $windows = @(foreach ($item in $combo.Items) { [string]$item.Display })
    $components = @(foreach ($item in $subcombo.Items) { [string]$item.Display })
    $keys = @(foreach ($item in $keyCombo.Items) { [string]$item })
    $hks1 = @(foreach ($item in $hotkeyCombo.Items) { [string]$item })
    $hks2 = @(foreach ($item in $overlayHotkeyCombo.Items) { [string]$item })
    $corners = @(foreach ($item in $overlayCorner.Items) { [string]$item })
    $modes = @(foreach ($item in $methodCombo.Items) { [string]$item })
    $skills = @(
        foreach ($row in $grid.Rows) {
            [pscustomobject]@{
                enabled = [bool]$row.Cells[0].Value
                key = [string]$row.Cells[1].Value
                ms = [string]$row.Cells[2].Value
            }
        }
    )
    $quests = @(
        foreach ($li in $questList.Items) {
            $q = $li.Tag
            $reqs = @()
            if ($script:overlayReadings.ContainsKey([string]$q.File)) {
                $reqs = @(
                    foreach ($r in @($script:overlayReadings[[string]$q.File])) {
                        [pscustomobject]@{ name = [string]$r.Name; value = [string]$r.Value; status = [string]$r.Status }
                    }
                )
            } else {
                $reqs = @(
                    foreach ($r in @(Get-AQWRequirements $q)) {
                        [pscustomobject]@{ name = [string]$r.Name; value = ''; status = 'Aguardando leitura' }
                    }
                )
            }
            [pscustomobject]@{
                name = [string]$q.Name; enabled = [bool]$li.Checked
                selected = [bool]$li.Selected
                status = [string]$li.SubItems[2].Text
                turns = [string]$li.SubItems[3].Text
                requirements = @($reqs)
            }
        }
    )
    return [pscustomobject]@{
        target = [string]$script:targetTitle
        status = [string]$status.Text
        questInfo = [string]$questInfo.Text
        ocrReady = [bool]$script:ocrReady
        monitor = [bool]$script:questWatchEnabled
        running = [bool]$script:isRunning
        paused = [bool]$script:isPaused
        windows = @($windows)
        components = @($components)
        windowSelected = [int]$combo.SelectedIndex
        componentSelected = [int]$subcombo.SelectedIndex
        keyChoices = @($keys)
        keyChoice = [string]$keyCombo.SelectedItem
        hotkeys = @($hks1)
        hotkeysQuest = @($hks2)
        hotkeySequence = [string]$hotkeyCombo.SelectedItem
        hotkeyQuest = [string]$overlayHotkeyCombo.SelectedItem
        cornerChoices = @($corners)
        corner = [string]$overlayCorner.SelectedItem
        modes = @($modes)
        modeIndex = [int]$methodCombo.SelectedIndex
        overlay = [bool]$overlayCheckbox.Checked
        autoQuest = [bool]$questAuto.Checked
        similarity = [int]$questThreshold.Value
        mouseMove = [int]$mouseMove.Value
        mouseHover = [int]$mouseHover.Value
        mousePress = [int]$mousePress.Value
        mouseAfter = [int]$mouseAfter.Value
        skills = @($skills)
        quests = @($quests)
    }
}
function Send-JordsWebState {
    if (-not $script:jordsWebReady -or $null -eq $script:jordsWebBrowser -or $null -eq $script:jordsWebBrowser.Document) { return }
    try {
        $json = ConvertTo-Json -InputObject (Get-JordsWebState) -Depth 8 -Compress
        [void]$script:jordsWebBrowser.Document.InvokeScript('syncState', [object[]]@([string]$json))
    } catch {
        $script:jordsWebError = $_.Exception.Message
    }
}
function Select-JordsKeyRow([int]$index) {
    if ($index -lt 0 -or $index -ge $grid.Rows.Count) { return $false }
    $grid.ClearSelection(); $grid.Rows[$index].Selected = $true
    $grid.CurrentCell = $grid.Rows[$index].Cells[1]
    return $true
}
function Select-JordsQuest([int]$index) {
    if ($index -lt 0 -or $index -ge $questList.Items.Count) { return $false }
    foreach ($li in $questList.Items) { $li.Selected = $false }
    $questList.Items[$index].Selected = $true
    return $true
}
function Set-JordsTiming($control, [string]$value) {
    [int]$num = 0
    if (-not [int]::TryParse($value, [ref]$num)) { return }
    if ($num -lt [int]$control.Minimum -or $num -gt [int]$control.Maximum) { return }
    $control.Value = [decimal]$num
}
function Handle-JordsWebCommand([string]$message) {
    $parts = $message.Split([char]'|', 2)
    $action = [string]$parts[0]
    $arg = $(if ($parts.Length -gt 1) { [uri]::UnescapeDataString($parts[1]) } else { '' })
    if ($action -eq 'ready') { $script:jordsWebReady = $true; Send-JordsWebState; return }
    if ($action -eq 'classic') { $script:jordsWebBrowser.Visible = $false; $script:jordsWebEnabled = $false; return }
    $index = -1; $value = ''
    if ($arg -match '^([0-9]+):(.*)$') { $index = [int]$matches[1]; $value = [string]$matches[2] }
    switch ($action) {
        'start' { if (-not $script:isRunning) { $start.PerformClick() } }
        'pause' { Toggle-Automation }
        'stop' { $stop.PerformClick() }
        'refresh' { $refresh.PerformClick() }
        'pin' { $pin.PerformClick() }
        'selectWindow' { if ($arg -match '^\d+$' -and [int]$arg -lt $combo.Items.Count) { $combo.SelectedIndex = [int]$arg } }
        'selectComponent' { if ($arg -match '^\d+$' -and [int]$arg -lt $subcombo.Items.Count) { $subcombo.SelectedIndex = [int]$arg } }
        'addKey' { if ($keyCombo.Items.Contains($arg) -and $add.Enabled) { $keyCombo.SelectedItem = $arg; $add.PerformClick() } }
        'keyEnabled' { if ($grid.Enabled -and $index -ge 0 -and $index -lt $grid.Rows.Count) { $grid.Rows[$index].Cells[0].Value = ($value -eq '1') } }
        'keyTime' { if ($grid.Enabled -and $index -ge 0 -and $index -lt $grid.Rows.Count) { Set-JordsTimingSafe $index $value } }
        'keyUp' { if ($grid.Enabled -and (Select-JordsKeyRow $index)) { $up.PerformClick() } }
        'keyDown' { if ($grid.Enabled -and (Select-JordsKeyRow $index)) { $down.PerformClick() } }
        'keyDelete' { if ($grid.Enabled -and (Select-JordsKeyRow $index)) { $remove.PerformClick() } }
        'captureArea' { Set-AQWCaptureRegion }
        'addQuest' { $questAdd.PerformClick() }
        'removeQuest' { $questRemove.PerformClick() }
        'addReq' { $questAddReq.PerformClick() }
        'removeReq' { $questRemoveReq.PerformClick() }
        'viewReq' { $questReqDetails.PerformClick() }
        'revalidate' { $questRevalidate.PerformClick() }
        'toggleMonitor' { $questToggle.PerformClick() }
        'questEnabled' { if ($index -ge 0 -and $index -lt $questList.Items.Count) { $questList.Items[$index].Checked = ($value -eq '1') } }
        'selectQuest' { if ($arg -match '^\d+$') { [void](Select-JordsQuest ([int]$arg)) } }
        'autoQuest' { $questAuto.Checked = ($arg -eq '1') }
        'similarity' { Set-JordsTiming $questThreshold $arg }
        'ocrTest' { $questTest.PerformClick() }
        'map' { $questMap.PerformClick() }
        'overlayEnabled' { $overlayCheckbox.Checked = ($arg -eq '1') }
        'overlayCorner' { if ($overlayCorner.Items.Contains($arg)) { $overlayCorner.SelectedItem = $arg } }
        'hotkeySequence' { if ($hotkeyCombo.Items.Contains($arg)) { $hotkeyCombo.SelectedItem = $arg } }
        'hotkeyQuest' { if ($overlayHotkeyCombo.Items.Contains($arg)) { $overlayHotkeyCombo.SelectedItem = $arg } }
        'sendMode' { if ($arg -match '^\d+$' -and [int]$arg -lt $methodCombo.Items.Count) { $methodCombo.SelectedIndex = [int]$arg } }
        'mouseMove' { Set-JordsTiming $mouseMove $arg }
        'mouseHover' { Set-JordsTiming $mouseHover $arg }
        'mousePress' { Set-JordsTiming $mousePress $arg }
        'mouseAfter' { Set-JordsTiming $mouseAfter $arg }
    }
    Send-JordsWebState
}
function Set-JordsTimingSafe([int]$index, [string]$value) {
    [int]$num = 0
    if ([int]::TryParse($value, [ref]$num) -and $num -ge 50 -and $num -le 60000) {
        $grid.Rows[$index].Cells[2].Value = [string]$num
    }
}

try {
    $htmlFile = [string]$env:AQW_JORDS_HTML_FILE
    $logoFile = [string]$env:AQW_JORDS_LOGO_FILE
    if ([string]::IsNullOrWhiteSpace($htmlFile) -or -not (Test-Path -LiteralPath $htmlFile)) { throw 'Arquivo local de interface nao encontrado.' }
    $html = [System.IO.File]::ReadAllText($htmlFile, [System.Text.Encoding]::UTF8)
    if ((-not [string]::IsNullOrWhiteSpace($logoFile)) -and (Test-Path -LiteralPath $logoFile)) {
        $logoBase64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($logoFile))
        $html = $html.Replace('LOGO_DATA_URI','data:image/png;base64,' + $logoBase64)
    } else { $html = $html.Replace('LOGO_DATA_URI','') }
    $script:jordsWebBridge = New-Object AQWJordsWebBridge
    $script:jordsWebBridge.add_Request({ param($value)
        try { Handle-JordsWebCommand ([string]$value) }
        catch { $script:jordsWebError = $_.Exception.Message }
    })
    $script:jordsWebBrowser = New-Object System.Windows.Forms.WebBrowser
    $script:jordsWebBrowser.Dock = [System.Windows.Forms.DockStyle]::Fill
    $script:jordsWebBrowser.ScriptErrorsSuppressed = $true
    $script:jordsWebBrowser.IsWebBrowserContextMenuEnabled = $false
    $script:jordsWebBrowser.WebBrowserShortcutsEnabled = $false
    $script:jordsWebBrowser.AllowWebBrowserDrop = $false
    $script:jordsWebBrowser.ObjectForScripting = $script:jordsWebBridge
    $form.Controls.Add($script:jordsWebBrowser)
    $script:jordsWebBrowser.BringToFront()
    $script:jordsWebBrowser.DocumentText = $html
    $form.Size = New-Object System.Drawing.Size(1320,860)
    $form.MinimumSize = New-Object System.Drawing.Size(970,650)
    $script:jordsWebTick = New-Object System.Windows.Forms.Timer
    $script:jordsWebTick.Interval = 850
    $script:jordsWebTick.Add_Tick({
        if ($script:jordsWebReady) { Send-JordsWebState }
        elseif ($script:jordsWebEnabled -and ([datetime]::Now - $script:jordsStartup).TotalSeconds -gt 12) {
            $script:jordsWebEnabled = $false
            $script:jordsWebBrowser.Visible = $false
            $script:jordsWebTick.Stop()
            [System.Windows.Forms.MessageBox]::Show('A nova interface nao respondeu. A interface original foi restaurada, com todas as funcionalidades preservadas.','AQW Jords - recuperacao de interface') | Out-Null
        }
    })
    $script:jordsWebTick.Start()
} catch {
    $script:jordsWebError = $_.Exception.ToString()
    if ($null -ne $script:jordsWebBrowser) { $script:jordsWebBrowser.Visible = $false }
    [System.Windows.Forms.MessageBox]::Show(('Nao foi possivel iniciar a nova interface. Usando interface classica. Detalhe: ' + $script:jordsWebError),'AQW Jords') | Out-Null
}
$form.Add_FormClosing({
    if ($null -ne $script:jordsWebTick) { $script:jordsWebTick.Stop(); $script:jordsWebTick.Dispose() }
    if ($null -ne $script:jordsWebBrowser) { $script:jordsWebBrowser.Dispose() }
})

Refresh-Targets
Layout-App
[void]$form.ShowDialog()
$script:timer.Dispose()
$tooltip.Dispose()
$form.Dispose()
